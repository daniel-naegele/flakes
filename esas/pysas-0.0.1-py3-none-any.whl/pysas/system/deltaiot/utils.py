import statistics

from .data import DeltaIoTStatus, DeltaIoTQoS

from typing import List, Dict


__all__ = [
    'compute_metrics',
    'compute_cumulative_energy_consumption',
    'compute_average_packet_loss',
    'compute_network_fairness_index'
]


RELATIVE_BATTERY_REMAINING: str = 'relative_battery_remaining'
QUEUE_SIZE: str = 'queue_size'


def compute_cumulative_energy_consumption(status: DeltaIoTStatus) -> float:
    return sum(gateway.power_consumed for gateway in status.gateways)


def compute_average_packet_loss(status: DeltaIoTStatus) -> float:
    return sum(max(0.0, min(1.0, gateway.packet_loss)) for gateway in status.gateways) / len(status.gateways)


def min_max_normalisation(values: List[float], eps: float = 1.e-9) -> List[float]:
    min_value = min(values)
    max_value = max(values)
    normalised_values = [max(eps, x - min_value) / max(eps, max_value - min_value) for x in values]

    return normalised_values


def compute_qos_weights(qos_values: Dict[str, List[float]], eps: float = 1.e-9) -> Dict[str, float]:
    qos_variance = {k: statistics.variance(values) for k, values in qos_values.items() if len(values) > 1}  # TODO find better solution
    total_variance = sum(qos_variance.values())
    qos_weights = {k: max(eps, v) / max(eps * len(qos_values), total_variance) for k, v in qos_variance.items()}

    return qos_weights


def compute_network_fairness_index(status: DeltaIoTStatus, eps: float = 1.e-9) -> float:
    # Based on the formula describe in this paper: https://doi.org/10.1016/j.future.2020.02.027
    
    qos_values = {
        RELATIVE_BATTERY_REMAINING: min_max_normalisation(
            [mote.battery_remaining / mote.battery_capacity for mote in status.motes], eps=eps
        ),
        QUEUE_SIZE: min_max_normalisation([len(mote.packet_queue) for mote in status.motes], eps=eps)
    }
    qos_weights = compute_qos_weights(qos_values, eps=eps)

    q_values: List[float] = [sum(w * qos_values[k][i] for k, w in qos_weights.items()) for i in range(len(status.motes))]

    squared_sum_q: float = sum(q_values) ** 2
    sum_q_squared: float = sum(q ** 2 for q in q_values)

    fairness: float = squared_sum_q / max(eps, len(status.motes) * sum_q_squared)

    return fairness


def compute_metrics(status: DeltaIoTStatus) -> DeltaIoTQoS:
    return DeltaIoTQoS(
        cumulative_energy_consumption=compute_cumulative_energy_consumption(status),
        average_packet_loss=compute_average_packet_loss(status),
        network_fairness_index=compute_network_fairness_index(status)
    )

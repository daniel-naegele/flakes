from __future__ import annotations

import math
import random
import numpy as np
from dataclasses import dataclass, field
import pandas as pd
from typing import Optional, List, Tuple, Dict, Union, Protocol

__all__ = ['Node', 'Mote', 'Gateway', 'Link', 'Packet', 'DeltaIoTStatus', 'DeltaIoTQoS',
           'DomainConstants', 'DoubleRange', 'FileProfile', 
           'SNREquation', 'RunInfo', 'Position']

class DomainConstants:
    POWER_CONSUMPTION_RATES = [
        20.2, 21.2, 22.3, 23.7, 24.7, 26.1, 27.5, 28.8, 
        30.0, 31.2, 32.4, 33.7, 35.1, 36.5, 38.0, 38.9
    ]
    
    SF_TIMES = {
        7: 0.128, 8: 0.258, 9: 0.458, 
        10: 0.858, 11: 1.158, 12: 1.58
    }
    
    COULOMB = 1000.0
    RECEPTION_COST = 14.2
    RECEPTION_TIME = 4
    
    @classmethod
    def get_power_consumption_rate(cls, number: int) -> float:
        return cls.POWER_CONSUMPTION_RATES[number]
    
    @classmethod
    def get_sf_time(cls, sf_time: int) -> float:
        return cls.SF_TIMES[sf_time]


@dataclass 
class DoubleRange:
    def __init__(self, min_val: float, max_val: float, rng: Optional[np.random.RandomState] = None):
        self.min_val = min_val
        self.max_val = max_val
        self.memory: Dict[int, float] = {}
        self._base_seed = hash((min_val, max_val)) % (2**31)
        self._external_rng = rng
    
    def get(self, run_number: int) -> float:
        if run_number in self.memory:
            return self.memory[run_number]
        else:
            if self._external_rng is not None:
                random_val = self.min_val + self._external_rng.random() * (self.max_val - self.min_val)
            else:
                seed = (self._base_seed + run_number) % (2**31)
                rng = np.random.RandomState(seed)
                random_val = self.min_val + rng.random() * (self.max_val - self.min_val)
            self.memory[run_number] = random_val
            if len(self.memory) > 1000:
                recent_keys = [k for k in self.memory.keys() if k > run_number - 100]
                self.memory = {k: self.memory[k] for k in recent_keys}
            return random_val


@dataclass
class FileProfile:
    values: List[float]
    default_value: float
    
    @classmethod
    def from_file(cls, file_path: str, default_value: float) -> FileProfile:
        import os
        
        current_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(current_dir, file_path)
        
        values = []
        try:
            with open(full_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        try:
                            values.append(float(line))
                        except ValueError:
                            continue
        except FileNotFoundError:
            values = [default_value] * 96
        except Exception as e:
            values = [default_value] * 96
            
        return cls(values=values, default_value=default_value)
    
    @classmethod
    def from_float(cls, value: float) -> FileProfile:
        values = [value] * 96
        default_value = value
        return cls(values=values, default_value=default_value)
    
    def get(self, run_number: int) -> float:
        if len(self.values) == 0:
            return self.default_value if self.default_value is not None else 0.1
        
        value = self.values[run_number % len(self.values)]
        return value if value is not None else (self.default_value if self.default_value is not None else 0.1)


@dataclass
class SNREquation:
    multiplier: float
    constant: float
    
    def get_snr(self, power: int) -> float:
        return self.multiplier * power + self.constant


@dataclass
class Position:
    x: float
    y: float
    
    @classmethod
    def random(cls, range_val: float) -> Position:
        return cls(random.random() * range_val, random.random() * range_val)


@dataclass
class RunInfo:
    global_interference: DoubleRange = field(default_factory=lambda: DoubleRange(0.0, 10.0))
    run_number: int = 0
    
    def increment_run_number(self):
        self.run_number += 1


@dataclass
class Packet:
    source: Mote
    destination_id: Optional[int]
    number: int
    
    def set_destination_id(self, gateway_id: int):
        self.destination_id = gateway_id
        
    def get_destination_id(self) -> Optional[int]:
        return self.destination_id
        
    def get_source(self) -> Mote:
        return self.source
        
    def get_number(self) -> int:
        return self.number
    
    def clone(self) -> Packet:
        return Packet(self.source, self.destination_id, self.number)
    
    def __hash__(self):
        prime = 31
        result = 1
        result = prime * result + self.number
        result = prime * result + (0 if self.source is None else hash(self.source))
        return result
    
    def __eq__(self, other):
        if self is other:
            return True
        if other is None or not isinstance(other, Packet):
            return False
        if self.number != other.number:
            return False
        if self.source is None:
            return other.source is None
        if self.destination_id is None:
            return other.destination_id is None
        else:
            return (self.source == other.source) and (self.destination_id == other.destination_id)

    @classmethod
    def from_dict(cls, data: Dict, source_mote: Mote) -> Packet:
        return cls(source_mote, data['dest_gateway_id'], data['number'])


@dataclass(kw_only=True)
class Node:
    id: int
    position: Position = field(default_factory=lambda: Position(0, 0))
    interference: float = 0.0
    
    def __hash__(self):
        return hash(self.id)
    
    def __eq__(self, other):
        if self is other:
            return True
        if other is None or not isinstance(other, Node):
            return False
        return self.id == other.id
    
    def receive_packet(self, packet: Packet):
        raise NotImplementedError


@dataclass
class Link:
    src_node_id: int
    dest_node_id: int
    direction_gateway_id: int
    power: int
    distribution: int
    latency: float = 0.0
    sf_time_number: int = 11
    snr_equation: SNREquation = field(default_factory=lambda: SNREquation(0, 0))
    interference: float = 0.0
    
    @property
    def from_id(self) -> int:
        return self.src_node_id
    
    @property
    def to_id(self) -> int:
        return self.dest_node_id
    
    @property
    def direction_id(self) -> int:
        return self.direction_gateway_id

    @property
    def power_number(self) -> int:
        return self.power
    
    @power_number.setter
    def power_number(self, value: int):
        self.power = value

    @property
    def snr_eq_params(self) -> Tuple[float, float]:
        return (self.snr_equation.multiplier, self.snr_equation.constant)

    @property
    def snr(self) -> float:
        return self.snr_equation.get_snr(self.power)

    @property
    def packet_loss(self) -> int:
        return 0
    
    def send_packet(self, packet: Packet, run_info: RunInfo, 
                destination_node: Optional[Mote | Gateway] = None,
                gateway: Optional[Gateway] = None):
        packet_loss = self.calculate_packet_loss(run_info)
        if random.random() * 100 + 1 > packet_loss:
            if destination_node:
                if isinstance(destination_node, Mote):
                    destination_node.receive_packet(packet, gateway=gateway)
                else:
                    destination_node.receive_packet(packet)
        
        
    def calculate_packet_loss(self, run_info: RunInfo) -> int:
        snr = self.get_snr(run_info)
        if snr > 0:
            return 0
        elif snr < -20:
            return 100
        else:
            return int(abs(snr / 2) * 10)
            
    def get_snr(self, run_info: RunInfo) -> float:
        snr = self.snr_equation.get_snr(self.power)
        run_number = run_info.run_number
        link_int = self.interference
        if run_info.global_interference is not None:
            global_int = run_info.global_interference.get(run_number)
        else:
            global_int = 0.0
        interference = max(link_int, global_int)
        return snr - interference
        
    def get_power_consumption_rate(self) -> float:
        return DomainConstants.get_power_consumption_rate(self.power)
        
    def get_sf_time(self) -> float:
        return DomainConstants.get_sf_time(self.sf_time_number)

    @classmethod
    def from_dict(cls, params: Dict) -> Link:
        if not all(k in params for k in ('src_node_id', 'dest_node_id', 'direction_gateway_id')):
            raise ValueError("Missing required parameters to create Link")
        link = cls(
            src_node_id=params['src_node_id'],
            dest_node_id=params['dest_node_id'],
            direction_gateway_id=params['direction_gateway_id'],
            power=params.get('power', 0),
            distribution=params.get('distribution', 0),
            latency=params.get('latency', 0.0),
            sf_time_number=params.get('sf_time_number', 11),
            interference=params.get('interference', 0.0),
            snr_equation=SNREquation(
                params.get('snr_eq_params', (0.0, 0.0))[0],
                params.get('snr_eq_params', (0.0, 0.0))[1]
            )
        )    
        return link

    def __str__(self):
        return (f'Link node {self.src_node_id} - node {self.dest_node_id}:\n'
                f'\tsource node: {self.src_node_id}\n'
                f'\tdestination node: {self.dest_node_id}\n'
                f'\tdirection: gateway: {self.direction_gateway_id}\n'
                f'\tpower: {self.power:.2f}\n'
                f'\tdistribution: {self.distribution}\n'
                f'\tlatency: {self.latency:.2f}\n'
                f'\tinterference: {self.interference:.2f}\n'
                f'\tpacket loss: {self.packet_loss}\n'
                f'\tsig. to noise ratio: {self.snr:.2f}')
        
    def print_src_dest(self) -> str:
        return f'Link {self.src_node_id} -> {self.dest_node_id}'

@dataclass(kw_only=True)
class Mote(Node):
    battery_capacity: float = 0.0
    load: int = 1
    battery_remaining: float = 0.0
    
    activation_probability: FileProfile = field(default_factory=lambda: FileProfile([1]*96, 1))
    
    did_activate_this_turn: bool = False  # idk let's see if this works
    
    @property
    def links(self) -> List[Link]:
        return self._links.copy()

    _links: List[Link] = field(default_factory=list)
    
    packet_queue: List[Packet] = field(default_factory=list)
    last_packet_number: int = 0
    
    def __post_init__(self):
        if self.battery_remaining is None or self.battery_remaining == 0.0:
            self.battery_remaining = self.battery_capacity
        
        # Handle dict serialization of FileProfile
        if isinstance(self.activation_probability, dict):
            self.activation_probability = FileProfile(
                values=self.activation_probability.get('values', [1]*96).copy(),
                default_value=self.activation_probability.get('default_value', 1.0)
            )
        elif isinstance(self.activation_probability, (int, float)):
            value = self.activation_probability if self.activation_probability is not None else 0.1
            self.activation_probability = FileProfile.from_float(value)
        elif self.activation_probability is None:
            self.activation_probability = FileProfile([1]*96, 1)
        elif not isinstance(self.activation_probability, FileProfile):
            self.activation_probability = FileProfile([1]*96, 1)
    
    def __hash__(self):
        return hash(self.id)
    
    def __eq__(self, other):
        if self is other:
            return True
        if other is None or not isinstance(other, Mote):
            return False
        return self.id == other.id
    
    def add_link(self, params: Dict):
        existing_link = self.get_link_to(params['dest_node_id'])
        if existing_link is not None:
            raise ValueError(f"Link from {params['src_node_id']} to {params['dest_node_id']} already exists")
        params['src_node_id'] = self.id # make sure that the source node id is correct
        link = Link.from_dict(params)
        self._links.append(link)
        
    def get_link_to(self, dest_node_id: int) -> Optional[Link]:
        for link in self._links:
            if link.dest_node_id == dest_node_id:
                return link
        return None
        
    def handle_turn(self, run_info: RunInfo, all_nodes: Optional[Dict[int, Mote] | Dict[int, Gateway]] = None):
        my_packets = []
        
        # DEFENSIVE CHECK: yes you have to defend yourself from this system
        if not hasattr(self.activation_probability, 'get'):
            if isinstance(self.activation_probability, (int, float)):
                self.activation_probability = FileProfile.from_float(float(self.activation_probability))
            else:
                self.activation_probability = FileProfile([1]*96, 1)
        
        #let's be super defensive here      
        if not self.activation_probability:
            self.activation_probability = FileProfile([1]*96, 1)
            
        should_send = random.random() < self.activation_probability.get(run_info.run_number)

        # RECORD activation status
        self.did_activate_this_turn = should_send

        if should_send:
            for i in range(self.load):
                self.last_packet_number += 1
                packet = Packet(source=self, destination_id=None, number=self.last_packet_number)
                my_packets.append(packet)
        
        # 2. Decide what direction to send the packets
        total_distribution = sum(link.distribution for link in self._links)
        
        # choose a destination for each packet
        for packet in my_packets:
            rand = int(round(random.random() * total_distribution))
            count_distribution = 0
            for link in self._links:
                count_distribution += link.distribution
                if count_distribution >= rand:
                    packet.set_destination_id(link.direction_gateway_id)
                    break
        
        # 3. Notify the gateways that it should expect packets
        for packet in my_packets:
            gateway = all_nodes.get(packet.get_destination_id(), None) if all_nodes else None
            if gateway:
                gateway.add_packet_to_expect()
        
        # 4. Send all packets in queue
        self.packet_queue.extend(my_packets)  # Add my packets to queue
        
        for packet in self.packet_queue:
            # gather possible destination links
            possible_links = []
            for link in self._links:
                if link.direction_gateway_id == packet.get_destination_id():
                    possible_links.append(link)
            
            # Calculate total distribution
            total_distribution = sum(link.distribution for link in possible_links)
            target_gateway = all_nodes.get(packet.get_destination_id()) if all_nodes else None

            if not possible_links:
                pass
            elif total_distribution > 100:
                for link in possible_links:
                    dest_node = all_nodes.get(link.dest_node_id) if all_nodes else None
                    self.send_packet_over(link, packet, run_info, node=dest_node, gateway=target_gateway)
            else:
                rand = int(round(random.random() * total_distribution))
                count_distribution = 0
                for link in possible_links:
                    count_distribution += link.distribution
                    if count_distribution >= rand:
                        dest_node = all_nodes.get(link.dest_node_id) if all_nodes else None
                        self.send_packet_over(link, packet, run_info, node=dest_node, gateway=target_gateway)
                        break
        
        # 5. Clear packet queue since they are all sent now
        self.packet_queue.clear()
            
    def send_packet_over(self, link: Link, packet: Packet, run_info: RunInfo, 
                    node: Optional[Mote | Gateway] = None, 
                    gateway: Optional[Gateway] = None):
        assert link in self._links
        link.send_packet(packet, run_info, destination_node=node, gateway=gateway)
        battery_usage = link.get_sf_time() * (link.get_power_consumption_rate() / DomainConstants.COULOMB)
        self.battery_remaining -= battery_usage
        if gateway:
            gateway.report_power_consumed(battery_usage)
        
    def receive_packet(self, packet: Packet, gateway: Optional[Gateway] = None):
        self.packet_queue.append(packet)
        
        battery_usage = (DomainConstants.RECEPTION_TIME * 
                        DomainConstants.RECEPTION_COST / 
                        DomainConstants.COULOMB)
        self.battery_remaining -= battery_usage
        if gateway:
            gateway.report_power_consumed(battery_usage)

    def str_deep(self) -> str:
        return f"Mote {self.id}: pos={self.position.x:.1f},{self.position.y:.1f}, battery={self.battery_remaining:.1f}, links={len(self.links)}"

    @classmethod
    def from_dict(cls, params: Dict) -> Mote:
        mote = cls(
            id=params.get('id'),
            position=params.get('position', Position(0, 0)) if isinstance(params.get('position'), Position) else Position(params.get('position', {}).get('x', 0), params.get('position', {}).get('y', 0)),
            interference=params.get('interference', 0.0),
            battery_capacity=params.get('battery_capacity', 100.0),
            battery_remaining=params.get('battery_remaining', None),
            load=params.get('load', 1),
            did_activate_this_turn=params.get('did_activate_this_turn', False),
            _links=[Link.from_dict(link) for link in params.get('_links', [])],
            packet_queue=[],
            last_packet_number=params.get('last_packet_number'),
            activation_probability=params.get('activation_probability', FileProfile([1]*96, 1))
        )
        
        # activation_prob = params.get('activation_probability', FileProfile([1]*96, 1))
        # mote.activation_probability = activation_prob
    
        return mote

    def __str__(self):
        return (f'Mote {self.id}:\n'
                f'\tposition: ({self.position.x:.2f}, {self.position.y:.2f})\n'
                f'\tinterference: {self.interference:.2f}\n'
                f'\tbattery: {100 * self.battery_remaining / self.battery_capacity:.2f}%\n'
                f'\tload: {self.load}\n'
                f'\tactivation proba.: {self.activation_probability.get(0) if isinstance(self.activation_probability, FileProfile) else self.activation_probability}\n'
                f'\tpacket queue size: {len(self.packet_queue)}')


@dataclass(kw_only=True)  
class Gateway(Node):
    @property
    def view_mote_ids(self) -> List[int]:
        return self._view_mote_ids.copy()
    
    _view_mote_ids: List[int] = field(default_factory=list)

    packet_store: List[Packet] = field(default_factory=list)
    expected_packet_count: int = 0
    power_consumed: float = 0.0
    
    def __hash__(self):
        return hash(self.id)
    
    def __eq__(self, other):
        if self is other:
            return True
        if other is None or not isinstance(other, Gateway):
            return False
        return self.id == other.id

    @property 
    def packet_loss(self) -> float:
        return self.calculate_packet_loss()
        
    def receive_packet(self, packet: Packet):
        self.packet_store.append(packet)
        
    def add_packet_to_expect(self):
        self.expected_packet_count += 1
        
    def reset_packet_store_and_expected_packet_count(self):
        self.packet_store.clear()
        self.expected_packet_count = 0
        
    def report_power_consumed(self, amount: float):
        self.power_consumed += amount
        
    def reset_power_consumed(self):
        self.power_consumed = 0.0
        
    def calculate_packet_loss(self) -> float:
        if self.expected_packet_count == 0:
            return 0.0
        
        # Handle both Packet objects and dictionary representations
        # because yes this system hates you even though you just show it love
        unique_packets = set()
        
        for packet in self.packet_store:
            if isinstance(packet, dict):
                packet_key = (packet.get('src_mote_id'), packet.get('dest_gateway_id'), packet.get('number'))
            else:
                packet_key = (packet.source.id, packet.destination_id, packet.number)
            
            unique_packets.add(packet_key)
        
        packet_store_size_without_duplicates = len(unique_packets)
        
        return 1.0 - (packet_store_size_without_duplicates / self.expected_packet_count)

    def str_deep(self) -> str:
        return f"Gateway {self.id}: pos={self.position.x:.1f},{self.position.y:.1f}, packets={len(self.packet_store)}"

    def __post_init__(self):
        if math.isnan(self.packet_loss):
            self.packet_loss = 0.0

    @classmethod
    def from_dict(cls, params: Dict) -> Gateway:
        gateway = cls(
            id=params['id'],
            position=params.get('position', Position(0, 0)) if isinstance(params.get('position'), Position) else Position(params.get('position', {}).get('x', 0), params.get('position', {}).get('y', 0)),
            _view_mote_ids=params.get('_view_mote_ids', []),
            interference=params.get('interference', 0.0),
            packet_store=[],
            expected_packet_count=params.get('expected_packet_count', 0),
            power_consumed=params.get('power_consumed', 0.0)
        )
        return gateway

    def __str__(self):
        return (f'Gateway {self.id}:\n'
                f'\tposition: ({self.position.x:.2f}, {self.position.y:.2f})\n'
                f'\tinterference: {self.interference:.2f}\n'
                f'\tpacket store size: {len(self.packet_store)}\n'
                f'\texpected packets: {self.expected_packet_count}\n'
                f'\tpower consumed: {self.power_consumed:.2f}\n'
                f'\tpacket loss: {self.packet_loss:.2f}')


@dataclass
class DeltaIoTStatus:
    motes: List[Mote]
    gateways: List[Gateway]
    turn_order: List[int]
    global_interference: DoubleRange

    @property
    def links(self) -> List[Link]:
        return [link for mote in self.motes for link in mote.links]

    @property
    def status_df(self):
        data = [
                   {
                       'type': 'network', 'interference': self.global_interference.get(0)
                   },
               ] + [
                   {
                       'type': 'mote',
                       'id': mote.id,
                       'position_coord_x': mote.position.x,
                       'position_coord_y': mote.position.y,
                       'interference': mote.interference,
                       'battery': mote.battery_remaining / mote.battery_capacity,
                       'packet_queue_size': len(mote.packet_queue),
                       'turn_order': self.turn_order.index(mote.id),
                   }
                   for mote in self.motes
               ] + [
                   {
                       'type': 'gateway',
                       'id': gateway.id,
                       'position_coord_x': gateway.position.x,
                       'position_coord_y': gateway.position.y,
                       'interference': gateway.interference,
                       'view_size': len(gateway.view_mote_ids),
                       'packet_store_size': len(gateway.packet_store),
                       'expected_packets': gateway.expected_packet_count,
                       'power_consumed': gateway.power_consumed,
                       'packet_loss': gateway.packet_loss
                   }
                   for gateway in self.gateways
               ] + [
                   {
                       'type': 'link',
                       'id': (link.src_node_id, link.dest_node_id),
                       'interference': link.interference,
                       'power': link.power,
                       'distribution': link.distribution / max(1.e-9, sum(
                           l.distribution for l in self._get_node(link.src_node_id).links
                       )) if sum(l.distribution for l in self._get_node(link.src_node_id).links) <= 100 else 1.0,
                       'packet_loss': link.packet_loss,
                       'snr': link.snr
                   }
                   for link in self.links
               ]

        df = pd.DataFrame(data)
        return df

    @classmethod
    def from_dict(cls, data: Dict) -> 'DeltaIoTStatus':
        return cls(
            [Mote.from_dict(mote_params) for mote_params in data['motes']],
            [Gateway.from_dict(gateway_params) for gateway_params in data['gateways']],
            data['turn_order'],
            DoubleRange(
                data.get('global_interference', {'min_val': 0.0, 'max_val': 10.0}).get('min_val', 0.0),
                data.get('global_interference', {'min_val': 0.0, 'max_val': 10.0}).get('max_val', 10.0),
                None
            ) if not isinstance(data.get('global_interference', None), DoubleRange) else data['global_interference']
        )

    def _get_node(self, node_id: int):
        for mote in self.motes:
            if mote.id == node_id:
                return mote
        for gateway in self.gateways:
            if gateway.id == node_id:
                return gateway

        raise RuntimeError(f'Node {node_id} not found')


@dataclass
class DeltaIoTQoS:
    cumulative_energy_consumption: float = 0.0
    average_packet_loss: float = 0.0
    network_fairness_index: float = 1.0

    @property
    def values(self) -> List[float]:
        return [
            self.cumulative_energy_consumption,
            self.average_packet_loss,
            self.network_fairness_index
        ]

    @property
    def keys(self) -> List[str]:
        return ['cumulative_energy_consumption', 'average_packet_loss', 'network_fairness_index']

    def __getitem__(self, index: Union[int, str]) -> float:
        if isinstance(index, int):
            return self.values[index]
        elif isinstance(index, str):
            return getattr(self, index)
        else:
            raise ValueError(f'Invalid index {index}')
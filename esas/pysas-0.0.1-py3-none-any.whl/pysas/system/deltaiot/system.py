from __future__ import annotations

import logging
import numpy as np
from joblib import Parallel, delayed

from dataclasses import dataclass, asdict
from collections import deque
from copy import deepcopy

from ..core import System, SystemAction
from .data import *
from .utils import compute_metrics

from typing import Optional, List, Dict, Literal, Union

from matplotlib import pyplot as plt
import plotly.graph_objects as go


__all__ = ['DeltaIoT', 'DeltaIoTAction']


@dataclass(kw_only=True)
class DeltaIoTAction(SystemAction):
    src_node_id: int = -1
    dest_node_id: int = -1
    target: Optional[Literal['power', 'distribution']] = None
    action: Optional[Literal['increase', 'decrease']] = None
    equalize: Optional[bool] = None
    current_value: Optional[int] = None

    @classmethod
    def build_plan(
            cls, status: DeltaIoTStatus, plan: Dict[Literal['power', 'distribution'], Optional[Literal['increase', 'decrease']]]
    ) -> List[DeltaIoTAction]:
        return [
            cls(
                src_node_id=link.src_node_id,
                dest_node_id=link.dest_node_id,
                target=target,
                action=action,
                equalize=False if target == 'distribution' else None
            )
            for target, actions in plan.items() for action, link in zip(actions, status.links)
            if action is not None
        ]

    def apply(self, system: DeltaIoT, *args, validate_integrity: bool = True, **kwargs):
        if system.actionable_mote_ids is not None and self.src_node_id not in system.actionable_mote_ids:
            logging.warning(f'Requested to operate on non-actionable mote with ID {self.src_node_id}, skipping')
            return

        if self.target == 'power':
            self.current_value = system.get_link(self.src_node_id, self.dest_node_id).power
            if self.action == 'increase':
                params = {
                    'src_node_id': self.src_node_id,
                    'dest_node_id': self.dest_node_id,
                    'power': max(0, min(15, self.current_value + 1))
                }
                self.success = system.update_link(
                    params=params,
                    validate_integrity=validate_integrity
                )
            elif self.action == 'decrease':
                params = {
                    'src_node_id': self.src_node_id,
                    'dest_node_id': self.dest_node_id,
                    'power': max(0, min(15, self.current_value - 1))
                }
                self.success = system.update_link(
                    params=params,
                    validate_integrity=validate_integrity
                )
            else:
                raise ValueError(f'Invalid action {self.action}')
        elif self.target == 'distribution':
            self.current_value = system.get_link(self.src_node_id, self.dest_node_id).distribution
            if self.action == 'increase':
                params = {
                    'src_node_id': self.src_node_id,
                    'dest_node_id': self.dest_node_id,
                    'distribution': max(0, min(100, (50 if self.equalize else self.current_value) + 10))
                }
                self.success = system.update_link(
                    params=params,
                    validate_integrity=validate_integrity
                )
            elif self.action == 'decrease':
                params = {
                    'src_node_id': self.src_node_id,
                    'dest_node_id': self.dest_node_id,
                    'distribution': max(0, min(100, (50 if self.equalize else self.current_value) - 10))
                }
                self.success = system.update_link(
                    params=params,
                    validate_integrity=validate_integrity
                )
            else:
                raise ValueError(f'Invalid action {self.action}')
        else:
            raise ValueError(f'Invalid target {self.target}')

    def undo(self, system: DeltaIoT, validate_integrity: bool = True):
        if self.success is None:
            raise RuntimeError('Action not yet applied')
        if not self.success:
            return

        if self.target == 'power':
            params = {
                'src_node_id': self.src_node_id,
                'dest_node_id': self.dest_node_id,
                'power': self.current_value
            }
            self.success = system.update_link(
                params=params,
                validate_integrity=validate_integrity
            )
        elif self.target == 'distribution':
            params = {
                'src_node_id': self.src_node_id,
                'dest_node_id': self.dest_node_id,
                'distribution': self.current_value
            }
            self.success = system.update_link(
                params=params,
                validate_integrity=validate_integrity
            )
        else:
            raise ValueError(f'Invalid target {self.target}')


class DeltaIoT(System):
    
    TURN_ORDER: str = 'turn_order'
    MOTE: str = 'mote'
    GATEWAY: str = 'gateway'
    LINK: str = 'link'
    GLOBAL_INTERFERENCE: str = 'global_interference'

    CONCURRENT_TRANSITIONS: bool = False

    def __init__(
        self,
        *args,
        actionable_mote_ids: Optional[List[int]] = None,
        **kwargs
    ):
        self._motes: Dict[int, Mote] = {}
        self._gateways: Dict[int, Gateway] = {}
        self._turn_order: List[int] = []
        self._run_info = RunInfo()
        self._qos_values: List[Dict] = []
        self._rng = np.random.RandomState()
        
        self._actionable_mote_ids: Optional[List[int]] = actionable_mote_ids
        
        super().__init__(*args, **kwargs)

    @classmethod
    def _create_from_status_dict(cls, system: DeltaIoT, status_dict: Dict, actionable_mote_ids: Optional[List[int]] = None) -> 'DeltaIoT':
        system._actionable_mote_ids = actionable_mote_ids
        status: DeltaIoTStatus = DeltaIoTStatus.from_dict(status_dict)
        
        for mote_data in status.motes:
            mote = Mote(
                id=mote_data.id,
                position=mote_data.position,
                battery_capacity=mote_data.battery_capacity,
                load=mote_data.load
            )
            mote.battery_remaining = mote_data.battery_remaining    
            mote.activation_probability = mote_data.activation_probability
            
            # Ensure activation_probability is a FileProfile, not a float  
            if isinstance(mote.activation_probability, (int, float)):
                mote.activation_probability = FileProfile.from_float(float(mote.activation_probability))
            elif mote.activation_probability is None:
                mote.activation_probability = FileProfile([1]*96, 1)
            elif not isinstance(mote.activation_probability, FileProfile):
                # This might be a dict from serialization
                if isinstance(mote.activation_probability, dict):
                    mote.activation_probability = FileProfile(
                        values=mote.activation_probability['values'].copy(),
                        default_value=mote.activation_probability['default_value']
                    )
                else:
                    mote.activation_probability = FileProfile([1]*96, 1)

            mote.interference = mote_data.interference
            
            mote.last_packet_number = mote_data.last_packet_number or 0
            mote.did_activate_this_turn = mote_data.did_activate_this_turn
            system._motes[mote.id] = mote
        
        for gateway_data in status.gateways:
            gateway = Gateway(
                id=gateway_data.id,
                position=gateway_data.position
            )
            gateway.interference = gateway_data.interference
            gateway.expected_packet_count = gateway_data.expected_packet_count
            gateway.power_consumed = gateway_data.power_consumed
            # Ensure view_mote_ids is always a list of integers - sometimes it likes to mutate and become a list of Mote objects or dicts
            # why, you ask? because this is python and python is dynamic and hates you. or because i made a mistake somewhere else. who knows.
            view_mote_ids = []
            if gateway_data.view_mote_ids:
                for vmi in gateway_data.view_mote_ids:
                    if isinstance(vmi, dict):
                        mote_id = vmi.get('id')
                        if mote_id and mote_id in system._motes:
                            view_mote_ids.append(mote_id)
                    elif isinstance(vmi, int):
                        if vmi in system._motes:
                            view_mote_ids.append(vmi)
                    elif hasattr(vmi, 'id'):
                        if vmi.id in system._motes:
                            view_mote_ids.append(vmi.id)
            
            gateway._view_mote_ids = view_mote_ids
            system._gateways[gateway.id] = gateway
        
        for mote_data in status.motes:
            mote = system._motes[mote_data.id]
            for link_data in mote_data.links:
                destination_node_id = link_data.dest_node_id
                direction_gateway_id = link_data.direction_gateway_id
                
                if destination_node_id in system._motes or destination_node_id in system._gateways:
                    mote.add_link(
                        params={
                            'dest_node_id': destination_node_id,
                            'direction_gateway_id': direction_gateway_id,
                            'power': link_data.power,
                            'distribution': link_data.distribution or 0,
                        })
                    
                    link = mote.get_link_to(destination_node_id)
                    if link:
                        link.latency = link_data.latency
                        link.interference = link_data.interference
                        link.snr_equation.multiplier = link_data.snr_eq_params[0]
                        link.snr_equation.constant = link_data.snr_eq_params[1]
        
        for mote_data in status.motes:
            mote = system._motes[mote_data.id]
            for packet_data in mote_data.packet_queue:
                if packet_data:
                    source_mote = system._motes.get(packet_data.src_mote_id)
                    
                    if source_mote and packet_data.dest_gateway_id:
                        packet = Packet(
                            source=source_mote,
                            destination_id=packet_data.dest_gateway_id,
                            number=packet_data.number
                        )
                        mote.packet_queue.append(packet)
                        
        for gateway_data in status.gateways:
            gateway = system._gateways[gateway_data.id]
            for packet_data in gateway_data.packet_store:
                if packet_data:
                    source_mote = system._motes.get(packet_data.src_mote_id)
                    
                    if source_mote and packet_data.dest_gateway_id:
                        packet = Packet(
                            source=source_mote,
                            destination_id=packet_data.dest_gateway_id,
                            number=packet_data.number
                        )
                        gateway.packet_store.append(packet)
        
        system._turn_order = status.turn_order.copy()
        if isinstance(status.global_interference, dict):
            global_int = DoubleRange(
                status.global_interference.get('min_val', 0.0),
                status.global_interference.get('max_val', 0.0),
                system._rng
            )
            global_int.memory = status.global_interference.get('memory', {})
            system._run_info.global_interference = global_int
        else:
            system._run_info.global_interference = status.global_interference
        
        return system

    @classmethod
    def _create_base_case(cls, system: DeltaIoT, actionable_mote_ids: Optional[List[int]] = None) -> 'DeltaIoT':
        # system = cls(actionable_mote_ids=actionable_mote_ids)
        
        load = 10
        battery = 11880.0
        pos_scale = 2
        
        motes_data = [
            (2, 378, 193), (3, 365, 343), (4, 508, 296), (5, 603, 440),
            (6, 628, 309), (7, 324, 273), (8, 392, 478), (9, 540, 479),
            (10, 694, 356), (11, 234, 232), (12, 221, 322), (13, 142, 170),
            (14, 139, 293), (15, 128, 344)
        ]
        
        for mote_id, x, y in motes_data:
            mote = Mote(
                id=mote_id,
                position=Position(x * pos_scale, y * pos_scale),
                battery_capacity=battery,
                load=load
            )
            system._motes[mote_id] = mote
        
        gateway = Gateway(
            id=1,
            position=Position(482 * pos_scale, 360 * pos_scale)
        )
        gateway._view_mote_ids = list(system._motes.keys())
        system._gateways[1] = gateway
        
        power = 15
        distribution = 100
        
        links_data = [
            (2, 4), (3, 1), (4, 1), (5, 9), (6, 4), (7, 2), (7, 3),
            (8, 1), (9, 1), (10, 6), (10, 5), (11, 7), (12, 7), (12, 3),
            (13, 11), (14, 12), (15, 12)
        ]
        
        for src_id, dest_id in links_data:
            src_mote = system._motes[src_id]
            src_mote.add_link({
                'dest_node_id': dest_id,
                'direction_gateway_id': gateway.id,
                'power': power,
                'distribution': distribution
            })
        
        system._motes[2].activation_probability = FileProfile.from_float(0.85)
        system._motes[8].activation_probability = FileProfile.from_float(0.85)
        system._motes[10].activation_probability = FileProfile.from_file("scenario_data/PIR1.txt", 1.0)
        system._motes[13].activation_probability = FileProfile.from_file("scenario_data/PIR2.txt", 1.0)
        system._motes[14].activation_probability = FileProfile.from_float(0.85)
        
        mote12_to_gateway_link = system._motes[12].get_link_to(gateway.id)
        if mote12_to_gateway_link:
            mote12_to_gateway_link.interference = FileProfile.from_file("scenario_data/SNR2.txt", 0.0)
        
        snr_equations = {
            (2, 4): (0.0473684210526, -5.29473684211),
            (3, 1): (0.0280701754386, 4.25263157895),
            (4, 1): (0.119298245614, -1.49473684211),
            (5, 9): (-0.019298245614, 4.8),
            (6, 4): (0.0175438596491, -3.84210526316),
            (7, 3): (0.168421052632, 2.30526315789),
            (7, 2): (-0.0157894736842, 3.77894736842),
            (8, 1): (0.00350877192982, 0.45263157895),
            (9, 1): (0.0701754385965, 2.89473684211),
            (10, 6): (3.51139336547e-16, -2.21052631579),
            (10, 5): (0.250877192982, -1.75789473684),
            (11, 7): (0.380701754386, -2.12631578947),
            (12, 7): (0.317543859649, 2.95789473684),
            (12, 3): (-0.0157894736842, -3.77894736842),
            (13, 11): (-0.0210526315789, -2.81052631579),
            (14, 12): (0.0333333333333, 2.58947368421),
            (15, 12): (0.0438596491228, 1.31578947368)
        }
        
        node_map = {1: gateway}
        node_map.update(system._motes)
        
        for (src_id, dest_id), (multiplier, constant) in snr_equations.items():
            if src_id in system._motes:
                src_mote = system._motes[src_id]
                link = src_mote.get_link_to(dest_id)
                if link:
                    link.snr_equation.multiplier = multiplier
                    link.snr_equation.constant = constant
        
        system._turn_order = [8, 10, 13, 14, 15, 5, 6, 11, 12, 9, 7, 2, 3, 4]
        system._run_info.global_interference = DoubleRange(-5.0, 5.0, system._rng)
        
        return system

    @classmethod
    def load_from_configs(
            cls,
            *args,
            initial_status_dict: Optional[Dict] = None,
            actuate_original_motes_only: bool = True,
            actionable_mote_ids: Optional[List[int]] = None,
            **kwargs,
    ) -> 'DeltaIoT':
        system = super().load_from_configs(*args, actionable_mote_ids=actionable_mote_ids, **kwargs)
        if initial_status_dict is not None:
            system = cls._create_from_status_dict(system, initial_status_dict, actionable_mote_ids)
        else:
            system = cls._create_base_case(system, actionable_mote_ids)

        if actuate_original_motes_only and actionable_mote_ids is None:
            system._actionable_mote_ids = list(system._motes.keys())

        return system

    def _log_status(self):
        logging.debug(f'Logging system status')
        self.log(self._step, self.SYSTEM_STATUS, asdict(compute_metrics(self.status)))
        logging.debug(f'System status logged')
        
    def set_seed(self, seed: Optional[int]):
        if seed is not None:
            self._rng.seed(seed)
        else:
            self._rng = np.random.RandomState()

    def clone(self, reset: bool = True, seed: int = None):
        cloned_system = DeltaIoT.load_from_configs(
            initial_status_dict=self._status_dict(),
            actionable_mote_ids=deepcopy(self._actionable_mote_ids),
        )
        cloned_system._path = self._path
        cloned_system._step = self._step
        cloned_system._rng = deepcopy(self._rng)
        cloned_system._fail_silent = self._fail_silent
        
        if seed is not None:
            cloned_system.set_seed(seed)
        
        if reset:
            cloned_system.reset()

        return cloned_system

    def reset(self):
        for mote in self._motes.values():
            mote.battery_remaining = mote.battery_capacity
            mote.packet_queue.clear()
            mote.last_packet_number = 0
            
        for gateway in self._gateways.values():
            gateway.reset_packet_store_and_expected_packet_count()
            gateway.reset_power_consumed()

        self._run_info.run_number = 0
        self._step = 0

    def __str__(self):
        return (f'DeltaIoT network:\n'
                f'\tStep: {self.step}\n'
                f'\tMote(s):\n\t\t{'\n'.join(m.str_deep() for m in self.motes).replace('\n', '\n\t\t')}\n'
                f'\tGateway(s):\n\t\t{'\n'.join(g.str_deep() for g in self.gateways).replace('\n', '\n\t\t')}\n'
                f'\tTurn order: {self.turn_order}\n'
                f'\tGlobal interference: {self.global_interference.get(self._run_info.run_number):.2f}').replace('\t', '  ')

    def _interactive_plot(self, *args, figure: Optional = None, show: bool = True, **kwargs):
        figure = go.Figure(*args, **kwargs) if figure is None else figure

        edge_x_coords = list()
        edge_y_coords = list()
        for link in self.links:
            src_node = self.get_node_by_id(link.src_node_id)
            dest_node = self.get_node_by_id(link.dest_node_id)
            edge_x_coords.extend([src_node.position.x, dest_node.position.x, None])
            edge_y_coords.extend([src_node.position.y, dest_node.position.y, None])
            figure.add_trace(go.Scatter(
                x=[(src_node.position.x + dest_node.position.x) / 2],
                y=[(src_node.position.y + dest_node.position.y) / 2],
                text=[str(link).replace('\n', '<br>').replace('\t', '  ')],
                mode='markers',
                hoverinfo='text',
                marker=dict(opacity=0, color='black'),
                showlegend=False
            ))
        figure.add_trace(go.Scatter(
            x=edge_x_coords,
            y=edge_y_coords,
            mode='lines',
            line=dict(color='black', dash='dash'),
            name='Links'
        ))

        figure.add_trace(go.Scatter(
            x=[m.position.x for m in self.motes],
            y=[m.position.y for m in self.motes],
            mode='markers',
            marker=dict(color='blue', size=10),
            text=[str(m).replace('\n', '<br>').replace('\t', '  ') for m in self.motes],
            hoverinfo='text',
            name='Motes'
        ))
        figure.add_trace(go.Scatter(
            x=[g.position.x for g in self.gateways],  # Use .x
            y=[g.position.y for g in self.gateways],  # Use .y
            mode='markers',
            marker=dict(color='red', size=12, symbol='square'),
            text=[str(g).replace('\n', '<br>').replace('\t', '  ') for g in self.gateways],
            hoverinfo='text',
            name='Gateways'
        ))

        figure.update_yaxes(scaleanchor='x', scaleratio=1)
        figure.update_layout(
            title='DeltaIoT network', xaxis_title='X coordinate', yaxis_title='Y coordinate', autosize=True
        )

        if show:
            figure.show()

        return figure

    def _static_plot(self, *args, figure: Optional = None, axis: Optional = None, show: bool = True, **kwargs):
        figure = plt.figure(*args, **kwargs) if figure is None and axis is None else figure
        axis = figure.add_subplot(1, 1, 1) if axis is None else axis

        for link in self.links:
            src_pos = self.get_node(link.src_node_id).position
            dest_pos = self.get_node(link.dest_node_id).position
            axis.plot(
                [src_pos.x, dest_pos.x],
                [src_pos.y, dest_pos.y],
                c='k',
                linestyle='--',
                zorder=-1
            )

        mote_positions = [(m.position.x, m.position.y) for m in self.motes]
        gateway_positions = [(g.position.x, g.position.y) for g in self.gateways]

        if mote_positions:
            axis.scatter(*list(zip(*mote_positions)), c='tab:blue', label='Motes', zorder=1)
        if gateway_positions:
            axis.scatter(*list(zip(*gateway_positions)), c='tab:red', label='Gateways', zorder=1)

        axis.set_xlabel('X coordinate')
        axis.set_ylabel('Y coordinate')
        axis.set_title('DeltaIoT network at step {}'.format(self.step))
        axis.grid()
        axis.legend(loc='best')

        plt.gca().set_aspect('equal')

        if show:
            plt.show()

        return figure, axis

    def plot(self, *args, interactive: bool = True, **kwargs):
        if interactive:
            return self._interactive_plot(*args, **kwargs)
        else:
            return self._static_plot(*args, **kwargs)

    def _run_step(self):
        self._run_info.run_number = self._step % 96
            
        for gateway in self._gateways.values():
            gateway.reset_packet_store_and_expected_packet_count()
            gateway.reset_power_consumed()
        
        for mote_id in self._turn_order:
            mote = self._motes.get(mote_id)
            if mote:
                mote.handle_turn(self._run_info, all_nodes=self._motes | self._gateways)
        
        if self._gateways:
            first_gateway = next(iter(self._gateways.values()))
            qos = {
                'energy_consumption': first_gateway.power_consumed,
                'packet_loss': first_gateway.calculate_packet_loss(),
                'period': str(self._run_info.run_number)
            }
            self._qos_values.append(qos)
        
        if len(self._qos_values) > 100:
            self._qos_values = self._qos_values[-100:]
        
    @property
    def step(self):
        return self._step
        
    @property
    def actionable_mote_ids(self) -> Optional[List[int]]:
        return self._actionable_mote_ids
    
    @property
    def turn_order(self) -> List[int]:
        return self._turn_order.copy()
    
    @turn_order.setter
    def turn_order(self, turn_order: List[int]):
        self._turn_order = turn_order.copy()
        self.log(self._step, self.EVENT, {self.TYPE: self.UPDATE, self.TURN_ORDER: self.turn_order})
        
    # @property
    # def global_interference(self) -> DoubleRange:
    #     return self._run_info.global_interference
    
    @property
    def global_interference(self) -> DoubleRange:
        return DoubleRange(
            self._run_info.global_interference.min_val,
            self._run_info.global_interference.max_val,
            None  # should i share the rng or not idk
        )

    @global_interference.setter
    def global_interference(self, global_interference: float| DoubleRange):
        self._run_info.global_interference = DoubleRange(global_interference, global_interference, self._rng)

    @property
    def motes(self) -> List[Mote]:
        m = sorted(self._motes.values(), key=lambda m: m.id)
        return m
    
    @property
    def gateways(self) -> List[Gateway]:
        g = sorted(self._gateways.values(), key=lambda g: g.id)
        return g
    
    @property
    def nodes(self) -> List[Node]:
        nodes = list(self._motes.values()) + list(self._gateways.values())
        return sorted(nodes, key=lambda n: n.id)

    @property
    def links(self) -> List[Link]:
        return [self._serialize_link(link) for mote in self.motes for link in mote.links]
        
    @property
    def status(self) -> DeltaIoTStatus:
        return DeltaIoTStatus(
            [self._serialize_mote(mote) for mote in self.motes],
            [self._serialize_gateway(gateway) for gateway in self.gateways],
            self.turn_order.copy(),
            self.global_interference
        )

    def _serialize_mote(self, mote: Mote) -> Mote:
        if isinstance(mote.activation_probability, FileProfile):
            activation_prob_dict = {
                'values': mote.activation_probability.values.copy(),
                'default_value': mote.activation_probability.default_value
            }
        else:
            activation_prob_dict = {
                'values': [1.0] * 96,
                'default_value': 1.0
            }
        
        mote_copy = Mote(
            id=mote.id,
            position=Position(mote.position.x, mote.position.y),
            interference=mote.interference,
            battery_capacity=mote.battery_capacity,
            battery_remaining=mote.battery_remaining,
            load=mote.load,
            activation_probability=activation_prob_dict,
            did_activate_this_turn=mote.did_activate_this_turn,
            _links=[self._serialize_link(link) for link in mote._links],
            packet_queue=[self._serialize_packet(packet) for packet in mote.packet_queue],
            last_packet_number=mote.last_packet_number
        )
        return mote_copy

    def _serialize_gateway(self, gateway: Gateway) -> Gateway:
        gateway_copy = Gateway(
            id=gateway.id,
            position=Position(gateway.position.x, gateway.position.y),
            interference=gateway.interference,
            _view_mote_ids=gateway._view_mote_ids.copy(),
            packet_store=[self._serialize_packet(packet) for packet in gateway.packet_store],
            expected_packet_count=gateway.expected_packet_count,
            power_consumed=gateway.power_consumed
        )
        return gateway_copy

    def _serialize_link(self, link: Link) -> Link:
        return Link(
            src_node_id=link.src_node_id,
            dest_node_id=link.dest_node_id,
            direction_gateway_id=link.direction_gateway_id,
            power=link.power,
            distribution=link.distribution,
            latency=link.latency,
            sf_time_number=link.sf_time_number,
            snr_equation=SNREquation(link.snr_equation.multiplier, link.snr_equation.constant),
            interference=link.interference
        )

    def _serialize_packet(self, packet: Packet) -> Dict:
        # Serialize packet as dict to avoid mote reference
        return {
            'src_mote_id': packet.source.id,
            'dest_gateway_id': packet.destination_id,
            'number': packet.number
        }

    def _serialize_double_range(self, double_range: DoubleRange) -> Dict:
        # Serialize DoubleRange as dict to avoid RNG reference issues
        return {
            'min_val': double_range.min_val,
            'max_val': double_range.max_val,
            'memory': double_range.memory.copy()
        }
        
    def _status_dict(self) -> Dict:
    
        temp_status = DeltaIoTStatus(
            [self._serialize_mote(mote) for mote in self.motes],
            [self._serialize_gateway(gateway) for gateway in self.gateways], 
            self.turn_order,
            self._serialize_double_range(self.global_interference)
        )
        # use deeeeeeepcopy instead of asdict to avoid shallow copying of lists
        # this SHOULD ensure that activation_probability.values are not shared between motes
        # do i know it for a fact? no. but it should.
        # honestly this whole serialization/deserialization process is a bit of a mess idk
        status_dict = self._deep_serialize_status(temp_status)
        
        return status_dict
    
    def _deep_serialize_status(self, status: DeltaIoTStatus) -> Dict:
        """
        i'm just trying to be absolutely sure that no mutable objects are shared between motes
        during serialization/deserialization. this is killing me softly.
        we need to deep copy everything.
        let's use helper functions to serialize each component. yes i asked my intern to do this.
        miao
        """
        # Helper function to serialize a packet
        def serialize_packet(p):
            if isinstance(p, dict):
                return {
                    'src_mote_id': p.get('src_mote_id'),
                    'dest_gateway_id': p.get('dest_gateway_id'),
                    'number': p.get('number')
                }
            else:
                return {
                    'src_mote_id': p.source.id,
                    'dest_gateway_id': p.destination_id,
                    'number': p.number
                }
        
        # Helper function to serialize a link
        def serialize_link(link):
            if isinstance(link, dict):
                return {
                    'src_node_id': link.get('src_node_id'),
                    'dest_node_id': link.get('dest_node_id'),
                    'direction_gateway_id': link.get('direction_gateway_id'),
                    'power': link.get('power'),
                    'distribution': link.get('distribution'),
                    'latency': link.get('latency', 0.0),
                    'sf_time_number': link.get('sf_time_number', 11),
                    'interference': link.get('interference', 0.0),
                    'snr_eq_params': link.get('snr_eq_params', (0.0, 0.0))
                }
            else:
                return {
                    'src_node_id': link.src_node_id,
                    'dest_node_id': link.dest_node_id,
                    'direction_gateway_id': link.direction_gateway_id,
                    'power': link.power,
                    'distribution': link.distribution,
                    'latency': link.latency,
                    'sf_time_number': link.sf_time_number,
                    'interference': link.interference,
                    'snr_eq_params': (link.snr_equation.multiplier, link.snr_equation.constant)
                }
        
        # Helper function to serialize activation_probability
        def serialize_activation_prob(ap):
            if isinstance(ap, dict):
                return {
                    'values': ap.get('values', [1.0] * 96).copy() if isinstance(ap.get('values'), list) else [1.0] * 96,
                    'default_value': ap.get('default_value', 1.0)
                }
            elif isinstance(ap, FileProfile):
                return {
                    'values': ap.values.copy(),
                    'default_value': ap.default_value
                }
            else:
                return {
                    'values': [1.0] * 96,
                    'default_value': 1.0
                }
        
        # Helper function to serialize position
        def serialize_position(pos):
            if isinstance(pos, dict):
                return {'x': pos.get('x', 0.0), 'y': pos.get('y', 0.0)}
            else:
                return {'x': pos.x, 'y': pos.y}
        
        # Serialize global_interference
        if isinstance(status.global_interference, dict):
            global_interference_dict = {
                'min_val': status.global_interference.get('min_val', 0.0),
                'max_val': status.global_interference.get('max_val', 0.0),
                'memory': status.global_interference.get('memory', {}).copy()
            }
        else:
            global_interference_dict = {
                'min_val': status.global_interference.min_val,
                'max_val': status.global_interference.max_val,
                'memory': status.global_interference.memory.copy()
            }
        
        return {
            'motes': [
                {
                    'id': m.id if not isinstance(m, dict) else m.get('id'),
                    'position': serialize_position(m.position if not isinstance(m, dict) else m.get('position', {})),
                    'interference': m.interference if not isinstance(m, dict) else m.get('interference', 0.0),
                    'battery_capacity': m.battery_capacity if not isinstance(m, dict) else m.get('battery_capacity', 100.0),
                    'battery_remaining': m.battery_remaining if not isinstance(m, dict) else m.get('battery_remaining', 100.0),
                    'load': m.load if not isinstance(m, dict) else m.get('load', 1),
                    'activation_probability': serialize_activation_prob(
                        m.activation_probability if not isinstance(m, dict) else m.get('activation_probability', {})
                    ),
                    'did_activate_this_turn': m.did_activate_this_turn if not isinstance(m, dict) else m.get('did_activate_this_turn', False),
                    '_links': [
                        serialize_link(link)
                        for link in (m._links if not isinstance(m, dict) else m.get('_links', []))
                    ],
                    'packet_queue': [
                        serialize_packet(p)
                        for p in (m.packet_queue if not isinstance(m, dict) else m.get('packet_queue', []))
                    ],
                    'last_packet_number': m.last_packet_number if not isinstance(m, dict) else m.get('last_packet_number', 0)
                }
                for m in status.motes
            ],
            'gateways': [
                {
                    'id': g.id if not isinstance(g, dict) else g.get('id'),
                    'position': serialize_position(g.position if not isinstance(g, dict) else g.get('position', {})),
                    'interference': g.interference if not isinstance(g, dict) else g.get('interference', 0.0),
                    '_view_mote_ids': (
                        g._view_mote_ids.copy() if not isinstance(g, dict) 
                        else g.get('_view_mote_ids', []).copy() if isinstance(g.get('_view_mote_ids'), list) 
                        else []
                    ),
                    'packet_store': [
                        serialize_packet(p)
                        for p in (g.packet_store if not isinstance(g, dict) else g.get('packet_store', []))
                    ],
                    'expected_packet_count': g.expected_packet_count if not isinstance(g, dict) else g.get('expected_packet_count', 0),
                    'power_consumed': g.power_consumed if not isinstance(g, dict) else g.get('power_consumed', 0.0)
                }
                for g in status.gateways
            ],
            'turn_order': status.turn_order.copy() if isinstance(status.turn_order, list) else [],
            'global_interference': global_interference_dict
        }
    
    def get_node_by_id(self, node_id: int) -> Optional[Union[Mote, Gateway]]:
        return self._motes.get(node_id) or self._gateways.get(node_id)
    
    def get_node(self, node_id: int) -> Optional[Node]:
        node = self._motes.get(node_id) or self._gateways.get(node_id)
        if node is None and not self._fail_silent:
            raise RuntimeError(f'Node {node_id} not found')
        return node

    def get_mote(self, mote_id: int) -> Optional[Mote]:
        mote = self._motes.get(mote_id)
        if mote is None and not self._fail_silent:
            raise RuntimeError(f'Mote {mote_id} not found')
        return mote

    def get_gateway(self, gateway_id: int) -> Optional[Gateway]:
        gateway = self._gateways.get(gateway_id)
        if gateway is None and not self._fail_silent:
            raise RuntimeError(f'Gateway {gateway_id} not found')
        return gateway
    
    def get_link(self, src_mote_id: int, dest_node_id: int) -> Optional[Link]:
        src_mote = self._motes.get(src_mote_id)
        if src_mote:
            return src_mote.get_link_to(dest_node_id)
        if not self._fail_silent:
            raise RuntimeError(f'Source mote {src_mote_id} not found')
        return None
    
    def _is_cyclic(self):
        adjacency_dict = {}
        for mote in self._motes.values():
            adjacency_dict[mote.id] = [link.dest_node_id for link in mote._links]
        
        for gateway in self._gateways.values():
            adjacency_dict[gateway.id] = []
        
        all_node_ids = set(adjacency_dict.keys())
        for outgoing_links in adjacency_dict.values():
            all_node_ids.update(outgoing_links)
        
        in_degree_dict = {k: 0 for k in all_node_ids}
        
        for outgoing_links in adjacency_dict.values():
            for dest_id in outgoing_links:
                if dest_id in in_degree_dict:
                    in_degree_dict[dest_id] += 1

        queue = deque()
        for k, v in in_degree_dict.items():
            if v == 0:
                queue.append(k)

        visited = 0
        while len(queue) > 0:
            node_id = queue.popleft()
            visited += 1
            for neighbor in adjacency_dict.get(node_id, []):
                if neighbor in in_degree_dict:
                    in_degree_dict[neighbor] -= 1
                    if in_degree_dict[neighbor] == 0:
                        queue.append(neighbor)

        return visited != len(all_node_ids)
    
    def _check_integrity(self) -> bool:
        if any(sum(link.distribution for link in mote._links) == 0 for mote in self.motes):
            return False
        return True
    
    # this method is needed because yes.
    # you would think that the system could never end up in such state, yet here we are.
    # idk if this is absolutely the best way of doing this but oh well it's just a safety check
    # better safe than sorry
    # also this is only called when deleting a link/mote, so performance isn't a big concern
    def _would_leave_isolated_gateway(self, exclude_mote_ids: List[int] = None, exclude_links: List[tuple] = None) -> bool:
        """
        Check if removing specified motes/links would leave gateways with no connections.
        Also handles the case where all motes would be removed while gateways exist.
        """
        exclude_mote_ids = exclude_mote_ids or []
        exclude_links = exclude_links or []
        
        # quick check: if we're excluding all motes while gateways still exist, that's bad
        remaining_motes = [m for m in self._motes.values() if m.id not in exclude_mote_ids]
        if not remaining_motes and self._gateways:
            return True
        
        for gateway in self._gateways.values():
            has_connection = False
            
            # Check if any remaining mote has a link to this gateway
            for mote in remaining_motes:
                for link in mote._links:
                    if link.dest_node_id == gateway.id and (mote.id, link.dest_node_id) not in exclude_links:
                        has_connection = True
                        break
                        
                if has_connection:
                    break
            
            if not has_connection and remaining_motes:
                return True
                
        return False
    
    def execute(self, plan: List[Optional[SystemAction]]) -> bool:
        # original_system = self.clone(reset=False)
        motes = deepcopy(self._motes)
        gateways = deepcopy(self._gateways)
        turn_order = deepcopy(self.turn_order)
        run_info = deepcopy(self._run_info)
        rng = deepcopy(self._rng)
        
        try:
            for action in plan:
                if action is not None:
                    action(self, validate_integrity=False)

            if not self._check_integrity():
                logging.debug('System network integrity would be violated, rolling back')
                # self._restore_from_clone(original_system)
                self._motes = motes
                self._gateways = gateways
                self._turn_order = turn_order
                self._run_info = run_info
                self._rng = rng
                return False
                
            if not self._validate_network_topology():
                logging.debug('Network topology would be invalid, rolling back')
                # self._restore_from_clone(original_system)
                self._motes = motes
                self._gateways = gateways
                self._turn_order = turn_order
                self._run_info = run_info
                self._rng = rng
                return False

            return True
            
        except Exception as e:
            logging.error(f'Error during action execution: {e}, rolling back')
            # self._restore_from_clone(original_system)
            self._motes = motes
            self._gateways = gateways
            self._turn_order = turn_order
            self._run_info = run_info
            self._rng = rng
            return False

    def _restore_from_clone(self, original_system: 'DeltaIoT'):
        self._motes = original_system._motes
        self._gateways = original_system._gateways
        self._turn_order = original_system._turn_order
        self._run_info = original_system._run_info
        self._qos_values = original_system._qos_values
        self._rng = original_system._rng
        self._step = original_system._step
        self._path = original_system._path

    def _validate_network_topology(self) -> bool:
        # If gateways exist, there must be motes
        if len(self._gateways) > 0 and len(self._motes) == 0:
            return False
            
        # If motes exist, there must be at least one gateway
        if len(self._motes) > 0 and len(self._gateways) == 0:
            return False
            
        # Every mote must have at least one outgoing link
        for mote in self._motes.values():
            if len(mote._links) == 0:
                return False
                
        # Every gateway must have at least one mote that can reach it
        for gateway in self._gateways.values():
            has_incoming_connection = False
            for mote in self._motes.values():
                for link in mote._links:
                    if link.dest_node_id == gateway.id:
                        has_incoming_connection = True
                        break
                if has_incoming_connection:
                    break
            if not has_incoming_connection:
                return False
                
        return True



    ############# CRUD operations daje ###############
    
    def insert_mote(self, params: Dict) -> bool:
        if params['id'] in self._motes:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Mote {params['id']} already exists')

        for link in params.get('links', []):
            dest_id = link.get('dest_node_id')
            direction_gateway_id = link.get('direction_gateway_id')
            
            if dest_id not in self._motes and dest_id not in self._gateways:
                if self._fail_silent:
                    return False
                raise RuntimeError(f'Destination node {dest_id} does not exist')
                
            if direction_gateway_id not in self._gateways:
                if self._fail_silent:
                    return False
                raise RuntimeError(f'Direction gateway {direction_gateway_id} does not exist')
                
        m = Mote.from_dict(params)
        
        self._motes[params['id']] = m

        for gateway in self._gateways.values():
            if params['id'] not in gateway._view_mote_ids:
                gateway._view_mote_ids.append(params['id'])

        if params.get('turn', None) is not None:
            turn = params['turn']
        else:
            turn = len(self._turn_order)
        
        self._turn_order.insert(turn, params['id'])

        # Set source node ID for all links and create the links
        for link_params in params.get('links', []):
            link_params['src_node_id'] = params['id']
            if not self.insert_link(link_params):
                # Rollback if link creation fails
                if params['id'] in self._motes:
                    del self._motes[params['id']]
                    self._turn_order.remove(params['id'])
                    for gateway in self._gateways.values():
                        if params['id'] in gateway._view_mote_ids:
                            gateway._view_mote_ids.remove(params['id'])
                return False

        # Handle parent links (links TO this new mote)
        if params.get('parent_links', None) is not None:
            for link_params in params['parent_links']:
                link_params['dest_node_id'] = params['id']
                if not self.insert_link(link_params):
                    # Rollback if parent link creation fails
                    if params['id'] in self._motes:
                        del self._motes[params['id']]
                        self._turn_order.remove(params['id'])
                        for gateway in self._gateways.values():
                            if params['id'] in gateway._view_mote_ids:
                                gateway._view_mote_ids.remove(params['id'])
                    return False

        self.log(self._step, self.EVENT, {self.TYPE: self.INSERT, self.MOTE: params['id']})

        return True

    def update_mote(self, id: int, params: Dict) -> bool:
        if id not in self._motes:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Mote {id} does not exist')

        mote = self._motes[id]

        if params.get('position', None) is not None:
            mote.position.x = params['position'].x
            mote.position.y = params['position'].y

        if params.get('interference', None) is not None:
            mote.interference = params['interference']

        if params.get('battery_remaining', None) is not None:
            mote.battery_remaining = params['battery_remaining']

        if params.get('load', None) is not None:
            mote.load = params['load']

        if params.get('activation_probability', None) is not None:
            mote.activation_probability = params['activation_probability']

        if params.get('last_packet_number', None) is not None:
            mote.last_packet_number = params['last_packet_number']

        if params.get('packet_queue', None) is not None:
            mote.packet_queue.clear()
            for packet_data in params['packet_queue']:
                if packet_data:
                    source_mote = self._motes.get(packet_data.src_mote_id)
                    
                    if source_mote and packet_data.dest_gateway_id:
                        packet = Packet(
                            source=source_mote,
                            destination_id=packet_data.dest_gateway_id,
                            number=packet_data.number
                        )
                        mote.packet_queue.append(packet)
                        
        if params.get('links', None) is not None:
            params['src_node_id'] = id # set source to the current mote
            links_params = params['links']
            
            if params.get('remove_current_links', False):
                # Check if removing all current links would leave gateways isolated
                # and if so, don't remove.
                # if a gateway ever ends up to be isolated, very bad things happen.
                exclude_links = [(id, link.dest_node_id) for link in self._motes[id]._links]
                if self._would_leave_isolated_gateway(exclude_links=exclude_links):
                    logging.debug(f'Cannot remove all links from mote {id}: would leave gateway(s) isolated')
                    if self._fail_silent:
                        return False
                    raise RuntimeError(f'Cannot remove all links from mote {id}: would leave gateway(s) isolated')
                
                self._motes[id]._links.clear()
            
            # If we're providing an empty links list and cleared existing ones, check topology
            if not links_params and params.get('remove_current_links', False):
                if self._would_leave_isolated_gateway(exclude_mote_ids=[id]):
                    logging.debug(f'Cannot leave mote {id} with no links: would leave gateway(s) isolated')
                    if self._fail_silent:
                        return False
                    raise RuntimeError(f'Cannot leave mote {id} with no links: would leave gateway(s) isolated')
                
            for link_params in links_params:
                existing_link = self._motes[id].get_link_to(link_params['dest_node_id'])
                if not existing_link:
                    self.insert_link(link_params)
                else:
                    self.update_link(link_params)

        self.log(self._step, self.EVENT, {self.TYPE: self.UPDATE, self.MOTE: id})

        return True
    
    def delete_mote(self, id: int) -> bool:
        if id not in self._motes:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Mote {id} not found')
        
        if self._would_leave_isolated_gateway(exclude_mote_ids=[id]):
            logging.debug(f'Cannot delete mote {id}: would leave gateway(s) isolated or result in zero motes while gateways exist')
            if self._fail_silent:
                return False
            raise RuntimeError(f'Cannot delete mote {id}: would leave gateway(s) isolated or result in zero motes while gateways exist')

        if id in self._turn_order:
            self._turn_order.remove(id)

        for gateway in self._gateways.values():
            gateway._view_mote_ids = [mote_id for mote_id in gateway._view_mote_ids if mote_id != id]

        connected_motes = [mote for mote in self._motes.values() if any(l.dest_node_id == id for l in mote._links)]
        while connected_motes:
            mote = connected_motes.pop()
            for link in mote._links:
                if link.dest_node_id == id:
                    self.delete_link(mote.id, id)
            connected_motes = [mote for mote in self._motes.values() if any(l.dest_node_id == id for l in mote._links)]

        del self._motes[id]

        self.log(self._step, self.EVENT, {self.TYPE: self.DELETE, self.MOTE: id})

        return True

    def insert_link(self, params: Dict) -> bool:
        src_mote = self._motes.get(params['src_node_id'])
        if not src_mote:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Source mote {params['src_node_id']} not found')

        dest_node = self.get_node_by_id(params['dest_node_id'])
        direction_gateway = self._gateways.get(params['direction_gateway_id'])
        
        if not dest_node or not direction_gateway:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Destination node {params['dest_node_id']} or direction gateway {params['direction_gateway_id']} not found')

        if src_mote.get_link_to(params['dest_node_id']):
            if self._fail_silent:
                return False
            raise RuntimeError(f'Link from {params['src_node_id']} to {params['dest_node_id']} already exists')

        src_mote.add_link(params)
        
        new_link = src_mote.get_link_to(params['dest_node_id'])

        if self._is_cyclic():
            src_mote._links.remove(new_link)
            if self._fail_silent:
                return False
            raise RuntimeError(f'Adding link would create cycle')

        self.log(self._step, self.EVENT, {self.TYPE: self.INSERT, self.LINK: (params['src_node_id'], params['dest_node_id'])})

        return True

    def update_link(self, params: Dict, validate_integrity: Optional[bool] = True) -> bool:
        src_mote = self._motes.get(params['src_node_id'])
        if not src_mote:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Source mote {params['src_node_id']} not found')

        dest_node = self.get_node_by_id(params['dest_node_id'])
        if not dest_node:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Destination node {params['dest_node_id']} not found')

        link = src_mote.get_link_to(params['dest_node_id'])
        if not link:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Link from {params['src_node_id']} to {params['dest_node_id']} not found')

        original_power = link.power
        original_distribution = link.distribution

        if params.get('power', None) is not None:
            if validate_integrity:
                total_power = sum(l.power for l in src_mote._links) - link.power + params['power']
                if total_power == 0:
                    if self._fail_silent:
                        return False
                    raise RuntimeError(f'Total power on mote {params['src_node_id']} would become zero')
            
            link.power = params['power']

        if params.get('distribution', None) is not None:
            if validate_integrity:
                total_dist = sum(l.distribution for l in src_mote._links) - link.distribution + params['distribution']
                if total_dist == 0:
                    if self._fail_silent:
                        return False
                    raise RuntimeError(f'Total distribution on mote {params['src_node_id']} would become zero')
            
            link.distribution = params['distribution']

        # check if the link update would break connectivity
        # this might when power=0 or distribution=0
        # i mean, it should not happen, but who knows at this point
        if validate_integrity and (link.power == 0 or link.distribution == 0):
            if self._would_leave_isolated_gateway(exclude_links=[(params['src_node_id'], params['dest_node_id'])]):
                link.power = original_power
                link.distribution = original_distribution
                
                logging.debug(f'Cannot set link {params['src_node_id']}->{params['dest_node_id']} to zero: would isolate gateway')
                if self._fail_silent:
                    return False
                raise RuntimeError(f'Cannot set link {params['src_node_id']}->{params['dest_node_id']} to zero: would isolate gateway')

        if params.get('latency', None) is not None:
            link.latency = params['latency']

        if params.get('interference', None) is not None:
            link.interference = params['interference']

        if params.get('snr_equation_params', None) is not None:
            multiplier, constant = params['snr_equation_params']
            link.snr_equation.multiplier = multiplier
            link.snr_equation.constant = constant
                
        if params.get('direction_gateway_id', None) is not None:
            if params['direction_gateway_id'] in self._gateways:
                link.direction_gateway_id = params['direction_gateway_id']

        self.log(self._step, self.EVENT, {self.TYPE: self.UPDATE, self.LINK: (params['src_node_id'], params['dest_node_id'])})

        return True

    def delete_link(self, src_node_id: int, dest_node_id: int) -> bool:
        src_mote = self._motes.get(src_node_id)
        if not src_mote:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Source mote {src_node_id} not found')

        dest_node = self.get_node_by_id(dest_node_id)
        if not dest_node:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Destination node {dest_node_id} not found')

        link = src_mote.get_link_to(dest_node_id)
        if not link:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Link from {src_node_id} to {dest_node_id} not found')
        
        if self._would_leave_isolated_gateway(exclude_links=[(src_node_id, dest_node_id)]):
            logging.debug(f'Cannot delete link {src_node_id}->{dest_node_id}: would leave gateway(s) isolated from remaining motes')
            if self._fail_silent:
                return False
            raise RuntimeError(f'Cannot delete link {src_node_id}->{dest_node_id}: would leave gateway(s) isolated from remaining motes')

        if len(src_mote._links) == 1:
            logging.debug(f'Deleting link {src_node_id}->{dest_node_id} would disconnect mote {src_node_id}, deleting mote {src_node_id} instead')
            return self.delete_mote(src_node_id)
        else:
            src_mote._links.remove(link)
            self.log(self._step, self.EVENT, {self.TYPE: self.DELETE, self.LINK: (src_node_id, dest_node_id)})

        return True

    def insert_gateway(self, params: Dict) -> bool:
        if params['id'] in self._gateways:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Gateway {params['id']} already exists')
        
        g = Gateway.from_dict(params)
        
        self._gateways[params['id']] = g
        
        if params.get('parent_links', None):
            for link_params in params['parent_links']:
                link_params['dest_node_id'] = params['id'] # set destination to the current (new) mote
                link_params['direction_gateway_id'] = params['id'] # set destination to the current (new) mote
                self.insert_link(link_params)
                
        g._view_mote_ids = [mote_id for mote_id in params.get('view_mote_ids', []) if mote_id in self._motes]

        self.log(self._step, self.EVENT, {self.TYPE: self.INSERT, self.GATEWAY: params['id']})

        return True


    def update_gateway(self, id: int, params: Dict) -> bool:
        if id not in self._gateways:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Gateway {id} does not exist')

        gateway = self._gateways[id]

        if params.get('position', None) is not None:
            gateway.position.x = params['position'].x
            gateway.position.y = params['position'].y

        if params.get('interference', None) is not None:
            gateway.interference = params['interference']

        if params.get('view_mote_ids', None) is not None:
            if params.get('remove_current_view_mote_ids', False):
                gateway._view_mote_ids.clear()
            view_mote_ids_new = [vmi for vmi in params['view_mote_ids'] if vmi in self._motes]
            gateway._view_mote_ids = view_mote_ids_new

        if params.get('expected_packet_count', None) is not None:
            gateway.expected_packet_count = params['expected_packet_count']

        if params.get('power_consumed', None) is not None:
            gateway.power_consumed = params['power_consumed']

        if params.get('packet_store', None) is not None:
            gateway.packet_store.clear()
            for packet_data in params['packet_store']:
                if packet_data:
                    source_mote = self._motes.get(packet_data.src_mote_id)
                    
                    if source_mote and packet_data.dest_gateway_id:
                        packet = Packet(
                            source=source_mote,
                            destination_id=packet_data.dest_gateway_id,
                            number=packet_data.number
                        )
                        gateway.packet_store.append(packet)

        self.log(self._step, self.EVENT, {self.TYPE: self.UPDATE, self.GATEWAY: id})

        return True
    
    # i dont really see this function to reasonably ever be used at least for now, but just in case
    # i addedd all possible checks
    ############# WARNING: DELETING A GATEWAY WILL DELETE ALL MOTES LINKED TO IT OR USING IT AS DIRECTION #############
    def delete_gateway(self, gateway_id: int) -> bool:
        if gateway_id not in self._gateways:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Gateway {gateway_id} not found')

        if len(self._gateways) == 1:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Deleting last gateway is not allowed')

        links_to_delete = [l for l in self.links if l.direction_gateway_id == gateway_id]
        while links_to_delete:
            l = links_to_delete.pop(0)
            if l.dest_node_id == gateway_id:
                src_mote = self._motes.get(l.src_node_id)
                self.log(self._step, self.EVENT, {self.TYPE: self.DELETE, self.LINK: (l.src_node_id, l.dest_node_id)})
                src_mote._links.remove(l)
                if len(src_mote._links) == 0:
                    return self.delete_mote(l.src_node_id)
            else:
                self.delete_link(l.src_node_id, l.dest_node_id)
            links_to_delete = [l for l in self.links if l.direction_gateway_id == gateway_id]

        for mote in self._motes.values():
            mote.packet_queue = [p for p in mote.packet_queue if p.destination_id != gateway_id]

        del self._gateways[gateway_id]

        self.log(self._step, self.EVENT, {self.TYPE: self.DELETE, self.GATEWAY: gateway_id})
        
        return True
from .core import System

from .deltaiot import DeltaIoT
from .disaster_management import DisasterManagement
from .malware_infection import MalwareInfection

from typing import Dict, Type


system_mapping: Dict[str, Type[System]] = {
    DeltaIoT.__name__: DeltaIoT,
    DisasterManagement.__name__: DisasterManagement,
    MalwareInfection.__name__: MalwareInfection
}

from .deltaiot import *
from .malware_infection import *
from .disaster_management import *

from .mappings import system_mapping

import os
from itertools import chain

from joblib import Parallel, delayed

from dataclasses import dataclass

from datetime import datetime, timedelta
import logging

from abc import ABC
from typing import Iterable, List, Union, Optional, Dict

from pysas.common.configurable import ConfigurableMixin


__all__ = ['System', 'SystemAction', 'SystemObserver', 'SystemLogger', 'SystemManager']


class SystemObserver(ConfigurableMixin, ABC):
    _system: Optional['System']

    def __init__(self, *args, system: Optional['System'] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._system = system

    @property
    def system(self):
        return self._system

    @property
    def path(self) -> Optional[str]:
        return self._system.path if self._system is not None else None

    @system.setter
    def system(self, system: Optional['System']):
        logging.debug('Registering system')
        self._system = system
        logging.debug('System registered in observer')

    def start(self):
        raise NotImplementedError()

    def stop(self):
        raise NotImplementedError()

    def __call__(self, *args, **kwargs):
        raise NotImplementedError()


class SystemLogger(SystemObserver):
    STEP: str = 'step'

    def __init__(self, *args, period: int = 1, **kwargs):
        super().__init__(*args, **kwargs)
        self._period: int = period
        self._buffer: List = list()

    def _check_for_flush(self):
        return self._system.step % self._period == 0

    def _flush(self, path: Optional[str]):
        raise NotImplementedError()

    def flush(self):
        logging.debug('Processing data in logger buffer')
        if self.path is not None:
            os.makedirs(self.path, exist_ok=True)
            self._flush(self.path)
            logging.debug('Logger buffer flushed to drive')
        self._buffer.clear()
        logging.debug('Logger buffer cleared')

    def stop(self):
        logging.debug('Stopping logger')
        self.flush()
        logging.debug('Logger')

    def log(self, step: int, entry: str, data):
        data_to_log = {self.STEP: step, entry: data}
        # add timestamp to all entries
        data_to_log['timestamp'] = datetime.now().timestamp()
        self._buffer.append(data_to_log)

    def __call__(self):
        logging.info('Running system logger')
        if self._check_for_flush():
            self.flush()
        logging.info('System logger run complete')


class SystemManager(SystemObserver):
    def __init__(self, *args, checkpoint_period: Optional[int] = None, overwrite_checkpoint: bool = True, **kwargs):
        if checkpoint_period is not None and checkpoint_period < 1:
            raise ValueError('Checkpoint period must be >= 1 or None')

        self._checkpoint_period: Optional[int] = checkpoint_period
        self._overwrite_checkpoint: bool = overwrite_checkpoint

        super().__init__(*args, **kwargs)

    def _check_for_checkpoint(self):
        return self._checkpoint_period is not None and self._system.step % self._checkpoint_period == 0

    def _checkpoint(self, path: str):
        raise NotImplementedError()

    def checkpoint(self, path: Optional[str] = None, checkpoint_id: Optional[str] = None):
        if checkpoint_id is None:
            checkpoint_id = 'checkpoint' if self._overwrite_checkpoint else str(self._system.step).zfill(6) # Assuming no more than 999999 steps
        path = path if path is not None else self.path
        if path is not None:
            logging.debug('Checkpointing manager')
            path = os.path.join(path, self.__class__.__name__.lower(), checkpoint_id)
            os.makedirs(path, exist_ok=True)
            self._checkpoint(path)
            logging.debug(f'Manager checkpoint saved at {path}')

    def stop(self):
        logging.debug('Stopping manager')
        self.checkpoint(path=self._system.path)
        logging.debug('Manager stopped')

    def observe(self):
        raise NotImplementedError()

    def act(self, *args, **kwargs):
        raise NotImplementedError()

    def __call__(self):
        logging.info('Running system manager')
        observation = self.observe()
        self.act(observation)
        if self._check_for_checkpoint():
            self.checkpoint(path=self._system.path)
        logging.info('System manager run complete')


@dataclass
class SystemAction(ABC):
    success: Optional[bool] = None

    @classmethod
    def build_plan(cls, status, plan) -> List['SystemAction']:
        raise NotImplementedError()

    def apply(self, system: 'System', validate_integrity: bool = True):
        raise NotImplementedError()

    def undo(self, system: 'System', validate_integrity: bool = True):
        raise NotImplementedError()

    def __call__(self, *args, **kwargs):
        return self.apply(*args, **kwargs)


class System(ConfigurableMixin, ABC):
    # TODO: consider multiple manager options
    # TODO: consider loggers and observers removal
    # TODO: rename better observer and observers
    # TODO: decide how to approach update (separate manager, logging and other observers?)
    SYSTEM_STATUS: str = 'system_status'
    EVENT: str = 'event'
    TYPE: str = 'type'
    INSERT: str = 'insert'
    UPDATE: str = 'update'
    RESTORE: str = 'restore'
    DELETE: str = 'delete'

    CONCURRENT_TRANSITIONS: bool = False

    def __init__(
            self,
            *args,
            manager: Optional[SystemManager] = None,
            logger: Optional[Union[Iterable[SystemLogger], SystemLogger]] = None,
            observer: Optional[Union[Iterable[SystemObserver], SystemObserver]] = None,
            path: Optional[str] = None,
            clock_period: Optional[float] = None,
            seed: Optional[int] = None,
            fail_silent: bool = True,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        if manager is not None:
            manager.system = self
        self._manager: Optional[SystemManager] = manager
        if logger is not None:
            if isinstance(logger, SystemLogger):
                logger = [logger]
            else:
                logger = [*logger]
            for l in logger:
                l.system = self
        else:
            logger = list()
        self._logger: List[SystemLogger] = logger
        if observer is not None:
            if isinstance(observer, SystemObserver):
                observer = [observer]
            else:
                observer = [*observer]
            for o in observer:
                o.system = self
        else:
            observer = list()
        self._observer: List[SystemObserver] = observer

        self._path: Optional[str] = path  # Make it a temporary path to avoid data losses?

        self._clock_period: Optional[float] = clock_period
        self._last_clock_reset: Optional[datetime] = None
        self._step = 0

        self._seed: Optional[int] = seed
        self._fail_silent: bool = fail_silent

    def clone(self, reset: bool = True) -> 'System':
        raise NotImplementedError()

    def reset(self):
        raise NotImplementedError()

    @property
    def step(self) -> int:
        return self._step

    @property
    def manager(self) -> Optional[SystemManager]:
        return self._manager

    @manager.setter
    def manager(self, manager: SystemManager):
        logging.debug('Registering new system manager' if self._manager is not None else 'Registering system manager')
        if self._manager is not None:
            self._manager.system = None
        manager.system = self
        self._manager = manager
        logging.debug('System manager registered')

    @property
    def logger(self) -> List[SystemLogger]:
        return self._logger

    @logger.setter
    def logger(self, logger: Union[Iterable[SystemLogger], SystemLogger]):
        if isinstance(logger, SystemLogger):
            logger = [logger]
        else:
            logger = [*logger]
        for l in logger:
            l.system = self
        self._logger.extend(logger)

    @property
    def observer(self) -> List[SystemObserver]:
        return self._observer

    @observer.setter
    def observer(self, observer: Union[Iterable[SystemObserver], SystemObserver]):
        logging.debug(f'Registering new system observer(s)')
        if isinstance(observer, SystemObserver):
            observer = [observer]
        else:
            observer = [*observer]
        for o in observer:
            o.system = self
        self._observer.extend(observer)
        logging.debug(f'New system observer(s) registered')

    @property
    def observers(self) -> Iterable[SystemObserver]:
        return chain([self._manager] if self._manager is not None else list(), self._logger, self._observer)

    def _check_integrity(self) -> bool:
        raise NotImplementedError()

    def execute(self, plan: List[Optional[SystemAction]]) -> bool:
        Parallel(backend='threading', n_jobs=-1 if self.CONCURRENT_TRANSITIONS else 1)(
            delayed(action)(self, validate_integrity=False)
            for action in plan if action is not None
        )
        valid: bool = self._check_integrity()
        if not valid:
            logging.error('System network integrity violated after applying actions, reverting to previous state.')
            Parallel(backend='threading', n_jobs=-1 if self.CONCURRENT_TRANSITIONS else 1)(
                delayed(action.undo)(self, validate_integrity=False)
                for action in plan if action is not None
            )

        return valid

    @property
    def path(self) -> Optional[str]:
        return self._path

    @property
    def time_to_next_clock_reset(self) -> Optional[timedelta]:
        if self._clock_period is not None and self._last_clock_reset is not None:
            return timedelta(seconds=self._clock_period) - (datetime.now() - self._last_clock_reset)
        else:
            return None

    def _run_step(self):
        raise NotImplementedError()

    def _start(self):
        logging.debug(f'Signaling system start to observers')
        for observer in self.observers:
            observer.start()
        logging.debug(f'Start signals sent')

    def _update(self):
        logging.debug(f'Updating system observers')
        for observer in self.observers:
            observer()
        logging.debug('System observers updated')

    def _stop(self):
        logging.debug(f'Signaling system stop to obsersers')
        for observer in self.observers:
            observer.stop()
        logging.debug(f'Stop signals sent')

    def _status_dict(self) -> Dict:
        raise NotImplementedError()

    def _log_status(self):
        logging.debug(f'Logging system status')
        self.log(self._step, self.SYSTEM_STATUS, self._status_dict())
        logging.debug(f'System status logged')

    def log(self, *args, **kwargs):
        # TODO add filters on loggers
        logging.debug(f'Logging to system loggers')
        for logger in self.logger:
            logger.log(*args, **kwargs)
        logging.debug(f'Logging completed')

    def run_step(self):
        logging.debug(f'Starting system step')
        self._run_step()
        self._last_clock_reset = datetime.now()
        self._step += 1
        self._log_status()
        self._update()
        logging.debug('System step completed')

    def run(self, num_steps: int):
        logging.info(f'Running system for {num_steps} steps')
        self._start()
        self._log_status()
        self._update()

        for i in range(num_steps):
            self.run_step()
            logging.info(f'Run {i + 1}/{num_steps} step(s)')

        self._stop()

    def run_indefinitely(self):
        logging.info('Running system indefinitely (use keyboard interrupt or send SIGTERM to stop)')
        self._start()
        self._log_status()
        self._update()

        running: bool =True
        while running:
            try:
                self.run_step()
            except KeyboardInterrupt:
                logging.info(f'Stopping signal received')
                running = False

        self._stop()

    def __call__(self, num_steps: Optional[int] = None):
        logging.info(f'Starting system run')
        if num_steps is None:
            self.run_indefinitely()
        else:
            self.run(num_steps)
        logging.info('System run completed')

import logging
from copy import deepcopy

import numpy as np
import scipy.sparse as sp
from dataclasses import dataclass, asdict
from typing import Optional, List, Dict, Literal, Tuple

from .data import *
from .utils import compute_metrics
from ..core import System, SystemAction


__all__ = ['DisasterManagement', 'DisasterManagementAction']


@dataclass(kw_only=True)
class DisasterManagementAction(SystemAction):
    team: int | None = None
    edge: Tuple[int, int] | None = None
    resources: int | None = None

    @classmethod
    def build_plan(
            cls, status: DisasterManagementStatus, plan: List[Optional[Tuple[int, Tuple[int, int], int]]]
    ) -> List['DisasterManagementAction']:
        actions = []
        for action in plan:
            if action is not None:
                team, edge, resources = action
                actions.append(cls(team=team, edge=edge, resources=resources))

        return actions

    def apply(self, system: 'DisasterManagement', validate_integrity: bool = True):
        self.success = system.move_resources(self.team, self.edge, self.resources)

    def undo(self, system: 'DisasterManagement', validate_integrity: bool = True):
        if self.success is None:
            raise RuntimeError('Action not yet applied')
        if not self.success:
            return

        system.resources_allocation[self.edge[0]] -= self.resources
        if system.teams_allocation[self.team] >= 0:
            system.resources_allocation[self.edge[1]] -= self.resources
        system.teams_allocation[self.team] = self.edge[0]


class DisasterManagement(System):
    R: float = 0.40
    Y: float = 0.85
    G: float = 0.99

    MAX_RES = 3

    LABELS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    
    CONCURRENT_TRANSITIONS: bool = False

    def __init__(
            self,
            *args,
            deterministic: bool = False,
            **kwargs
    ):
        self._adjacency_matrix: sp.csr_matrix | None = None
        self._transition_probability_matrix: sp.csr_matrix | None = None
        self._resources_allocation: np.ndarray | None = None
        self._teams_allocation: np.ndarray | None = None
        self._target_allocation: np.ndarray | None = None

        self._deterministic: bool = deterministic

        super().__init__(*args, **kwargs)

        if self._seed is not None:
            self._random = np.random.RandomState(self._seed)
        else:
            self._random = np.random.RandomState()

    @classmethod
    def _create_from_status_dict(cls, system: 'DisasterManagement', status_dict: Dict) -> 'DisasterManagement':
        status: DisasterManagementStatus = DisasterManagementStatus.from_dict(status_dict)

        system._adjacency_matrix = status.adjacency_matrix
        system._transition_probability_matrix = status.transition_probability_matrix
        system._resources_allocation = status.resources_allocation
        system._teams_allocation = status.teams_allocation
        system._target_allocation = status.target_allocation

        return system

    @classmethod
    def _create_base_case(cls, system: 'DisasterManagement') -> 'DisasterManagement':
        system._adjacency_matrix = sp.csr_matrix(
        (
                [1, 2, 9, 1, 5, 2, 5, 3, 2, 9, 3, 5, 1, 2, 3, 4, 3, 2, 5, 4, 2, 3, 1, 3],  # Data
                (
                    [0, 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7],  # Row index
                    [1, 2, 3, 0, 2, 0, 1, 3, 4, 0, 2, 6, 7, 2, 5, 6, 4, 6, 3, 4, 5, 7, 3, 6]   # Column index
                )
            ),
            shape=(8, 8),
            dtype=np.float32
        )
        R = cls.R
        Y = cls.Y
        G = cls.G
        system._transition_probability_matrix = sp.csr_matrix(
            (
                [R, Y, G, R, G, Y, G, R, R, G, R, G, R, R, Y, R, Y, Y, G, R, Y, G, R, G],  # Data
                (
                    [0, 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7],  # Row index
                    [1, 2, 3, 0, 2, 0, 1, 3, 4, 0, 2, 6, 7, 2, 5, 6, 4, 6, 3, 4, 5, 7, 3, 6]   # Column index
                )
            ),
            shape=(8, 8),
            dtype=np.float32
        )
        system._resources_allocation = np.array([0, 2, 0, 0, 2, 3, 0, 0], dtype=np.float32)
        system._teams_allocation = np.array([0, 5], dtype=np.int32)
        system._target_allocation = np.array([3, 0, 0, 0, 0, 0, 0, 2], dtype=np.float32)

        return system

    @classmethod
    def load_from_configs(
            cls,
            *args,
            initial_status_dict: Optional[Dict] = None,
            deterministic: bool = False,
            **kwargs,
    ) -> 'DisasterManagement':
        system = super().load_from_configs(*args, **kwargs)
        if initial_status_dict is not None:
            system = cls._create_from_status_dict(system, initial_status_dict)
        else:
            system = cls._create_base_case(system)

        system._deterministic = deterministic

        return system

    def _log_status(self):
        logging.debug(f'Logging system status')
        self.log(self._step, self.SYSTEM_STATUS, asdict(compute_metrics(self.status)))
        logging.debug(f'System status logged')

    def clone(self, reset: bool = True, reset_seed: bool = True):
        raise NotImplementedError()

    def reset(self):
        raise NotImplementedError()

    def __str__(self):
        s = 'Status'
        for idx, (l, r, t) in enumerate(
                zip(self.LABELS, self._resources_allocation, self._target_allocation)):
            s += f'\n\tLocation {l}:'
            s += f'\n\t\tResources: {r}'
            if t > 0:
                s += f'\n\t\tTarget: {t}'
            if any(pos == idx for pos in self._teams_allocation):
                teams = [str(team_idx + 1) for team_idx, pos in enumerate(self._teams_allocation) if pos == idx]
                s += f'\n\t\tTeam(s): {", ".join(teams)}'

        return s

    def _run_step(self):
        pass

    @property
    def step(self):
        return self._step

    @step.setter
    def step(self, value: int):
        self._step = value

    @property
    def seed(self):
        return self._seed

    @seed.setter
    def seed(self, seed: int | None):
        if seed is not None:
            self._random = np.random.RandomState(seed)
        else:
            self._random = np.random.RandomState()

    @property
    def status(self) -> DisasterManagementStatus:
        return DisasterManagementStatus(
            self._adjacency_matrix,
            self._transition_probability_matrix,
            self._resources_allocation,
            self._teams_allocation,
            self._target_allocation
        )

    def _status_dict(self) -> Dict:
        return asdict(self.status)

    @property
    def nodes(self) -> int:
        return len(self._resources_allocation)
    
    @property
    def adjacency_matrix(self) -> sp.csr_matrix:
        return self._adjacency_matrix

    @property
    def transition_probability_matrix(self) -> sp.csr_matrix:
        return self._transition_probability_matrix

    @property
    def resources_allocation(self) -> np.ndarray:
        return self._resources_allocation

    @property
    def teams_allocation(self) -> np.ndarray:
        return self._teams_allocation

    @property
    def target_allocation(self) -> np.ndarray:
        return self._target_allocation

    def _check_integrity(self) -> bool:
        return True
    
    def execute(self, plan: List[Optional[SystemAction]]) -> bool:
        """Execute a plan of actions."""
        # Clone current simulator for rollback
        status = deepcopy(self.status)
        
        # Apply all actions
        try:
            # Parallel(backend='threading', n_jobs=-1 if self.CONCURRENT_TRANSITIONS else 1)(
            #     delayed(action)(self, validate_integrity=False)
            #     for action in plan if action is not None
            # )
            for action in plan:
                if action is not None:
                    action(self, validate_integrity=False)

            valid_actions: bool = self._check_integrity()

            if valid_actions:
                logging.debug('Action plan executed successfully')
            else:
                # Restore original simulator
                self._adjacency_matrix = status.adjacency_matrix
                self._transition_probability_matrix = status.transition_probability_matrix
                self._resources_allocation = status.resources_allocation
                self._teams_allocation = status.teams_allocation
                self._target_allocation = status.target_allocation
                logging.error('System simulator integrity would be violated after applying actions, keeping original state.')

            return valid_actions
            
        except Exception as e:
            # Restore original simulator on any error
            self._adjacency_matrix = status.adjacency_matrix
            self._transition_probability_matrix = status.transition_probability_matrix
            self._resources_allocation = status.resources_allocation
            self._teams_allocation = status.teams_allocation
            self._target_allocation = status.target_allocation
            logging.error(f'Error executing action plan: {e}')
            return False

    def enumerate_actions(self) -> List[DisasterManagementAction]:
        return [
            DisasterManagementAction(team=t, edge=(s_idx.item(), e_idx.item()), resources=r)
            for t in range(len(self._teams_allocation))
            for s_idx, e_idx in zip(*self._adjacency_matrix.nonzero())
            for r in range(self.MAX_RES + 1)
        ]


    def validate_action(self, action: DisasterManagementAction) -> bool:
        if (
                self._teams_allocation[action.team] == -1 or
                self._teams_allocation[action.team] != action.edge[0] or
                self.adjacency_matrix[*action.edge] == 0 or
                self.resources_allocation[action.edge[0]] < action.resources or
                action.resources > self.MAX_RES
        ):
            return False
        else:
            return True


    def move_resources(self, team: int, edge: Tuple[int, int], resources: int) -> bool:
        u, v = edge
        if self._teams_allocation[team] == -1:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Team {team + 1} is not available')
        elif self._teams_allocation[team] != u:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Team {team + 1} is not assigned to location {self.LABELS[u]}')
        elif self.adjacency_matrix[u, v] == 0:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Edge between location {self.LABELS[u]} and location {self.LABELS[v]} is not available')
        elif self.resources_allocation[u] < resources:
            if self._fail_silent:
                return False
            raise RuntimeError(
                f'Not enough resources to move {resources} from location {self.LABELS[u]} to location {self.LABELS[v]}'
            )
        elif resources > self.MAX_RES:
            if self._fail_silent:
                return False
            raise RuntimeError(f'Cannot move more than {self.MAX_RES} resources at once')

        self.resources_allocation[u] -= resources
        if self._deterministic or self._random.rand() < self.transition_probability_matrix[u, v]:

            self.resources_allocation[v] += resources
            self._teams_allocation[team] = v
        else:
            self._teams_allocation[team] = -1

        return True

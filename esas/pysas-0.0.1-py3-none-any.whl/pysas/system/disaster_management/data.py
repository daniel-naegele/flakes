from dataclasses import dataclass

import numpy as np
import scipy.sparse as sp
from typing import List, Dict, Union


__all__ = ['DisasterManagementStatus', 'DisasterManagementQoS']


@dataclass
class DisasterManagementStatus:
    adjacency_matrix: sp.csr_matrix
    transition_probability_matrix: sp.csr_matrix
    resources_allocation: np.ndarray
    teams_allocation: np.ndarray
    target_allocation: np.ndarray

    @property
    def status_df(self):
        raise NotImplementedError()

    @classmethod
    def from_dict(cls, data: Dict) -> 'DisasterManagementStatus':
        raise NotImplementedError()

@dataclass
class DisasterManagementQoS:
    available_resources: float
    available_teams: float
    completion: float

    @property
    def values(self) -> List[float]:
        return [self.available_resources, self.available_teams, self.completion]

    @property
    def keys(self) -> List[str]:
        return ['available_resources', 'available_teams', 'completion']

    def __get__(self, index: Union[int, str]) -> float:
        if isinstance(index, int):
            return self.values[index]
        elif isinstance(index, str):
            return getattr(self, index)
        else:
            raise ValueError(f'Invalid index {index}')

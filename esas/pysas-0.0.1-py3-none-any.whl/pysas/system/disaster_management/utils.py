import numpy as np
from .data import DisasterManagementStatus, DisasterManagementQoS


__all__ = ['compute_metrics', 'compute_available_resources', 'compute_available_teams', 'compute_completion']


def compute_available_resources(status: DisasterManagementStatus) -> float:
    return float(np.sum(status.resources_allocation))


def compute_available_teams(status: DisasterManagementStatus) -> float:
    return float(np.sum(status.teams_allocation >= 0))


def compute_completion(status: DisasterManagementStatus) -> float:
    return float(
        np.all(np.minimum(status.resources_allocation, status.target_allocation) >= status.target_allocation).item()
    )


def compute_metrics(status: DisasterManagementStatus) -> DisasterManagementQoS:
    return DisasterManagementQoS(
        compute_available_resources(status), compute_available_teams(status), compute_completion(status)
    )

import torch
import torch.nn as nn
import torch.nn.functional as F


__all__ = ['SymmetricBilinear']


class SymmetricBilinear(nn.Bilinear):
    def __init__(self, in_features: int, out_features: int, **kwargs) -> None:
        super().__init__(in_features, in_features, out_features, **kwargs)

    def reset_parameters(self) -> None:
        super().reset_parameters()
        with torch.no_grad():
            self.weight.data = self.weight.data.triu()

    def forward(self, input1: torch.Tensor, input2: torch.Tensor) -> torch.Tensor:
        return F.bilinear(input1, input2, self.weight.triu() + self.weight.triu().mT, self.bias)

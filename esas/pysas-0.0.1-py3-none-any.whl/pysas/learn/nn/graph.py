import torch
import torch.nn as nn
import torch_geometric.nn as gnn
from torch.amp import autocast
from .common import SymmetricBilinear

from torch_geometric.data import Data

from typing import Optional, Union, Dict


__all__ = [
    'GraphNNEstimator',
    'EdgeEstimator',
    'LinearEdgeEstimator',
    'EdgeData',
    'NodePairEstimator',
    'LinearNodePairEstimator'
]


class EdgeData(Data):
    def __inc__(self, key, value, *args, **kwargs):
        if key == 'nen_index':
            return self.x.size(0)
        return super().__inc__(key, value, *args, **kwargs)


class GraphBlock(nn.Module):
    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            *args, 
            norm: bool = True,
            dropout_rate: float = 0.1,
            residual: bool = False,
            half_precision: bool = True,
            **kwargs
        ):
        super().__init__(*args, **kwargs)
        self._half_precision = half_precision
        self._norm: Optional[nn.Module] = nn.LayerNorm(in_channels) if norm else None
        self._conv: gnn.SAGEConv = gnn.SAGEConv(in_channels, out_channels, bias=not norm)
        self._act_fn: nn.ReLU = nn.ReLU()  # TODO make this configurable
        self._dropout: nn.Dropout = nn.Dropout(p=dropout_rate)
        self._residual: bool = residual

    @property
    def in_channels(self) -> int:
        return self._conv.in_channels

    @property
    def out_channels(self) -> int:
        return self._conv.out_channels

    def forward(self, x: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        with autocast('cuda', enabled=self._half_precision, cache_enabled=True):
            h = self._dropout(x)
            if self._norm is not None:
                h = self._norm(h.float())  # LayerNorm requires float32
            h = self._conv(h, *args, **kwargs)
            h = self._act_fn(h)
            h = self._dropout(h)

            if self._residual:
                return h + x
            else:
                return h


class GraphNN(nn.Module):
    def __init__(
            self, 
            in_channels: int,
            *args,
            hidden_channels: Optional[int] = None,
            n_layers: Optional[int] = 1,
            norm: bool = True,
            dropout_rate: float = 0.1,
            residual: bool = False,
            half_precision: bool = True,
            **kwargs
        ):
        if hidden_channels is None:
            hidden_channels = in_channels
        super().__init__(*args, **kwargs)
        self._half_precision = half_precision
        self._input_proj: nn.Linear = nn.Linear(in_channels, hidden_channels)
        self._act_fn: Optional[nn.ReLU] = nn.ReLU() if not residual or n_layers is None or n_layers == 0 else None  # Prevent liner dependencies
        self._layers: Optional[nn.ModuleList] = nn.ModuleList([
            GraphBlock(hidden_channels, hidden_channels, norm=norm, dropout_rate=dropout_rate, residual=residual, half_precision=half_precision)
            for _ in range(n_layers)
        ]) if n_layers is not None else None

    @property
    def in_channels(self) -> int:
        return self._input_proj.in_features

    @property
    def out_channels(self) -> int:
        if self._layers is not None and len(self._layers) > 0:
            return self._layers[-1].out_channels
        else:
            return self._input_proj.out_features

    def forward(self, x: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        with autocast('cuda', enabled=self._half_precision, cache_enabled=True):
            h = self._input_proj(x)
            if self._act_fn is not None:
                h = self._act_fn(h)
            if self._layers is not None:
                for layer in self._layers:
                    h = layer(h, *args, **kwargs)
            return h


class GraphNNHead(nn.Module):
    def __init__(
            self,
            in_channels: int,
            *args,
            norm: bool = True,
            dropout_rate: float = 0.1,
            half_precision: bool = True,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._half_precision = half_precision
        self._dropout: nn.Dropout = nn.Dropout(p=dropout_rate)
        self._norm: Optional[nn.Module] = nn.LayerNorm(in_channels) if norm else None

    @property
    def in_channels(self) -> int:
        raise NotImplementedError()

    @property
    def out_channels(self) -> Union[Dict[str, int], int]:
        raise NotImplementedError()

    def forward(self, h: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        with autocast('cuda', enabled=self._half_precision, cache_enabled=True):
            h = self._dropout(h)
            if self._norm is not None:
                h = self._norm(h.float())
            return h


class GraphNNEstimator(nn.Module):
    _head: Optional[Union[GraphNNHead, nn.ModuleDict]]

    def __init__(
            self,
            in_channels: int,
            *args,
            hidden_channels: Optional[int] = None,
            n_layers: Optional[int] = None,
            norm: bool = True,
            dropout_rate: float = 0.1,
            residual: bool = False,
            half_precision: bool = True,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._half_precision = half_precision
        self._gnn: Optional[GraphNN] = GraphNN(
            in_channels, hidden_channels=hidden_channels, n_layers=n_layers, norm=norm, dropout_rate=dropout_rate, residual=residual, half_precision=half_precision
        ) if hidden_channels is not None or n_layers is not None else None
        self._head = None

    @property
    def in_channels(self) -> int:
        return self._gnn.in_channels if self._gnn is not None else self._head.in_channels

    @property
    def hidden_channels(self) -> Optional[int]:
        return self._head.in_channels

    @property
    def out_channels(self) -> Union[Dict[str, int], int]:
        return self._head.out_channels if isinstance(
            self._head, GraphNNHead
        ) else {k: h.out_channels for k, h in self._head.items()}

    @property
    def multioutput(self) -> bool:
        return not isinstance(self._head, GraphNNHead)

    def forward(
            self, x: torch.tensor, *args, **kwargs
        ) -> Union[torch.Tensor, Dict[str, torch.Tensor]]:
        h = self._gnn(x, *args, **kwargs) if self._gnn is not None else x

        return h


class EdgeHead(GraphNNHead):
    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            *args,
            norm: bool = True,
            undirected: bool = False,
            **kwargs
        ):
        super().__init__(in_channels, *args, norm=norm, **kwargs)
        self._undirected: bool = undirected
        self._out_proj: nn.Linear = nn.Linear(in_channels * 3, out_channels, bias=not norm)

    @property
    def in_channels(self) -> int:
        return self._out_proj.in_features

    @property
    def out_channels(self) -> Union[Dict[str, int], int]:
        return self._out_proj.out_features

    def forward(self, h: torch.Tensor, nen_index: torch.LongTensor, *args, **kwargs) -> torch.Tensor:
        with autocast('cuda', enabled=self._half_precision, cache_enabled=True):
            h = super().forward(h, *args, **kwargs)
            y = self._out_proj(torch.hstack([h[idx] for idx in nen_index]))
            if self._undirected:
                y = (y + self._out_proj(torch.hstack([h[idx] for idx in nen_index.flipud()]))) / 2

            return y


class EdgeEstimator(GraphNNEstimator):
    _head: Union[EdgeHead, nn.ModuleDict]

    def __init__(
            self, 
            in_channels: int,
            out_channels: Union[int, Dict[str, int]],
            *args,
            hidden_channels: Optional[int] = None,
            norm: bool = True,
            dropout_rate: float = 0.1,
            undirected: bool = False,
            **kwargs
        ):
        super().__init__(
            in_channels, *args, hidden_channels=hidden_channels, norm=norm, dropout_rate=dropout_rate, **kwargs
        )
        self._head: Union[EdgeHead, nn.ModuleDict] = EdgeHead(
            hidden_channels if hidden_channels is not None else in_channels, out_channels, norm=norm, dropout_rate=dropout_rate, undirected=undirected
        ) if isinstance(out_channels, int) else nn.ModuleDict({
            k: EdgeHead(hidden_channels if hidden_channels is not None else in_channels, oc, norm=norm, dropout_rate=dropout_rate, undirected=undirected)
            for k, oc in out_channels.items()
        })
    
    def forward(
            self, x: torch.tensor, nen_index: torch.LongTensor, *args, **kwargs
        ) -> Union[torch.Tensor, Dict[str, torch.Tensor]]:
        h = super().forward(x, *args, **kwargs)
        y = {k: head(h, nen_index) for k, head in self._head.items()} if self.multioutput else self._head(h, nen_index)

        return y


class LinearEdgeEstimator(EdgeEstimator):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, hidden_channels=None, n_layers=None, **kwargs)


class NodePairHead(GraphNNHead):
    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            *args,
            norm: bool = True,
            **kwargs
        ):
        super().__init__(in_channels, *args, norm=norm, **kwargs)
        self._out_proj: SymmetricBilinear = SymmetricBilinear(in_channels, out_channels, bias=not norm)

    @property
    def in_channels(self) -> int:
        return self._out_proj.in_features

    @property
    def out_channels(self) -> Union[Dict[str, int], int]:
        return self._out_proj.out_features

    def forward(self, h: torch.Tensor, edge_index: torch.LongTensor) -> torch.Tensor:
        with autocast('cuda', enabled=self._half_precision, cache_enabled=True):
            h = super().forward(h)
            mask = edge_index[1] >= edge_index[0]
            y = self._out_proj(h[edge_index[0, mask]], h[edge_index[1, mask]])
            return y


class NodePairEstimator(GraphNNEstimator):
    _head: Union[NodePairHead, nn.ModuleDict]

    def __init__(
            self,
            in_channels: int,
            out_channels: Union[int, Dict[str, int]],
            *args,
            hidden_channels: Optional[int] = None,
            norm: bool = True,
            dropout_rate: float = 0.1,
            **kwargs
    ):
        super().__init__(in_channels, *args, hidden_channels=hidden_channels, norm=norm, dropout_rate=dropout_rate, **kwargs)
        self._head: Union[NodePairHead, nn.ModuleDict] = NodePairHead(
            hidden_channels if hidden_channels is not None else in_channels, out_channels, norm=norm, dropout_rate=dropout_rate
        ) if isinstance(out_channels, int) else nn.ModuleDict({
            k: NodePairHead(hidden_channels if hidden_channels is not None else in_channels, oc, norm=norm, dropout_rate=dropout_rate)
            for k, oc in out_channels.items()
        })

    def forward(
            self, x: torch.tensor, *args, edge_index = None, **kwargs
    ) -> Union[torch.Tensor, Dict[str, torch.Tensor]]:
        if edge_index is None:
            raise ValueError()

        h = super().forward(x, *args, edge_index=edge_index, **kwargs)
        y = {k: head(h, edge_index) for k, head in self._head.items()} if self.multioutput else self._head(h, edge_index)

        return y

class LinearNodePairEstimator(NodePairEstimator):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, hidden_channels=None, n_layers=None, **kwargs)

import numpy as np
import pandas as pd

from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder, MinMaxScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from .core import SoftClipTransformer, ComplementTransformer, SigmoidTransformer

from typing import Dict, Optional, Iterable, Literal

__all__ = ['DeltaIoTStatusTransformer', 'DeltaIoTActionTransformer', 'DeltaIoTRewardTransformer']




class DeltaIoTStatusTransformer(TransformerMixin, BaseEstimator):
    def __init__(self, *args, transformer: Optional[TransformerMixin] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._transformer = transformer if transformer is not None else ColumnTransformer(
            transformers=[
                ('standardised', StandardScaler(), ['interference', 'position_coord_x', 'position_coord_y', 'view_size']),
                ('minmax', MinMaxScaler(), ['power', 'turn_order']),
                ('ohe', OneHotEncoder(), ['type']),
                ('invscaled', Pipeline(
                    [('standardised', StandardScaler()), ('clipped', SigmoidTransformer())]
                ), ['packet_queue_size', 'packet_store_size', 'expected_packets']),
                ('passthrough', 'passthrough', ['battery', 'distribution', 'snr'])
            ]
        )

    def _pre_process(self, x: pd.DataFrame):
        return x[x['type'] != 'network']

    def _post_process(self, x: np.ndarray):
        return np.nan_to_num(x)

    def fit(self, X, y=None):
        self._transformer = self._transformer.fit(self._pre_process(X))

        return self

    def _transform(self, x):
        x = self._pre_process(x)
        
        x = x.copy()
        x.replace([np.inf, -np.inf], np.nan, inplace=True)
        
        id_mapping = {k: i for i, k in enumerate(x['id'])}
        edge_index = np.array([
            [i, j]
            for (src_id, dest_id) in x[x['type'] == 'link']['id'].values
            for i, j in [
                [id_mapping[src_id], id_mapping[(src_id, dest_id)]],
                [id_mapping[(src_id, dest_id)], id_mapping[dest_id]]
            ]
        ])
        nen_index = np.array([
            [id_mapping[src_id], id_mapping[(src_id, dest_id)], id_mapping[dest_id]]
            for (src_id, dest_id) in x[x['type'] == 'link']['id'].values
        ])
        x = self._transformer.transform(x).astype(np.float32)
        x = self._post_process(x)

        return x, edge_index, nen_index

    def transform(self, X):
        return [self._transform(x) for x in X]


class DeltaIoTActionTransformer(TransformerMixin, BaseEstimator):
    # Link order should be the same between status encoder, action encoder and status DF
    def __init__(self, *args, label_encoders: Optional[Dict[str, TransformerMixin]] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.label_encoders: Optional[Dict[str, LabelEncoder]] = label_encoders

    def fit(self, X, y=None):
        self.label_encoders = {k: LabelEncoder().fit(a) for k, a in X.items()}

        return self

    def transform(self, X):
        return [{k: le.transform(x[k]) for k, le in self.label_encoders.items()} for x in X]

    def inverse_transform(self, X):
        return [{k: le.inverse_transform(x[k]) for k, le in self.label_encoders.items()} for x in X]


class DeltaIoTRewardTransformer(TransformerMixin, BaseEstimator):
    def __init__(
            self,
            *args,
            transformer: Optional[TransformerMixin] = None,
            weights: Optional[Iterable[float]] = None,  # (0.2, 0.8, 0.0),
            idxs: Optional[Iterable[int]] = (0, 1),
            reduction: Literal['sum', 'mean', 'min'] = 'min',
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._transformer = transformer if transformer is not None else ColumnTransformer(
            transformers=[
                ('minimize', Pipeline([
                    ('columns', ColumnTransformer(
                        transformers=[
                            ('norm', Pipeline(
                                [('standardised', StandardScaler()), ('clipped', SigmoidTransformer())]
                            ), ['cumulative_energy_consumption']),
                            ('minmax', MinMaxScaler(clip=True), ['average_packet_loss'])
                        ]
                    )),
                    ('inverter', ComplementTransformer())
                ]), ['cumulative_energy_consumption', 'average_packet_loss']),
                ('passthrough', 'passthrough', ['network_fairness_index'])
            ]
        )
        self._weights: Optional[np.ndarray] = np.array(weights, dtype=np.float32) if weights is not None else None
        self._idxs: Optional[np.ndarray] = np.array(idxs) if idxs is not None else None
        self._reduction: Literal['sum', 'mean', 'min'] = reduction

    def fit(self, X, y=None):
        self._transformer.fit(X)
        return self

    def transform(self, X, scalarise: bool = True):
        X = self._transformer.transform(X).astype(np.float32)
        if scalarise:
            if self._idxs is not None:
                X = X[:, self._idxs]
            if self._weights is not None:
                X = X * self._weights
            if self._reduction == 'sum':
                X = X.sum(axis=1)
            elif self._reduction == 'mean':
                X = X.mean(axis=1)
            elif self._reduction == 'min':
                X = X.min(axis=1)
            else:
                raise ValueError()
        return X

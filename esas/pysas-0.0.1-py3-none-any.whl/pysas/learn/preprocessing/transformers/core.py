import numpy as np
from scipy.special import expit

from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.preprocessing import LabelEncoder

from typing import List, Optional


__all__ = [
    'MultiOutputLabelEncoder',
    'ComplementTransformer',
    'SoftClipTransformer',
    'SigmoidTransformer',
    'MaxScaler',
    'MaxShifter',
    'ThresholdTransformer'
]


# TODO rewrite these transformers


class SoftClipTransformer(TransformerMixin, BaseEstimator):
    def fit(self, X, y=None):
        self.n_features_in_ = X.shape[1]  # Explicitly set this
        return self

    def transform(self, X):
        return X / (1. + np.abs(X))


class SigmoidTransformer(TransformerMixin, BaseEstimator):
    def fit(self, X, y=None):
        self.n_features_in_ = X.shape[1]  # Explicitly set this
        return self

    def transform(self, X):
        return expit(X)


class MaxScaler(TransformerMixin, BaseEstimator):
    def __init__(self):
        self.max = None

    def fit(self, X, y=None):
        self.max = X.max(axis=0)
        return self

    def transform(self, X):
        return X / self.max


class MaxShifter(TransformerMixin, BaseEstimator):
    def __init__(self):
        self.max = None

    def fit(self, X, y=None):
        self.max = X.max(axis=0)
        return self

    def transform(self, X):
        return X - self.max


class ComplementTransformer(TransformerMixin, BaseEstimator):
    def fit(self, X, y=None):
        self.n_features_in_ = X.shape[1]  # Explicitly set this
        return self

    def transform(self, X):
        return 1 - X


class ThresholdTransformer(TransformerMixin, BaseEstimator):
    def __init__(self, threshold: Optional):
        self.threshold = threshold

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X - self.threshold if self.threshold is not None else X


class MultiOutputLabelEncoder(TransformerMixin, BaseEstimator):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.label_encoders: List[LabelEncoder] = list()

    def fit(self, X, y=None):
        self.label_encoders = [LabelEncoder().fit(x) for x in [*zip(*X)]]

        return self

    def transform(self, X):
        return np.vstack([le.transform(x) for le, x in zip(self.label_encoders, [*zip(*X)])]).T

    def inverse_transform(self, X):
        return [*zip(*[le.inverse_transform(x) for le, x in zip(self.label_encoders, X.T)])]

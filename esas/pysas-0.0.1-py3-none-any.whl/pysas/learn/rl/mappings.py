from .core import Agent, Environment

from .agent import *
from .environment import *

from typing import Dict, Type


agent_mapping: Dict[str, Type[Agent]] = {
    LinearQN.__name__: LinearQN,
    GraphDQN.__name__: GraphDQN
}

environment_mapping: Dict[str, Type[Environment]] = {
    DeltaIoTEnvironment.__name__: DeltaIoTEnvironment,
    DeltaIoTPerturbedEnvironment.__name__: DeltaIoTPerturbedEnvironment,
    MalwareInfectionEnvironment.__name__: MalwareInfectionEnvironment,
    MalwareInfectionPerturbedEnvironment.__name__: MalwareInfectionPerturbedEnvironment
}

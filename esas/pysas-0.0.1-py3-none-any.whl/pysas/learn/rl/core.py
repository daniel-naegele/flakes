from abc import ABC

from joblib import Parallel, delayed

import numpy as np
from sklearn.base import TransformerMixin

from pysas.system.core import System, SystemAction

from typing import Optional, Union, Dict, List, Tuple, Iterable, Type, Literal


__all__ = ['Agent', 'Environment']


class Environment:
    _ACTION_DTYPE: Type[SystemAction] = SystemAction

    _reference_system: System
    _systems: List[System]
    _status_transformer: TransformerMixin
    _action_transformer: TransformerMixin
    _reward_transformer: TransformerMixin

    def __init__(
            self,
            system: System,
            status_transformer: TransformerMixin,
            action_transformer: TransformerMixin,
            reward_transformer: TransformerMixin,
            *args,
            violation_penalty: float = -1.,
            **kwargs
    ):
        super().__init__(*args, **kwargs)

        self._reference_system = system
        self._systems = [self._reference_system.clone()]
        self._eval_system = self._reference_system.clone()
        self._status_transformer = status_transformer
        self._action_transformer = action_transformer
        self._reward_transformer = reward_transformer

        self._violation_penalty: float = violation_penalty
        self._success: List[bool] = [True]

        self._training: bool = True

    @property
    def status_transformer(self):
        return self._status_transformer
    
    @status_transformer.setter
    def status_transformer(self, status_transformer: TransformerMixin):
        self._status_transformer = status_transformer
    
    @property
    def action_transformer(self):
        return self._action_transformer
    
    @action_transformer.setter
    def action_transformer(self, action_transformer: TransformerMixin):
        self._action_transformer = action_transformer
    
    @property
    def reward_transformer(self):
        return self._reward_transformer
    
    @reward_transformer.setter
    def reward_transformer(self, reward_transformer: TransformerMixin):
        self._reward_transformer = reward_transformer

    def _get_system_status(self, system: System):
        return self._get_systems_status([system])[0]

    def _get_systems_status(self, systems: List[System]):
        raise NotImplementedError()

    @property
    def status(self) -> np.ndarray:
        if self._training:
            return self._get_systems_status(self._systems)
        else:
            return self._get_systems_status([self._eval_system])

    @property
    def state_space_dim(self) -> int:
        raise NotImplementedError()

    @property
    def actions(self):
        raise NotImplementedError()

    @property
    def action_space_dim(self) -> Union[List[int], Dict[str, int], int]:  # Must flatten to depth 1 dictionary
        raise NotImplementedError()

    def _compute_system_reward(self, system: System) -> float:
        return self._compute_systems_reward([system])[0].item()

    def _compute_systems_reward(self, systems: List[System]) -> np.ndarray:
        raise NotImplementedError()

    def _get_system_reward(self, system: System, success: bool) -> float:
        if success:
            return self._compute_system_reward(system)
        else:
            return self._violation_penalty

    def _get_systems_reward(self, systems: List[System], success: List[bool]) -> np.ndarray:
        rewards = self._compute_systems_reward(systems)
        rewards[[not s for s in success]] = self._violation_penalty

        return rewards

    @property
    def reward(self) -> np.ndarray:
        if self._training:
            return self._get_systems_reward(self._systems, success=self._success)
        else:
            return self._get_systems_reward([self._eval_system], success=self._success)

    def reset(self, n: Optional[int] = None):
        if self._training:
            if n is None:
                n = len(self._systems)

            if len(self._systems) >= n:
                self._systems = self._systems[:n]
            else:
                self._systems.extend(self._reference_system.clone() for _ in range(n - len(self._systems)))

            for s in self._systems:
                s.reset()
        else:
            self._eval_system.reset()

    def _transition_system(self, system: System, actions: List, committed: bool) -> Tuple:
        actions = self._ACTION_DTYPE.build_plan(system.status, actions)

        system = system if committed else system.clone(reset=False)

        success = system.execute(actions)
        system.run_step()

        reward = self._get_system_reward(system, success=success)
        next_status = self._get_system_status(system)

        return success, next_status, reward

    def transition(self, agent_prediction, *args, committed: bool = True, **kwargs) -> Tuple[Iterable, np.ndarray]:
        # outcome = Parallel(backend='threading', n_jobs=1)(
        #     delayed(self._transition_system)(s, a, committed)
        #     for s, a in zip(self._systems, self._action_transformer.inverse_transform(agent_prediction))
        # )
        if self._training:
            outcome = [self._transition_system(s, a, committed) for s, a in zip(self._systems, self._action_transformer.inverse_transform(agent_prediction))]
        else:
            outcome = [self._transition_system(self._eval_system, self._action_transformer.inverse_transform(agent_prediction)[0], committed=committed)]
        success, next_status, reward = list(zip(*outcome))

        if committed:
            self._success = success

        return next_status, np.array(reward)

    def train(self):
        self._training = True

    def eval(self):
        self._training = False
    

class Agent:
    def __init__(self, *args, **kwargs):
        self._fitted: bool = False

    @property
    def fitted(self) -> bool:
        return self._fitted

    def fit(self, env: Environment, *args, **kwargs) -> 'Agent':
        raise NotImplementedError()

    def predict(self, env: Environment, *args, **kwargs):
        raise NotImplementedError()

    def predict_proba(self, env: Environment, *args, **kwargs):
        raise NotImplementedError()

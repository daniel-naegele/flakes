import math
import random
import numpy as np
from typing import List, Dict, Tuple

from ..mixin import InjectorMixin
from .base import DeltaIoTEnvironment
from pysas.schedule.deltaiot.events import *
from pysas.system.deltaiot.data import Position
from pysas.schedule import DeltaIOTEventsScheduler
from scipy.interpolate import LinearNDInterpolator


__all__ = ['DeltaIoTPerturbedEnvironment']


class DeltaIoTPerturbedEnvironment(InjectorMixin, DeltaIoTEnvironment):
    """
    DeltaIoTPerturbedEnvironment is a subclass of DeltaIoTEnvironment that injects random perturbations
    into the environment before each transition. This is useful for simulating real-world scenarios where
    the environment is subject to random changes or disturbances.
    In the antifragile setting, this environment can be used to train agents that are robust to such perturbations.
    """
    
    _distance_maps = {}
    
    _schedulers: List[DeltaIOTEventsScheduler] | None = None
    _selectedEvents: List[MoteInsertion | MoteUpdate | MoteDeletion | GatewayInsertion | GatewayUpdate | GatewayDeletion | LinkInsertion | LinkUpdate | LinkDeletion | TurnOrderUpdate | GlobalInterferenceUpdate | None] = [None]

    _availableEvents = [
        MoteInsertion,
        MoteUpdate,
        MoteDeletion,
        # # GatewayInsertion,
        # # GatewayUpdate,
        # # GatewayDeletion,
        LinkInsertion,
        LinkUpdate,
        LinkDeletion,
        # TurnOrderUpdate,
        # GlobalInterferenceUpdate
    ]
    
    def __init__(
        self,
        *args,
        injection_probability=None,
        injection_probabilities_for_events=None,
        **kwargs
    ):
        super().__init__(
            *args,
            **kwargs
        )

        self._schedulers = list(DeltaIOTEventsScheduler() for s in self._systems)
        self._selectedEvents = list(None for s in self._systems)
        self._injection_probability = injection_probability or 0.2
        self._injection_probabilities_for_events = (
            injection_probabilities_for_events or {
                "MoteUpdate": 0.4,
                "LinkInsertion": 0.1,
                "LinkUpdate": 0.4,
                "LinkDeletion": 0.1,
            }
        )

    def transition(self, *args, committed: bool = True, **kwargs) -> Tuple[np.ndarray, np.ndarray]:
        """
        Before calling the transition method, we inject a random perturbation into the environment.
        """
        if self._training:
            for system_index, system in enumerate(self._systems):
                if committed and random.random() < self._injection_probability and self._injection_probabilities_for_events:
                    #the distance map should always be updated with the current system state
                    self._distance_maps[system_index] = self._create_distance_map(system_index)
                    self.inject(
                        injection_probabilities_for_events=self._injection_probabilities_for_events,
                        system_index=system_index
                    )

        return super().transition(*args, committed=committed, **kwargs)

    def reset(self, n: int | None = None):
        super().reset(n)
        self._schedulers = list()
        for s in self._systems:
            o = DeltaIOTEventsScheduler()
            self._schedulers.append(o)
            s.observer = o
        self._selectedEvents = [None for s in self._systems]

    def _create_distance_map(
        self,
        system_index: int,
        include_self: bool = False,
    ) -> Dict[int, List[Dict]]:
        """
        Return {mote_id: [{'mote_id': j, 'distance': d_ij}, …]} for ALL motes.

        Parameters
        ----------
        include_self : bool, default False
            If True, each list also contains {'mote_id': mote_id, 'distance': 0.0}.

        Returns
        -------
        dict[int, list[dict]]
        """
        if not self._systems[system_index]:
            raise ValueError("System is not initialized.")

        pos = {m.id: m.position for m in self._systems[system_index].motes}

        def euclid(i: int, j: int) -> float:
            xi, yi = pos[i].x, pos[i].y
            xj, yj = pos[j].x, pos[j].y
            return math.hypot(xi - xj, yi - yj)

        mote_ids = list(pos.keys())
        distance_map: Dict[int, List[Dict]] = {i: [] for i in mote_ids}
        
        for idx, i in enumerate(mote_ids):
            for j in mote_ids[idx + 1:]:
                d = euclid(i, j)
                distance_map[i].append({"mote_id": j, "distance": d})
                distance_map[j].append({"mote_id": i, "distance": d})

        if include_self:
            for i in mote_ids:
                distance_map[i].append({"mote_id": i, "distance": 0.0})

        for neighbours in distance_map.values():
            neighbours.sort(key=lambda x: x["distance"])

        return distance_map

    def _get_closest_n_motes(self, system_index: int, position: Position, mote_id: int, n: int = 5) -> List:
        """
        Returns the n closest motes to the given position.
        """
        if self._distance_maps[system_index] is None:
            self._distance_maps[system_index] = self._create_distance_map(system_index, include_self=False)

        distances = []
        for other_mote_id, other_position in {
            m.id: m.position for m in self._systems[system_index].motes if m.id != mote_id
        }.items():
            dist = math.hypot(position.x - other_position.x, position.y - other_position.y)
            distances.append((other_mote_id, dist))

        distances.sort(key=lambda x: x[1]) # Sort by distance
        return [self._systems[system_index].get_mote(mid) for mid, _ in distances[:n]]
    
    def _generate_new_mote_id(self, system_index) -> int:
        """
        Generates a new mote ID that is not already in use.
        """
        mote_ids = [mote.id for mote in self._systems[system_index].motes]
        new_mote_id = random.randint(1, 1000)
        while new_mote_id in mote_ids:
            new_mote_id = random.randint(1, 1000)
        return new_mote_id

    def _generate_new_mote_position(self, system_index: int) -> Position:
        """
        Generates a new random position for the mote based on the current topology of the system (e.g., within the bounds of the environment, not overlapping with other motes).
        """
        x = random.uniform(200, 1400)
        y = random.uniform(300, 1000)
        # Ensure the new position does not overlap with existing motes
        for mote in self._systems[system_index].motes:
            if mote.position == (x, y):
                return self._generate_new_mote_position(system_index)
        return Position(x, y)
    
    def _update_mote_position(self, system_index: int, mote_id: int) -> Position:
        """
        Updates the position of the mote based on its current position.
        It will not be moved more than 100 units in any direction.
        
        """
        mote = self._systems[system_index].get_mote(mote_id)
        if mote is None:
            raise ValueError(f"Mote with ID {mote_id} not found.")
        x = mote.position.x + random.uniform(-100, 100)
        y = mote.position.y + random.uniform(-100, 100)
        # Ensure the new position does not overlap with existing motes
        for other_mote in self._systems[system_index].motes:
            if other_mote.id != mote.id and other_mote.position == (x, y):
                return self._update_mote_position(system_index, mote)
            
        return Position(x, y)
    
    def _generate_new_mote_interference(self, system_index: int, new_position: Position) -> float:
        """
        Predicts interference at `new_position` using 2D linear interpolation based on existing motes.
        """
        positions = np.array([m.position for m in self._systems[system_index].motes])
        positions_tuples = [(p.x, p.y) for p in positions]
        interferences = np.array([m.interference for m in self._systems[system_index].motes])

        if len(positions) < 3:
            return float(np.mean(interferences)) if len(interferences) > 0 else 0.0

        interpolator = LinearNDInterpolator(positions_tuples, interferences)
        new_position_tuple = (new_position.x, new_position.y)
        interference = interpolator(new_position_tuple)

        return float(interference) if interference is not None and not np.isnan(interference) else 0.0

    
    def _update_mote_interference(self, system_index: int, mote_id: int) -> float:
        """
        Updates the interference of the mote based on its current interference.
        It will not be moved more than 20% in any direction.
        
        """
        mote = self._systems[system_index].get_mote(mote_id)
        if mote is None:
            raise ValueError(f"Mote with ID {mote_id} not found.")
        new_interference = mote.interference + random.uniform(-0.2, 0.2)*mote.interference

        return new_interference

    def _generate_new_mote_battery_capacity(self, system_index: int) -> float:
        """
        Generates a new random battery capacity for the mote,
        based on the current existing battery capacities in the system.
        It will be sampled from a normal distribution representing the current battery capacities in the system.
        """
        current_battery_capacities = [mote.battery_capacity for mote in self._systems[system_index].motes]
        if not current_battery_capacities:
            return random.uniform(0, 100)
        return random.normalvariate(sum(current_battery_capacities) / len(current_battery_capacities), 10)
    
    def _update_mote_battery_remaining(self, system_index: int, mote_id: int) -> float:
        """
        Updates the battery remaining.
        """
        mote = self._systems[system_index].get_mote(mote_id)
        if mote is None:
            raise ValueError(f"Mote with ID {mote_id} not found.")
        new_battery_remaining = random.uniform(0, 100)

        return new_battery_remaining
    
    def _generate_new_link(self, system_index: int) -> Tuple[int, int]:
        mote_ids = [m.id for m in self._systems[system_index].motes]

        existing_links = {(link.src_node_id, link.dest_node_id) for link in self._systems[system_index].links}
        blocked_pairs = existing_links | {(dst, src) for (src, dst) in existing_links}

        all_possible_links = {
            (src_id, dest_id)
            for src_id in mote_ids
            for dest_id in mote_ids
            if src_id != dest_id and (src_id, dest_id) not in blocked_pairs
        }

        if not all_possible_links:
            return None, None

        return random.choice(list(all_possible_links))
    
    def _generate_new_link_interference(self, system_index: int, midpoint: Position = None) -> float:
        """Predicts interference at the midpoint of the link using 2D linear interpolation based on existing links."""
        midpoints = []
        interferences = []

        # Only get links from motes (gateways don't have outgoing links)
        for mote in self._systems[system_index].motes:
            for link in mote.links:
                src_id = link.src_node_id
                dest_id = link.dest_node_id
                
                if dest_id in [g.id for g in self._systems[system_index].gateways]:
                    dest = self._systems[system_index].get_gateway(dest_id)
                else:
                    dest = self._systems[system_index].get_mote(dest_id)

                if dest is None:
                    continue

                mx = (mote.position.x + dest.position.x) / 2
                my = (mote.position.y + dest.position.y) / 2
                midpoints.append((mx, my))
                
                interferences.append(link.interference)

        if len(midpoints) < 4 or midpoint is None:
            return 0.0

        try:
            interpolator = LinearNDInterpolator(np.array(midpoints), np.array(interferences))
            midpoint_tuple = (midpoint.x, midpoint.y)
            interference = interpolator(midpoint_tuple)
        except Exception as e:
            print(f"[WARNING] Interpolation failed: {e}")
            return 0.0

        return float(interference) if interference is not None and not np.isnan(interference) else 0.0


    def _generate_new_mote_links(self, system_index: int, mote_id: int, new_mote_position: Position) -> List[dict]:
        """
        Generates new random links for the mote based on the current topology of the system.
        First, it generates incoming links, then outgoing links.
        It generates from a minimum of 0 to a maximum of 2 incoming links, with probabilities of (0.5, 0.3, 0.2).
        Then, it generates from a minimum of 1 to a maximum of 2 outgoing links, with probabilities of (0.7, 0.3).
        """
        incoming_links = []
        outgoing_links = []

        closest_motes = self._get_closest_n_motes(system_index, new_mote_position, mote_id, n=5)
        closest_motes_ids = [mote.id for mote in closest_motes]
        
        num_in = random.choices([0,1,2], weights=[0.75,0.2,0.05])[0]
        num_out = random.choices([1,2], weights=[0.7,0.3])[0]

        used_pairs = set()

        # Incoming links
        for _ in range(num_in):
            possible_sources = [m for m in closest_motes_ids if m != mote_id and (m, mote_id) not in used_pairs]
            if not possible_sources:
                break
            src_mote_id = random.choice(possible_sources)
            used_pairs.add((src_mote_id, mote_id))

            midpoint = Position(
                (self._systems[system_index].get_mote(src_mote_id).position.x + new_mote_position.x) / 2,
                (self._systems[system_index].get_mote(src_mote_id).position.y + new_mote_position.y) / 2,
            )
            params = {
                "src_node_id": src_mote_id,
                "dest_node_id": mote_id,
                "direction_gateway_id": random.choice([g.id for g in self._systems[system_index].gateways]),
                "power": random.randint(1, 15),
                "distribution": random.randint(10, 100),
                "interference": self._generate_new_link_interference(system_index, midpoint=midpoint),
                "latency": random.uniform(0, 1),
            }
            incoming_links.append(params)

        # Outgoing links
        for _ in range(num_out):
            possible_dests = [m for m in closest_motes_ids if m != mote_id and (mote_id, m) not in used_pairs]
            if not possible_dests:
                break
            dest = random.choice(possible_dests)
            used_pairs.add((mote_id, dest))
            
            midpoint = Position(
                (new_mote_position.x + self._systems[system_index].get_mote(dest).position.x) / 2,
                (new_mote_position.y + self._systems[system_index].get_mote(dest).position.y) / 2,
            )

            params = {
                "src_node_id": mote_id,
                "dest_node_id": dest,
                "direction_gateway_id": random.choice([g.id for g in self._systems[system_index].gateways]),
                "power": random.randint(1, 15),
                "distribution": random.randint(10, 100),
                "interference": self._generate_new_link_interference(system_index, midpoint=midpoint),
                "latency": random.uniform(0, 1),
            }
            outgoing_links.append(params)

        return {"incoming": incoming_links, "outgoing": outgoing_links}

    def _generate_random_event(self, system_index) -> None:
        """
        Generates random parameters for the given event class.
        """
        super()._generate_random_event(system_index)

        active_events = [
            event for event in self._availableEvents
            if self._injection_probabilities_for_events.get(event.__name__, 0) > 0
        ]
        weights = [
            self._injection_probabilities_for_events[event.__name__]
            for event in active_events
        ]
        if not active_events:
            raise ValueError("No events with positive injection probability.")
        
        event = random.choices(active_events, weights=weights, k=1)[0]    
        
        event_dict = {}
        if event == MoteInsertion:
            mote_id = self._generate_new_mote_id(system_index)
            new_mote_position = self._generate_new_mote_position(system_index)
            links_dict = self._generate_new_mote_links(system_index, mote_id, new_mote_position)
            
            event_dict = {
                "id": mote_id,
                "position": new_mote_position,
                "interference": self._generate_new_mote_interference(system_index, new_mote_position),
                "battery_capacity": self._generate_new_mote_battery_capacity(system_index),
                "battery_remaining": 100.0,
                "load": random.randint(1, 10),
                "activation_probability": random.uniform(0, 1),
                "links": links_dict["outgoing"],
                "parent_links": links_dict["incoming"],
                "turn": None  # Let the system handle the placement
            }
        elif event == MoteUpdate:
            mote = random.choice(self._systems[system_index].motes)
            event_dict = {
                "id": mote.id,
                "position": self._update_mote_position(system_index, mote.id),
                "interference": self._update_mote_interference(system_index, mote.id),
                "battery_remaining": self._update_mote_battery_remaining(system_index, mote.id),
                "activation_probability": random.uniform(0, 1),
                "remove_current_links": random.choices([True, False], weights=[0.3, 0.7])[0],
            }
        elif event == MoteDeletion:
            mote = random.choice(self._systems[system_index].motes)
            event_dict = {
                "id": mote.id,
            }
            
        elif event == LinkInsertion:
            src_node_id, dest_node_id = self._generate_new_link(system_index)
            if src_node_id is None or dest_node_id is None:
                return
            
            midpoint = Position(
                (self._systems[system_index].get_mote(src_node_id).position.x + self._systems[system_index].get_mote(dest_node_id).position.x) / 2,
                (self._systems[system_index].get_mote(src_node_id).position.y + self._systems[system_index].get_mote(dest_node_id).position.y) / 2,
            )
            event_dict = {
                "src_node_id": src_node_id,
                "dest_node_id": dest_node_id,
                "direction_gateway_id": random.choice([g.id for g in self._systems[system_index].gateways]),
                "power": random.randint(1, 15),
                "interference": self._generate_new_link_interference(system_index, midpoint=midpoint),
                "latency": random.uniform(0, 1),
            }
        elif event == LinkUpdate:
            gateway_ids = [g.id for g in self._systems[system_index].gateways]
            links = [link for link in self._systems[system_index].links if link.dest_node_id not in gateway_ids]
            if not links:
                return
            link = random.choice(links)
            midpoint = Position(
                (self._systems[system_index].get_mote(link.src_node_id).position.x + self._systems[system_index].get_mote(link.dest_node_id).position.x) / 2,
                (self._systems[system_index].get_mote(link.src_node_id).position.y + self._systems[system_index].get_mote(link.dest_node_id).position.y) / 2,
            )
            event_dict = {
                "src_node_id": link.src_node_id,
                "dest_node_id": link.dest_node_id,
                "power": random.randint(1, 15),
                "interference": self._generate_new_link_interference(system_index, midpoint=midpoint),
                "latency": random.uniform(0, 1),
            }
            
        elif event == LinkDeletion:
            link = random.choice([link for mote in self._systems[system_index].motes for link in mote.links])
            event_dict = {
                "src_node_id": link.src_node_id,
                "dest_node_id": link.dest_node_id,
            }

        else:
            raise ValueError(f"Unsupported event type: {event}")
            
        if event_dict:
            self._selectedEvents[system_index] = event(**event_dict)
        else:
            raise ValueError("No event parameters generated.")
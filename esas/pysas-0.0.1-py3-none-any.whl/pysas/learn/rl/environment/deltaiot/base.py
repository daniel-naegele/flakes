import numpy as np

from pysas.system.deltaiot.system import DeltaIoTAction
from ....preprocessing.transformers.deltaiot import *

from ...core import Environment
from pysas.system import DeltaIoT
from pysas.system.deltaiot.utils import compute_metrics

import pandas as pd

from typing import List, Union, Dict

__all__ = ['DeltaIoTEnvironment']


# TODO handle batched environment execution (multiple simulators from same initial state)


class DeltaIoTEnvironment(Environment):
    _ACTION_DTYPE = DeltaIoTAction
    _systems: List[DeltaIoT]

    _status_transformer: DeltaIoTStatusTransformer
    _action_transformer: DeltaIoTActionTransformer
    _reward_transformer: DeltaIoTRewardTransformer

    def _get_systems_status(self, systems: List[DeltaIoT]):
        return self._status_transformer.transform(
            [s.status.status_df for s in systems] if self._training else [self._eval_system.status.status_df]
        )

    def _compute_systems_reward(self, systems: List[DeltaIoT]) -> np.ndarray:
        return self._reward_transformer.transform(pd.DataFrame(
            [compute_metrics(s.status) for s in systems] if self._training else [compute_metrics(self._eval_system.status)]
        ))

    @property
    def state_space_dim(self) -> int:
        return self.status[0][0].shape[-1]

    @property
    def actions(self):
        return {k: le.classes_ for k, le in self._action_transformer.label_encoders.items()}

    @property
    def action_space_dim(self) -> Union[Dict[str, int], List[int], int]:
        return {k: len(v) for k, v in self.actions.items()}

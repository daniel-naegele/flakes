__all__ = ['InjectorMixin']

class InjectorMixin:
    """
    Mixin class to inject changes into the environment.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
    def _generate_random_event(self, system_index: int):
        """
        Generates a random event based on the provided injection probabilities.
        """
        if not self._injection_probabilities_for_events:
            raise ValueError("Injection probabilities are not set.")
        
        if not self._availableEvents:
            raise ValueError("No available events to inject.")
        
    def inject(self, injection_probabilities_for_events: dict | None, system_index: int) -> None:
        """
        Injects changes into the environment based on the provided actions.
        """
        if injection_probabilities_for_events is not None:
            self._injection_probabilities_for_events = injection_probabilities_for_events
            
        if self._schedulers[system_index] is None:
            raise ValueError("Scheduler is not initialized.")
        
        self._generate_random_event(system_index)
        
        if self._selectedEvents[system_index] is not None:
            self._schedulers[system_index].add_to_schedule(self._systems[system_index].step+1, self._selectedEvents[system_index])
    
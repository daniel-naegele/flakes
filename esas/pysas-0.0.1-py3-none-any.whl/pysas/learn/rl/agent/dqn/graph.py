import logging

import random

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from torch_geometric.data import Batch, Data

from ....nn.graph import (
    GraphNNEstimator, EdgeEstimator, LinearEdgeEstimator, EdgeData, NodePairEstimator, LinearNodePairEstimator
)
from .core import DQN, QNetFactory

from ...core import Environment

from pysas.common.configurable import ConfigurableMixin

from typing import Tuple, Iterable, Union, Optional, Dict, List, Type


__all__ = ['GraphDQN', 'GraphQNetFactory']

# TODO change to MLP and add support for multi layer tabular networks


class GraphQNetFactory(QNetFactory):
    _q_net_dtype_mappings: Dict[str, Type[EdgeEstimator]] = {
        EdgeEstimator.__name__: EdgeEstimator,
        LinearEdgeEstimator.__name__: LinearEdgeEstimator,
        NodePairEstimator.__name__: NodePairEstimator,
        LinearNodePairEstimator.__name__: LinearNodePairEstimator
    }

    def __call__(self, agent: 'GraphDQN', environment: Environment, *args, **kwargs) -> nn.Module:
        kwargs = self._h_params | kwargs
        state_space_dim = environment.state_space_dim
        action_space_dim = environment.action_space_dim
        if agent.multiagent:
            state_space_dim += action_space_dim if isinstance(action_space_dim, int) else sum(action_space_dim.values())

        model = self._q_net_dtype(state_space_dim, action_space_dim, *args, **kwargs).to(agent.device)
        
        # save n_channels to be used later during preprocessing
        # this is the actual input size (?)
        # NOT COMPLETELY SURE ABOUT THIS
        model.register_buffer('_expected_in_channels', torch.tensor(state_space_dim), persistent=False)
        
        return model


class GraphDQN(ConfigurableMixin, DQN):
    _mapped: Tuple[str, ...] = ('model_factory',)

    mappings: Dict[str, Type] = {
        GraphQNetFactory.__name__: GraphQNetFactory
    }

    @classmethod
    def _q_function(
            cls,
            q_net: GraphNNEstimator,
            status: Union[Iterable[EdgeData], Iterable[Data]],
            action: Union[List[torch.Tensor], List[Dict[str, torch.Tensor]]], 
            *args, 
            **kwargs
        ) -> torch.Tensor:
        policy = cls._predict_proba(q_net, status, *args, action=action, **kwargs)
        if all(isinstance(p, torch.Tensor) for p in policy):
            action_value = torch.cat([torch.sum(p[torch.arange(p.size(0)), a]).view(1) for p, a in zip(policy, action)])
        elif all(isinstance(p, dict) for p in policy):
            action_value = torch.cat([
                torch.sum(torch.vstack([p[k][torch.arange(p[k].size(0)), a[k]] for k in p.keys()])).view(1)
                for p, a in zip(policy, action)
            ])
        else:
            raise ValueError()

        return action_value

    @classmethod
    def _v_function(
            cls, q_net: GraphNNEstimator, status: Union[Iterable[EdgeData], Iterable[Data]], *args, **kwargs
    ) -> torch.Tensor:
        policy = cls._predict_proba(q_net, status, *args, **kwargs)
        if all(isinstance(p, torch.Tensor) for p in policy):
            value = torch.cat([torch.sum(p.max(dim=-1, keepdim=True)[0]).view(1) for p in policy])
        elif all(isinstance(p, dict) for p in policy):
            value = torch.cat(
                [torch.sum(torch.vstack([v.max(dim=-1, keepdim=True)[0] for v in p.values()])).view(1) for p in policy]
            )
        else:
            raise ValueError()
                                 
        return value
    
    # def preprocess_status(
    #         self,
    #         status: Union[List[Tuple[np.ndarray, np.ndarray, np.ndarray]], List[Tuple[np.ndarray, np.ndarray]]]
    # ) -> Union[Iterable[EdgeData], Iterable[EdgeData]]:
    #     print("Tipo di _target_net:", type(self._target_net), flush=True)
    #     print("Attributi disponibili:", dir(self._target_net), flush=True)
    #     print("Attributi pubblici:", [attr for attr in dir(self._target_net) if not attr.startswith('_')], flush=True)

    #     # Verifica se esiste un attributo simile:
    #     for attr in ['in_channels', 'in_features', 'input_dim', 'state_space_dim', 'in_dim']:
    #         if hasattr(self._target_net, attr):
    #             print(f"Trovato: {attr} = {getattr(self._target_net, attr)}", flush=True)
                
    #     if all(len(s) == 3 for s in status):
    #         status = [EdgeData(
    #             x=F.pad(
    #                 torch.tensor(x, device=self._device, dtype=torch.bfloat16 if self._scaler is not None else torch.float),
    #                 (0, self._target_net.in_channels - x.shape[1])
    #             ),
    #             edge_index=torch.tensor(edge_index.T, device=self._device, dtype=torch.long),
    #             nen_index=torch.tensor(nen_index.T, device=self._device, dtype=torch.long)
    #         ) for x, edge_index, nen_index in status]
    #     elif all(len(s) == 2 for s in status):
    #         status = [Data(
    #             x=F.pad(
    #                 torch.tensor(x, device=self._device, dtype=torch.bfloat16 if self._scaler is not None else torch.float),
    #                 (0, self._target_net.in_channels - x.shape[1])
    #             ),
    #             edge_index=torch.tensor(edge_index.T, device=self._device, dtype=torch.long)
    #         ) for x, edge_index in status]
    #     else:
    #         raise ValueError()
        
    #     return status
    def preprocess_status(
        self,
        status: Union[List[Tuple[np.ndarray, np.ndarray, np.ndarray]], List[Tuple[np.ndarray, np.ndarray]]]
    ) -> Union[Iterable[EdgeData], Iterable[EdgeData]]:
        if hasattr(self._target_net, '_expected_in_channels'):
            in_channels = int(self._target_net._expected_in_channels.item())
        else:
            raise RuntimeError(
                "Model does not have '_expected_in_channels' attribute. "
                "This model was likely created with an older version of GraphQNetFactory. "
                "Please retrain the model."
            )
        
        if all(len(s) == 3 for s in status):
            status = [EdgeData(
                x=F.pad(
                    torch.tensor(x, device=self._device, dtype=torch.bfloat16 if self._scaler is not None else torch.float),
                    (0, max(0, in_channels - x.shape[1]))
                ),
                edge_index=torch.tensor(edge_index.T, device=self._device, dtype=torch.long),
                nen_index=torch.tensor(nen_index.T, device=self._device, dtype=torch.long)
            ) for x, edge_index, nen_index in status]
        elif all(len(s) == 2 for s in status):
            status = [Data(
                x=F.pad(
                    torch.tensor(x, device=self._device, dtype=torch.bfloat16 if self._scaler is not None else torch.float),
                    (0, max(0, in_channels - x.shape[1]))
                ),
                edge_index=torch.tensor(edge_index.T, device=self._device, dtype=torch.long)
            ) for x, edge_index in status]
        else:
            raise ValueError("Status must be either 3-tuple (EdgeData) or 2-tuple (Data)")
        
        return status

    def postprocess_status(
            self, status: Union[Iterable[EdgeData], Iterable[EdgeData]]
        ) -> Union[List[Tuple[np.ndarray, np.ndarray, np.ndarray]], List[Tuple[np.ndarray, np.ndarray]]]:
        if all(isinstance(s, EdgeData) for s in status):
            return [
                (edge_data.x.cpu().numpy(), edge_data.edge_index.T.cpu().numpy(), edge_data.nen_index.T.cpu().numpy())
                for edge_data in status
            ]
        elif all(isinstance(s, Data) for s in status):
            return [(edge_data.x.cpu().numpy(), edge_data.edge_index.T.cpu().numpy()) for edge_data in status]
        else:
            raise ValueError()

    def preprocess_action(
        self, action: Union[Iterable[np.ndarray], Iterable[Dict[str, np.ndarray]]]
    ) -> Union[List[torch.Tensor], List[Dict[str, torch.Tensor]]]:
        if all(isinstance(a, np.ndarray) for a in action):
            return [torch.tensor(a, device=self._device, dtype=torch.long) for a in action]
        elif all(isinstance(a, dict) for a in action):
            return [{k: torch.tensor(v, device=self._device, dtype=torch.long) for k, v in a.items()} for a in action]
        else:
            raise ValueError()

    def postprocess_action(
        self, action: Union[Iterable[torch.Tensor], Iterable[Dict[str, torch.Tensor]]]
    ) -> Union[List[np.ndarray], List[Dict[str, np.ndarray]]]:
        if all(isinstance(a, torch.Tensor) for a in action):
            return [a.cpu().numpy() for a in action]
        elif all(isinstance(a, dict) for a in action):
            return [{k: v.cpu().numpy() for k, v in a.items()} for a in action]
        else:
            raise ValueError()

    def collate(
        self, batch: Iterable[Tuple[
            Union[Tuple[np.ndarray, np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray]],
            Union[np.ndarray, Dict[str, np.ndarray]],
            Union[Tuple[np.ndarray, np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray]],
            np.ndarray
        ]]
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        status, action, next_status, reward = [*zip(*batch)]

        status = self.preprocess_status(status)
        action = self.preprocess_action(action)
        next_status = self.preprocess_status(next_status)
        reward = torch.tensor(
            np.stack(reward), device=self._device, dtype=torch.bfloat16 if self._scaler is not None else torch.float
        )

        return status, action, next_status, reward

    @classmethod
    def _predict(
            cls,
            q_net: GraphNNEstimator,
            status: Union[List[EdgeData], List[Data]],
            *args,
            epsilon: Optional[float] = None,
            **kwargs
    ) -> Union[List[torch.Tensor], List[Dict[str, torch.Tensor]]]:
        policy = cls._predict_proba(q_net, status, *args, **kwargs)
        if epsilon is not None and random.random() <= epsilon:
            if all(isinstance(p, torch.Tensor) for p in policy):
                action = [torch.randint(0, p.size(-1), (p.size(0),)) for p in policy]
            else:
                action = [{k: torch.randint(0, v.size(-1), (v.size(0),)) for k, v in p.items()} for p in policy]
        else:
            if all(isinstance(p, torch.Tensor) for p in policy):
                action = [p.argmax(dim=-1) for p in policy]
            else:
                action = [{k: v.argmax(dim=-1) for k, v in p.items()} for p in policy]
        logging.debug('Action predicted')

        return action

    @classmethod
    def _search_action(
            cls, q_net: GraphNNEstimator, status: Union[List[EdgeData], List[Data]], n_iter: int, *args, **kwargs
    ) -> Union[List[torch.Tensor], List[Dict[str, torch.Tensor]]] :
        batched_status = Batch.from_data_list(status)

        # TODO fixme: this is bad practice
        if all(isinstance(s, EdgeData) for s in status):
            splits = [data.nen_index.size(-1) for data in status]
            scores = q_net(
                batched_status.x, batched_status.nen_index, edge_index=batched_status.edge_index, *args, **kwargs
            )
        elif all(isinstance(s, Data) for s in status):
            splits = [data.edge_index.size(-1) // 2 for data in status]
            scores = q_net(batched_status.x, *args, edge_index=batched_status.edge_index, **kwargs)
        else:
            raise ValueError()
        # TODO fixme: this is bad practice
        if isinstance(scores, torch.Tensor):
            action = [s.argmax(dim=-1) for s in torch.split(scores, splits)]
        elif isinstance(scores, dict):
            action = [
                dict(zip(scores.keys(), [v.argmax(dim=-1) for v in values]))
                for values in [*zip(*[torch.split(v, splits) for v in scores.values()])]
            ]
        else:
            raise ValueError()

        for _ in range(n_iter - 1):
            action = (
                torch.hstack([
                    F.one_hot(torch.vstack([a[k] for a in action]), num_classes=n) for k, n in q_net.out_channels.items()
                ]) if q_net.multioutput else F.one_hot(torch.vstack(action), num_classes=q_net.out_channels)
            ).to(batched_status.x)
            # TODO fixme: this is bad practice
            if all(isinstance(s, EdgeData) for s in status):
                batched_status[batched_status.nen_index[:, 1], -action.size(1):] = action
            elif all(isinstance(s, Data) for s in status):
                batched_status[:, -action.size(1):] = action
            else:
                raise ValueError()

            # TODO fixme: this is bad practice
            if all(isinstance(s, EdgeData) for s in status):
                scores = q_net(
                    batched_status.x, batched_status.nen_index, edge_index=batched_status.edge_index, *args,
                    **kwargs
                )
            elif all(isinstance(s, Data) for s in status):
                scores = q_net(batched_status.x, *args, edge_index=batched_status.edge_index, **kwargs)
            else:
                raise ValueError()
            # TODO fixme: this is bad practice
            if isinstance(scores, torch.Tensor):
                action = [s.argmax(dim=-1) for s in torch.split(scores, splits)]
            elif isinstance(scores, dict):
                action = [
                    dict(zip(scores.keys(), [v.argmax(dim=-1) for v in values]))
                    for values in [*zip(*[torch.split(v, splits) for v in scores.values()])]
                ]
            else:
                raise ValueError()

        return action

    @classmethod
    def _predict_proba(
            cls,
            q_net: GraphNNEstimator,
            status: Union[List[EdgeData], List[Data]],
            *args,
            action: Optional[Union[List[torch.Tensor], List[Dict[str, torch.Tensor]]]] = None,
            multiagent: bool = True,
            budget: Optional[int] = None,
            p_masking: Optional[float] = None,
            device: Optional[torch.device] = None,
            half_precision: bool = False,
            **kwargs
    ) -> Union[List[torch.Tensor], List[Dict[str, torch.Tensor]]]:
        if half_precision:
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
                return cls._predict_proba(
                    q_net, status, *args, action=action, multiagent=multiagent, budget=budget, p_masking=p_masking, **kwargs
                )

        if multiagent and action is None and budget is None:
            raise ValueError()

        batched_status = Batch.from_data_list(status)

        if multiagent:
            with torch.no_grad():
                if action is None:
                    action = cls._search_action(q_net, status, budget, *args, **kwargs)
                action = (
                     torch.hstack([
                         F.one_hot(torch.vstack([a[k] for a in action]), num_classes=n) for k, n in q_net.out_channels.items()
                     ]) if q_net.multioutput else F.one_hot(torch.vstack(action), num_classes=q_net.out_channels)
                ).to(batched_status.x)
                action = F.dropout(action, p=p_masking, training=q_net.training)
                # TODO fixme: this is bad practice
                if all(isinstance(s, EdgeData) for s in status):
                    batched_status[batched_status.nen_index[:, 1], -action.size(1):] = action
                elif all(isinstance(s, Data) for s in status):
                    batched_status[:, -action.size(1):] = action
                else:
                    raise ValueError()

        #TODO fixme: this is bad practice
        if all(isinstance(s, EdgeData) for s in status):
            splits = [data.nen_index.size(-1) for data in status]
            scores = q_net(
                batched_status.x, batched_status.nen_index, edge_index=batched_status.edge_index, *args, **kwargs
            )
        elif all(isinstance(s, Data) for s in status):
            splits = [data.edge_index.size(-1) // 2 for data in status]
            scores = q_net(batched_status.x, *args, edge_index=batched_status.edge_index, **kwargs)
        else:
            raise ValueError()
        #TODO fixme: this is bad practice
        if isinstance(scores, torch.Tensor):
            scores = torch.split(scores, splits)
        elif isinstance(scores, dict):
            scores = [
                dict(zip(scores.keys(), values))
                for values in [*zip(*[torch.split(v, splits) for v in scores.values()])]
            ]
        else:
            raise ValueError()

        return scores

from abc import ABC

import math
import random

import logging

from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.amp import GradScaler
from torch.utils.data import IterableDataset
from torch.utils.data import DataLoader

from collections import deque

from ...core import Agent, Environment

from typing import Optional, Literal, Dict, Callable, List, Iterable, Tuple, Type, Union

from pysas.common.configurable import ConfigurableMixin

from .utils import MinSegmentTree, SumSegmentTree


# TODO Create parameter object to allow for scheduling
# TODO Add support for LR scheduling
# TODO differentiate linear and sequential models
# TODO add regularisation
# TODO add mixin/variant for LSTM


__all__ = ['DQN', 'QNetFactory']


class QNetFactory(ConfigurableMixin):
    _q_net_dtype_mappings: Dict[str, Type[nn.Module]] = {nn.Linear.__name__: nn.Linear}

    def __init__(self, q_net_dtype: Union[str, Type[nn.Module]], *args, h_params: Optional[Dict] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._q_net_dtype: Type[nn.Module] = q_net_dtype if isinstance(q_net_dtype, type) else self._q_net_dtype_mappings[q_net_dtype]
        self._h_params: Dict = h_params if h_params is not None else dict()

    def __call__(self, agent: 'DQN', environment: Environment, *args, **kwargs) -> nn.Module:
        kwargs = self._h_params | kwargs
        return self._q_net_dtype(
            environment.state_space_dim, environment.action_space_dim, *args, **kwargs
        ).to(agent.device)


class DQNDataset(IterableDataset):
    # Adapted from https://github.com/bitsandbytes-foundation/bitsandbytes/pull/1314#issuecomment-3262409035
    def __init__(
            self,
            data_set_size: int,
            replay_buffer_size: int,
            *args,
            total_steps: Optional[int] = None,
            alpha: float = 0.0,
            beta: float = 0.0,
            beta_init: Optional[float] = None,
            beta_final: Optional[float] = None,
            beta_schedule: Optional[Literal['linear']] = None,
            beta_decay: Optional[float] = None,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._data_set_size: int = data_set_size
        self._replay_buffer: deque = deque(maxlen=replay_buffer_size)

        # Prioritized replay buffer
        self._total_steps: Optional[int] = total_steps
        self._step: int = 0
        self._alpha: float = alpha
        self._beta: float = beta
        self._beta_init: Optional[float] = beta_init
        self._beta_final: Optional[float] = beta_final
        self._beta_schedule: Optional[Literal['linear']] = beta_schedule
        self._beta_decay: Optional[float] = beta_decay
        self._max_priority: Optional[float] = 1.0 if self.prioritised else None
        self._tree_ptr: Optional[int] = 0 if self.prioritised else None
        tree_capacity = 2 ** int(math.ceil(math.log2(self.max_length))) if self.prioritised else None
        self._sum_tree: Optional[SumSegmentTree] = SumSegmentTree(tree_capacity) if tree_capacity is not None else None
        self._min_tree: Optional[MinSegmentTree] = MinSegmentTree(tree_capacity) if tree_capacity is not None else None


    def __len__(self):
        return self._data_set_size

    @property
    def prioritised(self) -> bool:
        return self.alpha > 0.0 and self.beta > 0.0
    
    @property
    def alpha(self):
        return self._alpha

    @property
    def beta(self):
        if self._beta is not None:
            return self._beta
        else:
            if self._beta_schedule == 'linear':
                return self._beta_init + (self._beta_final - self._beta_init) / self._total_steps * self._step
            else:
                raise ValueError()

    @property
    def max_length(self):
        return self._replay_buffer.maxlen

    def _get_item_weight(self, index: int) -> float:
        if not self.prioritised:
            return 1.0
        
        p_min = self._min_tree.min() / self._sum_tree.sum()
        max_weight = (p_min * len(self._replay_buffer)) ** (-self.beta)

        p_item = self._sum_tree[index] / self._sum_tree.sum()
        weight = (p_item * len(self._replay_buffer)) ** (-self.beta)
        weight = weight / max_weight

        return weight

    def __getitem__(self, index):  # TODO manage better dataset
        return index, self._get_item_weight(index), self._replay_buffer[index]

    def _update_priority(self, index: int, priority: float):
        priority = max(priority, 1.e-6)
        self._sum_tree[index] = priority ** self.alpha
        self._min_tree[index] = priority ** self.alpha

        self._max_priority = max(self._max_priority, priority)

    def _sample_index(self) -> int:
        if not self.prioritised:
            return random.randint(0, len(self._replay_buffer) - 1)

        p_total = self._sum_tree.sum(0, len(self._replay_buffer) - 1)
        upperbound = random.uniform(0, p_total)

        return self._sum_tree.retrieve(upperbound)

    def __iter__(self):
        return iter(self[self._sample_index()] for _ in range(self._data_set_size))

    def push(self, sample):
        self._replay_buffer.append(sample)

        if self.prioritised:
            self._sum_tree[self._tree_ptr] = self._max_priority ** self.alpha
            self._min_tree[self._tree_ptr] = self._max_priority ** self.alpha
            self._tree_ptr = (self._tree_ptr + 1) % self.max_length

    def update_priorities(self, indices: List[int], priorities: List[float]):
        for index, priority in zip(indices, priorities):
            self._update_priority(index, priority)

    def step(self):
        self._step += 1


class DQN(Agent):
    # Adapted from https://pytorch.org/tutorials/intermediate/reinforcement_q_learning.html

    def __init__(
            self,
            *args,
            batch_size: int = 1,
            accumulation_steps: int = 1,
            episodes: int = 1,
            episode_steps: int = 1,
            iterations: int = 1,
            iteration_steps: int = 1,
            replay_buffer_size: Optional[int] = None,
            lr: float = 1.e-3,
            gamma: float = 0.99,
            eps: Optional[float] = None,
            eps_init: Optional[float] = None,
            eps_final: Optional[float] = None,
            eps_schedule: Optional[Literal['linear', 'exponential']] = None,
            eps_decay: Optional[float] = None,
            tau: float = 0.005,
            alpha: float = 0.2,
            beta: Optional[float] =  None,
            beta_init: Optional[float] = 0.6,
            beta_final: Optional[float] = 1.0,
            beta_schedule: Optional[Literal['linear', 'exponential']] = 'linear',
            beta_decay: Optional[float] = None,
            max_grad_norm: Optional[float] = None,
            centering_step: float = 0.0,
            reward_shaping_function: Optional[Callable] = None,
            baseline_model: Optional[nn.Module] = None,
            device: Optional[torch.device] = None,
            half_precision: bool = True,
            logging_period: Optional[int] = None,
            tol: float = 5.e-2,
            patience: int = 1,
            warmup: Optional[int] = None,
            reset_env: bool = True,
            num_workers: int = 4,
            model_factory: Optional[QNetFactory] = None,
            multiagent: bool = True,
            budget: Optional[int] = 1,
            p_masking: Optional[float] = 0.1,
            **kwargs
    ):
        if eps is not None and (eps_init is not None or eps_final is not None):
            raise ValueError()
        if (eps_init is not None and eps_final is None) or (eps_init is None and eps_final is not None):
            raise ValueError()
        if eps_init is not None and eps_final is not None and eps_schedule is None:
            raise ValueError()
        if eps_schedule is not None and eps_schedule == 'exponential' and eps_decay is None:
            eps_decay = 1.0

        super().__init__(*args, **kwargs)

        self._batch_size: int = batch_size
        self._accumulation_steps: int = accumulation_steps
        self._episodes: int = episodes
        self._episode_steps: int = episode_steps
        self._iterations: int = iterations
        self._iteration_steps: int = iteration_steps
        self._replay_buffer_size: int = replay_buffer_size if replay_buffer_size is not None else batch_size
        self._dataset: Optional[DQNDataset] = None
        self._dataloader: Optional[DataLoader] = None

        self._multiagent: bool = multiagent
        self._budget: Optional[int] = budget
        self._p_masking: Optional[float] = p_masking

        self._lr: float = lr
        self._gamma: float = gamma

        self._eps: Optional[float] = eps
        self._eps_init: Optional[float] = eps_init
        self._eps_final: Optional[float] = eps_final
        self._eps_schedule: Optional[Literal['linear', 'exponential']] = eps_schedule
        self._eps_decay: Optional[float] = eps_decay

        self._tau: float = tau
        
        self._alpha: float = alpha
        self._beta: Optional[float] = beta
        self._beta_init: Optional[float] = beta_init
        self._beta_final: Optional[float] = beta_final
        self._beta_schedule: Optional[Literal['linear']] = beta_schedule
        self._beta_decay: Optional[float] = beta_decay

        self._max_grad_norm: Optional[float] = max_grad_norm

        self._reward_shaping_function: Optional[Callable] = reward_shaping_function
        self._centering_step: float =  centering_step
        self._baseline_model: Optional[nn.Module] = baseline_model

        self._target_net: Optional[nn.Module] = None
        self._policy_net: Optional[nn.Module] = None
        self._optimiser: Optional[optim.Optimizer] = None
        self._scaler: Optional[GradScaler] = None

        self._cumulative_loss: Optional[torch.FloatTensor] = None
        self._eval_reward: Optional[torch.FloatTensor] = None
        self._old_eval_reward: Optional[torch.FloatTensor] = None
        self._mean_reward: Optional[float] = None

        self._device: torch.device = device if device is not None else torch.device(
            'cuda' if torch.cuda.is_available() else 'cpu'
        )
        self._half_precision: bool = half_precision

        self._reset_env: bool = reset_env

        self._num_workers: int = num_workers

        self._global_step: Optional[int] = None
        self._iteration: Optional[int] = None
        self._iteration_step: Optional[int] = None
        self._history: Optional[List[Dict]] = None
        self._logging_period: Optional[int] = logging_period

        self._tol: float = tol
        self._patience: int = patience
        self._warmup: Optional[int] = warmup
        self._iterations_wo_improvement: Optional[int] = 0

        self._pretrained: bool = False

        self._model_factory: QNetFactory = model_factory if model_factory is not None else QNetFactory(nn.Linear)

    @property
    def device(self) -> torch.device:
        return self._device

    @property
    def prioritised(self):
        return self._dataset.prioritised if self._dataset is not None else False

    @property
    def multiagent(self) -> bool:
        return self._multiagent

    @property
    def centering_step(self) -> float:
        return self._centering_step

    @centering_step.setter
    def centering_step(self, centering_step: float):
        self._centering_step = centering_step

    @property
    def reward_shaping_function(self) -> Optional[Callable]:
        return self._reward_shaping_function

    @reward_shaping_function.setter
    def reward_shaping_function(self, reward_shaping_function: Optional[Callable]):
        self._reward_shaping_function = reward_shaping_function

    @property
    def history(self) -> List[Dict]:
        return self._history

    @property
    def epsilon(self) -> float:
        if self._eps is not None:
            return self._eps
        else:
            if self._eps_schedule == 'linear':
                return self._eps_final + (self._eps_final - self._eps_init) / self.total_steps * (self._global_step - self.total_steps)
            elif self._eps_schedule == 'exponential':
                return self._eps_final + (self._eps_init - self._eps_final) * math.exp(-self._global_step / self._eps_decay)
            else:
                raise ValueError()

    @property
    def gamma(self) -> float:
        return self._gamma

    @property
    def loss_scale(self):
        return min(
            self._accumulation_steps,
            self._iteration_steps - ((self._iteration_step // self._accumulation_steps) * self._accumulation_steps)
        )

    @property
    def total_steps(self):
        return self._iterations * int(math.ceil(self._iteration_steps / self._accumulation_steps))

    @property
    def model(self) -> nn.Module:
        return self._target_net

    @property
    def weights(self) -> Optional[Dict[str, torch.Tensor]]:
        return self._target_net.state_dict() if self._target_net is not None else None

    @weights.setter
    def weights(self, weights: Dict[str, torch.Tensor]):
        self._target_net.load_state_dict(weights)
        self._pretrained = True
    
    @model.setter
    def model(self, q_net: nn.Module):
        self._target_net = q_net

    @property
    def baseline_model(self) -> Optional[nn.Module]:
        return self._baseline_model

    @baseline_model.setter
    def baseline_model(self, baseline_model: Optional[nn.Module]):
        self._baseline_model = baseline_model

    @property
    def logging_required(self) -> bool:
        return (
            self._logging_period is not None and self._global_step + 1 % self._logging_period
        ) or self._global_step + 1 == self.total_steps
    
    @property
    def check_convergence(self) -> bool:
        if self._global_step >= self._warmup:
            if np.abs(self._eval_reward - self._old_eval_reward) <= self._tol:
                self._iterations_wo_improvement += 1
                if self._iterations_wo_improvement >= self._patience:
                    return True
            else:
                self._iterations_wo_improvement = 0
        self._old_eval_reward = self._eval_reward

        return False

    def _init_q_net(self, environment: Environment):
        self._target_net = self._model_factory(self, environment)
        self._pretrained = False

    @classmethod
    def _q_function(
            cls, q_net: nn.Module, status: torch.Tensor, action: torch.Tensor, *args, **kwargs
    ) -> torch.Tensor:
        policy = cls._predict_proba(q_net, status, *args, **kwargs)
        action_value = policy[torch.arange(policy.size(0)), action]

        return action_value

    def q_function(self, *args, **kwargs) -> torch.Tensor:
        return self._q_function(
            self._target_net,
            *args,
            multiagent=self._multiagent,
            budget=self._budget,
            p_masking=self._p_masking,
            device=self._device,
            half_precision=self._half_precision,
            **kwargs
        )

    @classmethod
    def _v_function(cls, q_net: nn.Module, status: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        policy = cls._predict_proba(q_net, status, *args, **kwargs)
        value = policy.max(dim=-1)[0]

        return value

    def v_function(self, *args, **kwargs) -> torch.Tensor:
        return self._v_function(
            self._target_net,
            *args,
            multiagent=self._multiagent,
            budget=self._budget,
            p_masking=self._p_masking,
            device=self._device,
            half_precision=self._half_precision,
            **kwargs
        )

    @torch.no_grad()
    def eval(self, environment: Environment):
        environment.reset()
        rewards = []
        for i in range(self._episode_steps):
            status = environment.status
            action = self._predict(
                self._policy_net,
                self.preprocess_status(status),
                epsilon=self.epsilon,
                multiagent=self._multiagent,
                budget=self._budget,
                p_masking=self._p_masking,
                device=self._device,
                half_precision=self._half_precision
            )
            action = self.postprocess_action(action)
            _, reward = environment.transition(action)
            rewards.append(reward.mean())
        self._eval_reward = np.array(rewards).mean()

    @torch.no_grad()
    def run_episodes(self, environment: Environment):
        # TODO manage correctly parallel/batched environments
        if self._reset_env or self._iteration == 0:
            environment.reset(n=self._episodes)

        for i in range(self._episode_steps):
            status = environment.status
            action = self._predict(
                self._policy_net,
                self.preprocess_status(status),
                epsilon=self.epsilon,
                multiagent=self._multiagent,
                budget=self._budget,
                p_masking=self._p_masking,
                device=self._device,
                half_precision=self._half_precision
            )
            action = self.postprocess_action(action)
            next_status, reward = environment.transition(action)

            if self._reward_shaping_function is not None:  # https://ai.stanford.edu/~ang/papers/shaping-icml99.pdf - https://arxiv.org/pdf/2502.01307v1
                reward += self._reward_shaping_function(next_status) - self._reward_shaping_function(status)

            if self._baseline_model is not None:
                baseline_action = self._predict(
                    self._baseline_model,
                    self.preprocess_status(status),
                    multiagent=self._multiagent,
                    budget=self._budget,
                    p_masking=self._p_masking,
                    device=self._device,
                    half_precision=self._half_precision
                )
                baseline_action = self.postprocess_action(baseline_action)
                _, baseline_reward = environment.transition(baseline_action, committed=False)
                reward -= baseline_reward

            if self._centering_step > 0.0:  # https://openreview.net/pdf?id=i4eDGZFcva (it should be a special case of reward shaping)
                # Update average reward
                if self._mean_reward is not None:
                    self._mean_reward += self._centering_step * (reward.mean().item() - self._mean_reward)
                else:
                    self._mean_reward = reward.mean().item()

            if self._dataset is not None:
                for s, a, s_, r in zip(status, action, next_status, reward):
                    self._dataset.push((s, a, s_, r))

            self._history.extend([{
                'global_step': self._global_step + 1,
                'date_time': datetime.now(),
                'iteration': self._iteration + 1,
                'exploration_step': i + 1,
                'epsilon': self.epsilon,
                'environment': idx,
                'reward': r.item()
            } for idx, r in enumerate(reward)])

    def preprocess_status(self, status):
        return torch.tensor(status, device=self._device, dtype=torch.bfloat16 if self._scaler is not None else torch.float)

    def postprocess_status(self, status):
        return status.cpu().numpy()

    def preprocess_action(self, action):
        return torch.tensor(action, device=self._device)

    def postprocess_action(self, action):
        return action.cpu().numpy()

    def preprocess_reward(self, reward):
        if self._mean_reward is not None:
            reward -= self._mean_reward
        return torch.tensor(reward, device=self._device, dtype=torch.bfloat16 if self._scaler is not None else torch.float)

    def collate(
            self, batch: Iterable[Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]
        ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        status, action, next_status, reward = [np.vstack(x) for x in zip(*batch)]

        status = self.preprocess_status(status)
        action = self.preprocess_action(action)
        next_status = self.preprocess_status(next_status)
        reward = self.preprocess_reward(reward)

        return status, action, next_status, reward

    def _training_collate(
            self, batch: Iterable[Tuple[int, float, Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]]
    ):
        idxs, weights, batch = zip(*batch)
        return idxs, torch.tensor(weights, device=self._device), *self.collate(batch)
    
    def _process_batch(self, idxs, weights, status, action, next_status, reward) -> torch.Tensor:
        state_action_values = self._q_function(
            self._policy_net,
            status,
            action,
            multiagent=self._multiagent,
            budget=self._budget,
            p_masking=self._p_masking,
            device=self._device,
            half_precision=self._half_precision
        )
        with torch.no_grad():
            expected_state_action_values = reward.reshape(-1) + self._gamma * self._v_function(
                self._target_net,
                next_status,
                multiagent=self._multiagent,
                budget=self._budget,
                p_masking=self._p_masking,
                device=self._device,
                half_precision=self._half_precision
            )
        if self.prioritised:
            loss = F.smooth_l1_loss(state_action_values, expected_state_action_values, reduction='none')
            self._dataset.update_priorities(idxs, loss.detach().cpu().tolist())
            loss = torch.mean(loss * weights) / self.loss_scale  # TODO verify the torch.mean, it should be sum
        else:
            loss = F.smooth_l1_loss(state_action_values, expected_state_action_values) / self.loss_scale

        return loss

    def partial_fit(self, environment: Environment):
        logging.info(f'Iteration {self._iteration + 1}/{self._iterations} started')
        # Exploration
        logging.info('Collecting episodes')
        environment.train()
        self._policy_net.eval()
        logging.debug('Q-Network set in evaluation mode')
        self.run_episodes(environment)
        logging.info('Episodes collected')
        # Exploitation
        logging.info(f'Running {self._iteration_steps} update steps')
        self._policy_net.train()
        logging.debug('Q-Network set in training mode')
        self._iteration_step = 0
        for batch in self._dataloader:
            if self._scaler is not None:
                with torch.autocast(device_type=self._device.type, dtype=torch.bfloat16):
                    loss = self._process_batch(*batch)
                    logging.debug('Forward step half-precision completed')
                self._scaler.scale(loss).backward()
                logging.debug('Backward step half-precision completed')
            else:
                loss = self._process_batch(*batch)
                logging.debug('Forward step completed')
                loss.backward()
                logging.debug('Backward step completed')
            self._cumulative_loss = (self._cumulative_loss + loss.detach()) if self._cumulative_loss is not None else loss.detach()
            if (self._iteration_step + 1) % self._accumulation_steps == 0 or self._iteration_step + 1 == self._iteration_steps:
                if self._max_grad_norm is not None:
                    torch.nn.utils.clip_grad_norm_(self._policy_net.parameters(), self._max_grad_norm)
                    logging.debug('Gradient norm clipped')
                if self._scaler is not None:
                    self._scaler.step(self._optimiser)
                    self._scaler.update()
                    logging.debug('Optimiser step half-precision completed')
                else:
                    self._optimiser.step()
                    logging.debug('Optimiser step completed')
                self._optimiser.zero_grad()
                self._dataset.step()
                if self._tau > 0.0:
                    with torch.no_grad():
                        target_net_state_dict = self._target_net.state_dict()
                        for key, weight in self._policy_net.state_dict().items():
                            target_net_state_dict[key] = weight * self._tau + target_net_state_dict[key] * (1. - self._tau)
                        self._target_net.load_state_dict(target_net_state_dict)
                if self.logging_required:
                    self._history.append({
                        'global_step': self._global_step + 1,
                        'date_time': datetime.now(),
                        'iteration_step': self._iteration_step + 1,
                        'iteration': self._iteration + 1,
                        'loss': self._cumulative_loss.cpu().item(),
                    } | {
                        f'lr_param_group_{i}': p['lr'] for i, p in enumerate(self._optimiser.param_groups)
                    })
                self._global_step += 1
            logging.debug(f'Update step {self._iteration_step + 1}/{self._iteration_steps} completed')
            self._iteration_step += 1
        logging.debug(f'Update steps completed')
        logging.debug(f'Running evaluation at iteration {self._iteration + 1}/{self._iterations}')
        environment.eval()
        self._policy_net.eval()
        self.eval(environment)
        self._history.append({
            'global_step': self._global_step + 1,
            'date_time': datetime.now(),
            'iteration_step': self._iteration_step + 1,
            'iteration': self._iteration + 1,
            'eval_reward': self._eval_reward.item(),
        })
        logging.debug(f'Evaluation at iteration {self._iteration + 1}/{self._iterations} completed')
        self._fitted = self.check_convergence
        logging.info(f'Iteration {self._iteration + 1}/{self._iterations} completed')

    def fit(self, environment: Environment, *args, **kwargs):
        logging.info('Starting DQN agent fit')
        self._fitted = False
        # TODO add support for custom optimizers and lr scheduling
        if not self._pretrained:
            self._init_q_net(environment)
        if self._tau > 0.0:
            self._policy_net = self._model_factory(self, environment)
            with torch.no_grad():
                self._policy_net.load_state_dict(self._target_net.state_dict())
            self._target_net.eval()
        else:
            self._policy_net = self._target_net
        self._optimiser: optim.Optimizer = optim.AdamW(
            self._policy_net.parameters(), lr=self._lr
            # , amsgrad=True
            # , eps=1.e-4 if self._half_precision else 1.e-8,
            # Why epsilon is set like this https://discuss.pytorch.org/t/adam-half-precision-nans/1765/4
            # NOTE: higher epsilon leads to slower learning according to https://discuss.pytorch.org/t/the-problematic-adam-stability-in-automatic-mixed-precision-training/137434
        )
        self._scaler = GradScaler(self._device) if self._half_precision else None
        self._history = list()
        self._dataset = DQNDataset(
            self._iteration_steps * self._batch_size,
            self._replay_buffer_size,
            alpha=self._alpha,
            beta=self._beta,
            beta_init=self._beta_init,
            beta_final=self._beta_final,
            beta_schedule=self._beta_schedule,
            beta_decay=self._beta_decay,
            total_steps=self.total_steps
        )
        self._dataloader = DataLoader(
            self._dataset, 
            batch_size=self._batch_size, 
            collate_fn=self._training_collate,
            shuffle=False, 
            num_workers=self._num_workers
        )
        self._global_step = 0
        self._iteration = None
        self._iteration_step = None
        self._iterations_wo_improvement = 0
        self._cumulative_loss = None

        logging.info(f'Fitting for {self._iterations} iterations')
        # Initialise evaluation reward
        logging.debug(f'Running evaluation at iteration 0/{self._iterations}')
        environment.eval()
        self._policy_net.eval()
        self.eval(environment)
        self._old_eval_reward = self._eval_reward
        self._history.append({
            'global_step': self._global_step,
            'date_time': datetime.now(),
            'iteration_step': self._iteration_step,
            'iteration': self._iteration,
            'eval_reward': self._eval_reward.item()
        })
        logging.debug(f'Evaluation at iteration 0/{self._iterations} completed')
        # Run training
        for self._iteration in range(self._iterations):
            self.partial_fit(environment)
            if self._fitted:
                logging.info('DQN agent fitting completed beforehand')
                self._policy_net = self._target_net
                self._target_net.eval()
                logging.debug('Q-Network set in evaluation mode')
                return self
            
        self._fitted = True
        logging.info('DQN agent fitting completed')
        self._policy_net = self._target_net
        self._target_net.eval()
        logging.debug('Q-Network set in evaluation mode')

        return self

    @classmethod
    def _predict(
            cls, q_net: nn.Module, *args, epsilon: Optional[float] = None, **kwargs
    ) -> torch.Tensor:
        policy = cls._predict_proba(q_net, *args, **kwargs)
        if epsilon is not None and random.random() <= epsilon:
            action = torch.randint(0, policy.size(-1), (policy.size(0),))
        else:
            action = policy.argmax(dim=-1)

        return action

    def predict(self, *args, **kwargs) -> torch.Tensor:
        logging.debug('Predicting action')
        action = self._predict(
            self._target_net,
            *args,
            multiagent=self._multiagent,
            budget=self._budget,
            p_masking=self._p_masking,
            device=self._device,
            half_precision=self._half_precision,
            **kwargs
        )
        logging.debug('Action predicted')

        return action

    @classmethod
    def _predict_proba(
            cls, q_net: nn.Module,
            status: torch.Tensor,
            *args,
            action: Optional[Union[List[torch.Tensor], List[Dict[str, torch.Tensor]]]] = None,
            multiagent: bool = False,
            budget: Optional[int] = None,
            p_masking: Optional[float] = None,
            device: Optional[torch.device] = None,
            half_precision: bool = False,
            **kwargs
    ):
        if half_precision:
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
                return cls._predict_proba(q_net, status, *args, **kwargs)

        status = status.to(q_net.device)
        scores = q_net(status, *args, **kwargs)

        return scores

    def predict_proba(self, *args, **kwargs) -> torch.Tensor:
        logging.debug('Predicting raw scores')
        scores = self._predict_proba(
            self._target_net,
            *args,
            multiagent=self._multiagent,
            budget=self._budget,
            p_masking=self._p_masking,
            device=self._device,
            half_precision=self._half_precision,
            **kwargs
        )
        logging.debug('Scores predicted')

        return scores

import logging

import random

import torch
import torch.nn as nn

from ...core import Environment
from .core import DQN 

from typing import List, Union, Optional, List


__all__ = ['LinearQN']

# TODO change to MLP and add support for multi layer tabular networks
# TODO check wether to delete this Agent

class LinearQN(DQN):
    def _create_q_net(self, environment: Environment) -> Union[nn.Linear, nn.ModuleList]:
        state_space_dim = environment.state_space_dim
        action_space_dim = environment.action_space_dim

        if isinstance(action_space_dim, int):
            q_net = nn.Linear(state_space_dim, action_space_dim, device=self._device)
        else:
            q_net = nn.ModuleList([nn.Linear(state_space_dim, d, device=self._device) for d in action_space_dim])

        return q_net

    @classmethod
    def _q_function(
            cls, q_net: Union[nn.ModuleList, nn.Linear], status: torch.Tensor, action: torch.Tensor, *args, **kwargs
    ) -> Union[List[torch.Tensor], torch.Tensor]:
        if not isinstance(q_net, nn.ModuleList):
            return super()._q_function(q_net, status, action, *args, **kwargs)
        
        policy = cls._predict_proba(q_net, status, *args, **kwargs)
        action_value = torch.hstack(
            [p[torch.arange(p.size(0)), a].view(-1, 1) for p, a in zip(policy, action.T)]
        ).sum(dim=-1)

        return action_value

    @classmethod
    def _v_function(cls, q_net: Union[nn.ModuleList, nn.Linear], status: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        policy = cls._predict_proba(q_net, status, *args, **kwargs)
        value = torch.hstack([p.max(dim=-1, keepdim=True)[0] for p in policy]).sum(dim=-1)

        return value

    @classmethod
    def _predict(
            cls,
            q_net: Union[nn.ModuleList, nn.Linear],
            status: torch.Tensor,
            *args,
            epsilon: Optional[float] = None,
            **kwargs
    ) -> torch.Tensor:
        if not isinstance(q_net, nn.ModuleList):
            return super()._predict(q_net, status, *args, epsilon=epsilon, **kwargs)
        policy = cls._predict_proba(q_net, status, *args, **kwargs)
        if epsilon is not None and random.random() <= epsilon:
            action = action = torch.hstack([torch.randint(0, p.size(-1), (p.size(0), 1)) for p in policy])
        else:
            action = torch.hstack([p.argmax(dim=-1, keepdim=True) for p in policy])

        return action

    @classmethod
    def _predict_proba(
            cls, q_net: Union[nn.ModuleList, nn.Linear], status: torch.Tensor, *args, **kwargs
    ) -> Union[torch.Tensor, List[torch.Tensor]]:
        if not isinstance(q_net, nn.ModuleList):
            return super()._predict_proba(q_net, status, *args, **kwargs)
        status = status.to(q_net.device)
        scores = [module(status, *args, **kwargs) for module in q_net]

        return scores

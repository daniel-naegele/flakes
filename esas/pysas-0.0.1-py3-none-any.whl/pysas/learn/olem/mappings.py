from .core import ChangeDetector

from .eddm import EDDM

from typing import Dict, Type


agent_mapping: Dict[str, Type[ChangeDetector]] = {
    EDDM.__name__: EDDM
}
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

from typing import Dict, Literal, Optional, Union

from pygments.lexers import go

from pysas.learn.olem.core import ChangeDetector


__all__ = ['EDDM']


# TODO add support for other data formats (e.g., numpy arrays or pd.Series)
# TODO make it stateful and stateless


class EDDM(ChangeDetector):
    def __init__(
            self,
            *args,
            alpha: float = 0.1,  # TODO make this configurable for the different metrics
            detection_threshold: float = 3.0,  # TODO make this configurable for the different metrics
            warning_threshold: Optional[float] = None,  # TODO make this configurable for the different metrics
            mu0: Optional[Union[float, np.ndarray, pd.Series]] = None,
            sigma0: Optional[Union[float, np.ndarray, pd.Series]] = None,
            **kwargs
    ):
        super(ChangeDetector, self).__init__(*args, **kwargs)

        self._alpha: float = alpha
        self._detection_threshold: float = detection_threshold
        self._warning_threshold: float = warning_threshold if warning_threshold is not None else detection_threshold / 2

        self._mu0: Optional[Union[float, np.ndarray, pd.Series]] = mu0
        self._sigma0: Optional[Union[float, np.ndarray, pd.Series]] = sigma0

    @property
    def mu0(self) -> Union[float, np.ndarray, pd.Series]:
        return self._mu0

    @mu0.setter
    def mu0(self, mu0: Union[float, np.ndarray, pd.Series]):
        self._mu0 = mu0

    @property
    def sigma0(self) -> Union[float, np.ndarray, pd.Series]:
        return self._sigma0

    @sigma0.setter
    def sigma0(self, sigma0: Union[float, np.ndarray, pd.Series]):
        self._sigma0 = sigma0

    def compute_test_statistic(self, data: pd.DataFrame) -> pd.DataFrame:
        return data.ewm(alpha=self._alpha).mean()

    def compute_boundary(self, data: pd.DataFrame, threshold: float) -> pd.DataFrame:
        mu0 = self._mu0 if self._mu0 is not None else data.rolling(len(data), min_periods=1).mean()
        sigma0 = self._sigma0 if self._sigma0 is not None else data.rolling(len(data), min_periods=1).std()
        if isinstance(sigma0, pd.Series):
            sigma0 = pd.DataFrame([sigma0] * len(data))

        sigma_z = sigma0.apply(
            lambda x: x * np.sqrt((self._alpha / (2 - self._alpha)) * (1 - (1 - self._alpha) ** (2 * x.index))), axis=0
        )

        boundary = mu0 + sigma_z * threshold

        return boundary

    def _run_detection(self, data: pd.DataFrame, threshold: float, *args, **kwargs) -> bool:
        z = self.compute_test_statistic(data)
        boundary = self.compute_boundary(data, threshold)

        return (z.iloc[-1] > boundary.iloc[-1]).any().item()

    def detect(self, data: pd.DataFrame, *args, **kwargs) -> bool:
        return self._run_detection(data, self._detection_threshold, *args, **kwargs)

    def warn(self, data: pd.DataFrame, *args, **kwargs) -> bool:
        return self._run_detection(data, self._warning_threshold, *args, **kwargs)

    def plot(
            self,
            data: pd.DataFrame,
            *args,
            figure: Optional = None,
            axes: Optional = None,
            show: bool = True,
            titles: Optional[Dict[str, str]] = None,
            ylabels: Optional[Dict[str, str]] = None,
            **kwargs
    ):
        titles = titles if titles else dict()
        ylabels = ylabels if ylabels else dict()

        figure, axes = plt.subplots(
            *args, nrows=1, ncols=len(data.columns), sharex=True, **kwargs
        ) if figure is None and axes is None else (figure, axes)
        axes = figure.subplots(nrows=1, ncols=len(data.columns), sharex=True) if axes is None else axes.flatten()

        z = self.compute_test_statistic(data)
        boundary = self.compute_boundary(data, self._detection_threshold)
        warning_boundary = self.compute_boundary(data, self._warning_threshold)

        for metric, axis in zip(data.columns, axes):
            axis.plot(data.index, data[metric], c='tab:blue', label=f'Error')
            axis.plot(data.index, z[metric], c='tab:green', label=f'Error EWMA ($\\alpha = {self._alpha}$)')
            axis.plot(data.index, boundary[metric], c='tab:red', label='Drift detection threshold')
            if self._warning_threshold != self._detection_threshold:
                axis.plot(data.index, warning_boundary[metric], c='tab:orange', label='Drift warning threshold')

            axis.set_xlabel('Step')
            axis.set_ylabel(ylabels.get(metric, metric))
            axis.set_title(titles.get(metric, metric))
            axis.grid()

        if figure is not None:
            handles, labels = axes[0].get_legend_handles_labels()
            figure.legend(
                handles,
                labels,
                loc='upper center',
                bbox_to_anchor=(0.5, 1.025),
                ncol=4
            )

        if show:
            plt.show()

        return figure, axes

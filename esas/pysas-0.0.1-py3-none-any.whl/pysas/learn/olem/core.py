from abc import ABC
from typing import Tuple, Union, Optional

from pysas.common.configurable import ConfigurableMixin


__all__ = ['ChangeDetector']


# TODO make automatic tuning of of parameters available


class ChangeDetector(ConfigurableMixin, ABC):
    def detect(self, *args, **kwargs) -> bool:
        raise NotImplementedError()

    def warn(self, *args, **kwargs) -> bool:
        raise NotImplementedError()

    def __call__(self, *args, **kwargs) -> Tuple[bool, bool]:
        return self.detect(*args, **kwargs), self.warn(*args, **kwargs)

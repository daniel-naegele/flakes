import random
import logging

from abc import ABC

from pysas.system.core import System, SystemObserver

from typing import Dict, Optional, Iterable, Type

__all__ = ['EventsScheduler', 'Event']


class Event(ABC):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __call__(self, system: System, *args, **kwargs):
        raise NotImplementedError()


class EventsScheduler(SystemObserver):
    _events_mapping: Optional[Dict[str, Type[Event]]] = None

    def __init__(self, *args, schedule: Optional[Dict[int, Iterable[Event]]] = None, **kwargs):
        super().__init__(*args, **kwargs)

        self._schedule: Dict[int, Iterable[Event]] = schedule if schedule is not None else dict()

    @classmethod
    def load_from_configs(cls, *args, events_config: Optional[Iterable[Dict]] = None, **kwargs):
        schedule = dict()
        if events_config is not None:
            for event_config in events_config:
                dtype = event_config['dtype']
                step = event_config['step']
                params = {k: v for k, v in event_config.items() if k not in ('dtype', 'step')}
                if not isinstance(step, int):
                    step = random.randint(*step)
                if step in schedule:
                    schedule[step].append(cls._events_mapping[dtype](**params))
                else:
                    schedule[step] = [cls._events_mapping[dtype](**params)]

        return super().load_from_configs(*args, schedule=schedule, **kwargs)
    
    def add_to_schedule(self, step: int, event: Event):
        if step in self._schedule:
            self._schedule[step].append(event)
        else:
            self._schedule[step] = [event]

    def __call__(self, *args, **kwargs):
        events = self._schedule.get(self._system.step)
        if events is not None:
            for event in events:
                try:
                    event(self._system, *args, **kwargs)
                except RuntimeError as e:
                    logging.error(e)

    def start(self):
        pass

    def stop(self):
        pass

from .core import EventsScheduler

from .deltaiot import DeltaIOTEventsScheduler
from .malware_infection import MalwareInfectionEventsScheduler

from typing import Dict, Type


scheduler_mapping: Dict[str, Type[EventsScheduler]] = {
    DeltaIOTEventsScheduler.__name__: DeltaIOTEventsScheduler,
    MalwareInfectionEventsScheduler.__name__: MalwareInfectionEventsScheduler
}

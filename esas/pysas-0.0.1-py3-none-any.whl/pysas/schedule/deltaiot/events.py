import logging

from ..core import Event
from pysas.system import DeltaIoT
from pysas.system.deltaiot.data import Gateway, Link, Position

from typing import List, Optional, Tuple, Dict


__all__ = [
    'MoteInsertion', 'MoteUpdate', 'MoteDeletion',
    'GatewayInsertion', 'GatewayUpdate', 'GatewayDeletion',
    'LinkInsertion', 'LinkUpdate', 'LinkDeletion',
    'TurnOrderUpdate', 'GlobalInterferenceUpdate'
]


class MoteInsertion(Event):
    def __init__(
            self,
            id: int,
            position: Position | Tuple[float, float],
            *args,
            interference: float = 0.0,
            battery_capacity: float = 0.0,
            battery_remaining: float = 0.0,
            load: int = 0,
            activation_probability: Optional[float] = 1.0,
            last_packet_number: Optional[int] = 0,
            links: Optional[List[Dict]] = None,
            parent_links: Optional[List[Dict]] = None,
            turn: Optional[int] = None,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._id: int = id
        self._position: Position = position if isinstance(position, Position) else Position(position[0], position[1])
        self._interference: float = interference
        self._battery_capacity = battery_capacity
        self._battery_remaining = battery_remaining
        self._load: int = load
        self._activation_probability: float = activation_probability
        self._last_packet_number: int = last_packet_number
        self._links: List[Dict] = links if links is not None else []
        self._parent_links: List[Dict] = parent_links if parent_links is not None else []
        self._turn: Optional[int] = turn

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.insert_mote(
            params= {
                "id": self._id,
                "position": self._position,
                "interference": self._interference,
                "battery_capacity": self._battery_capacity,
                "battery_remaining": self._battery_remaining,
                "load": self._load,
                "activation_probability": self._activation_probability,
                "last_packet_number": self._last_packet_number,
                "links": self._links,
                "parent_links": self._parent_links,
                "turn": self._turn
            },
        )


class MoteUpdate(Event):
    def __init__(
            self,
            id: int,
            *args,
            position: Optional[Position | Tuple[float, float]] = None,
            interference: Optional[float] = None,
            battery_remaining: Optional[float] = None,
            load: Optional[int] = None,
            activation_probability: Optional[float] = None,
            links: Optional[List[Dict]] = None,
            remove_current_links: bool = False,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._id: int = id
        self._position: Optional[Position] = position if isinstance(position, Position) or position is None else Position(position[0], position[1])
        self._interference: Optional[float] = interference
        self._battery_remaining: Optional[float] = battery_remaining
        self._load: Optional[int] = load
        self._activation_probability: Optional[float] = activation_probability
        self._links: Optional[List[Dict]] = links
        self._remove_current_links: bool = remove_current_links

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.update_mote(
            self._id,
            params={
                "position": self._position,
                "interference": self._interference,
                "battery_remaining": self._battery_remaining,
                "load": self._load,
                "activation_probability": self._activation_probability,
                "links": self._links,
                "remove_current_links": self._remove_current_links
            }
        )


class MoteDeletion(Event):
    def __init__(self, id: int, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._id: int = id

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.delete_mote(self._id)


class GatewayInsertion(Event):
    def __init__(
            self,
            id: int,
            position: Position | Tuple[float, float],
            *args,
            interference: float = 0.0,
            view_mote_ids: Optional[List[int]] = None,
            expected_packet_count: int = 0,
            power_consumed: float = 0.0,
            packet_loss: float = 0.0,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._id: int = id
        self._position: Position = position if isinstance(position, Position) else Position(position[0], position[1])
        self._interference: float = interference
        self._view_mote_ids: List[int] = view_mote_ids if view_mote_ids is not None else list()
        self._expected_packet_count: int = expected_packet_count
        self._power_consumed: float = power_consumed
        self._packet_loss: float = packet_loss

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.insert_gateway(Gateway(
            self._id,
            self._position,
            interference=self._interference,
            view_mote_ids=self._view_mote_ids,
            expected_packet_count=self._expected_packet_count,
            power_consumed=self._power_consumed,
            packet_loss=self._packet_loss
        ))


class GatewayUpdate(Event):
    def __init__(
            self,
            id: int,
            *args,
            position: Optional[Position | Tuple[float, float]] = None,
            interference: Optional[float] = None,
            view: Optional[List[int]] = None,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._id: int = id
        self._position: Optional[Position] = position if isinstance(position, Position) or position is None else Position(position[0], position[1])
        self._interference: Optional[float] = interference
        self._view: Optional[List[int]] = view

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.update_gateway(
            self._id, position=self._position, interference=self._interference, view=self._view
        )


class GatewayDeletion(Event):
    def __init__(self, id: int, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._id: int = id

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.delete_gateway(self._id)


class LinkInsertion(Event):
    def __init__(
            self,
            src_node_id: int,
            dest_node_id: int,
            direction_gateway_id: int,
            power: int,
            *args,
            distribution: Optional[int] = 0,
            latency: float = 0.0,
            interference: float = 0.0,
            packet_loss: int = 0,
            snr_eq_params: Tuple[float, float] = (0.0, 0.0),
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._src_node_id: int = src_node_id
        self._dest_node_id: int = dest_node_id
        self._direction_gateway_id: int = direction_gateway_id
        self._power: int = power
        self._distribution: int = distribution
        self._latency: float = latency
        self._interference: float = interference
        self._packet_loss: int = packet_loss
        self._snr_eq_params: Tuple[float, float] = snr_eq_params

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.insert_link(
            params={
                "src_node_id": self._src_node_id,
                "dest_node_id": self._dest_node_id,
                "direction_gateway_id": self._direction_gateway_id,
                "power": self._power,
                "distribution": self._distribution,
                "latency": self._latency,
                "interference": self._interference,
                "packet_loss": self._packet_loss,
                "snr_eq_params": self._snr_eq_params
            }
        )


class LinkUpdate(Event):
    def __init__(
            self,
            src_node_id: int,
            dest_node_id: int,
            *args,
            latency: Optional[float] = None,
            power: Optional[float] = None,
            direction_gateway_id: Optional[int] = None,
            distribution: Optional[int] = None,
            snr_equation_params: Optional[Tuple[float, float]] = None,
            interference: Optional[float] = None,
            **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._src_node_id: int = src_node_id
        self._dest_node_id: int = dest_node_id
        self._latency: Optional[float] = latency
        self._power: Optional[float] = power
        self._direction_gateway_id: Optional[int] = direction_gateway_id
        self._distribution: Optional[int] = distribution
        self._snr_equation_params: Optional[Tuple[float, float]] = snr_equation_params
        self._interference: Optional[float] = interference

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.update_link(
            params={
                "src_node_id": self._src_node_id,
                "dest_node_id": self._dest_node_id,
                "latency": self._latency,
                "power": self._power,
                "direction_gateway_id": self._direction_gateway_id,
                "distribution": self._distribution,
                "snr_eq_params": self._snr_equation_params,
                "interference": self._interference
            }
        )

class LinkDeletion(Event):
    def __init__(self, src_node_id: int, dest_node_id: int, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._src_node_id: int = src_node_id
        self._dest_node_id: int = dest_node_id

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        try:
            #the checks are done in the system method already so it should work as expected
            system.delete_link(self._src_node_id, self._dest_node_id)
        except RuntimeError as e:
            logging.warning(f'Link deletion ({self._src_node_id}, {self._dest_node_id}) prevented by system safeguards: {e}')

class TurnOrderUpdate(Event):
    def __init__(self, turn_order: List[int], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._turn_order: List[int] = turn_order

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.turn_order = self._turn_order


class GlobalInterferenceUpdate(Event):
    def __init__(self, global_interference: float, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._global_interference: float = global_interference

    def __call__(self, system: DeltaIoT, *args, **kwargs):
        system.global_interference = self._global_interference

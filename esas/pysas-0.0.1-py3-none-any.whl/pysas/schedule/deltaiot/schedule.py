from ..core import EventsScheduler, Event
from pysas.system import DeltaIoT

from .events import *

from typing import Dict, Type


__all__ = ['DeltaIOTEventsScheduler']


class DeltaIOTEventsScheduler(EventsScheduler):
    _system: DeltaIoT

    _events_mapping: Dict[str, Type[Event]] = {
        MoteInsertion.__name__: MoteInsertion,
        MoteUpdate.__name__: MoteUpdate,
        MoteDeletion.__name__: MoteDeletion,
        GatewayInsertion.__name__: GatewayInsertion,
        GatewayUpdate.__name__: GatewayUpdate,
        GatewayDeletion.__name__: GatewayDeletion,
        LinkInsertion.__name__: LinkInsertion,
        LinkUpdate.__name__: LinkUpdate,
        LinkDeletion.__name__: LinkDeletion,
        TurnOrderUpdate.__name__: TurnOrderUpdate,
        GlobalInterferenceUpdate.__name__: GlobalInterferenceUpdate
    }

from .deltaiot import DeltaIOTEventsScheduler
from .malware_infection import MalwareInfectionEventsScheduler

from .mappings import scheduler_mapping

# TODO aggregate learning tools
# TODO aggregate drift detection tools
# TODO add constraints violation in analyzer

from abc import ABC

from sklearn.base import TransformerMixin

import torch.nn as nn

from pysas.learn.rl.core import Agent, Environment
from pysas.common.configurable import ConfigurableMixin

from typing import Optional

import threading


__all__ = [
    'LearnerMixin',
    'AgentInitialiser',
    'TransformerFactory',
    'EnvironmentFactory'
]


class EnvironmentFactory:
    def build(self) -> Environment:
        raise NotImplementedError()


class TransformerFactory(ConfigurableMixin, ABC):
    def __call__(self, *args, **kwargs) -> TransformerMixin:
        raise NotImplementedError()
    

class AgentInitialiser(ConfigurableMixin, ABC):
    def __init__(
            self, 
            *args, 
            transfer_threshold: Optional[float] = None,
            similarity_threshold: Optional[float] = None,
            **kwargs
        ):
        super().__init__(*args, **kwargs)

        self._transfer_threshold: Optional[float] = transfer_threshold
        self._similarity_threshold: Optional[float] = similarity_threshold

    def __call__(self, agent: Agent, environment: Environment, *args, **kwargs) -> bool:
        raise NotImplementedError()
    

class LearnerMixin:
    _agent: Optional[Agent] = None
    _environment: Optional[Environment] = None
    _status_transformer: Optional[TransformerMixin] = None
    _action_transformer: Optional[TransformerMixin] = None
    _reward_transformer: Optional[TransformerMixin] = None
    _agent_initialiser: Optional[AgentInitialiser] = None
    _environment_factory: Optional[EnvironmentFactory] = None
    _status_transformer_factory: Optional[TransformerFactory] = None
    _action_transformer_factory: Optional[TransformerFactory] = None
    _reward_transformer_factory: Optional[TransformerFactory] = None

    def __init__(
            self,
            *args,
            agent: Optional[Agent] = None,
            environment: Optional[Environment] = None,
            agent_initialiser: Optional[AgentInitialiser] = None, 
            environment_factory: Optional[EnvironmentFactory] = None,
            status_transformer_factory: Optional[TransformerFactory] = None,
            action_transformer_factory: Optional[TransformerFactory] = None,
            reward_transformer_factory: Optional[TransformerFactory] = None,
            **kwargs
    ):
        super().__init__(*args, **kwargs)

        self._agent = agent
        self._environment = environment
        self._status_transformer_factory = status_transformer_factory
        self._action_transformer_factory = action_transformer_factory
        self._reward_transformer_factory = reward_transformer_factory
        self._environment_factory = environment_factory
        self._agent_initialiser = agent_initialiser

        self._update_model_thread: Optional[threading.Thread] = None

    @classmethod
    def load_active_learner_from_configs(cls, *args, proactive: bool = False, **kwargs):
        raise NotImplementedError()

    @classmethod
    def load_passive_learner_from_configs(cls, *args, proactive: bool = False, **kwargs):
        raise NotImplementedError()

    @classmethod
    def load_static_learner_from_configs(cls, *args, proactive: bool = False, **kwargs):
        raise NotImplementedError()

    @property
    def agent(self):
        return self._agent

    @agent.setter
    def agent(self, agent: Agent):
        self._agent = agent

    @property
    def environment(self):
        return self._environment

    @environment.setter
    def environment(self, environment: Environment):
        self._environment = environment

    @property
    def status_transformer_factory(self) -> Optional[TransformerFactory]:
        return self._status_transformer_factory
    
    @status_transformer_factory.setter
    def status_transformer_factory(self, status_transformer_factory: TransformerFactory) -> Optional[TransformerFactory]:
        self._status_transformer_factory = status_transformer_factory

    @property
    def status_transformer(self) -> Optional[TransformerMixin]:
        return self._status_transformer

    @status_transformer.setter
    def status_transformer(self, transformer: TransformerMixin):
        self._status_transformer = transformer

    @property
    def action_transformer_factory(self) -> Optional[TransformerFactory]:
        return self._action_transformer_factory
    
    @action_transformer_factory.setter
    def action_transformer_factory(self, action_transformer_factory: TransformerFactory) -> Optional[TransformerFactory]:
        self._action_transformer_factory = action_transformer_factory

    @property
    def action_transformer(self) -> Optional[TransformerMixin]:
        return self._action_transformer

    @action_transformer.setter
    def action_transformer(self, transformer: TransformerMixin):
        self._action_transformer = transformer

    @property
    def reward_transformer_factory(self) -> Optional[TransformerFactory]:
        return self._reward_transformer_factory
    
    @reward_transformer_factory.setter
    def reward_transformer_factory(self, reward_transformer_factory: TransformerFactory) -> Optional[TransformerFactory]:
        self._reward_transformer_factory = reward_transformer_factory

    @property
    def reward_transformer(self) -> Optional[TransformerMixin]:
        return self._reward_transformer

    @reward_transformer.setter
    def reward_transformer(self, transformer: TransformerMixin):
        self._reward_transformer = transformer

    @property
    def agent_initialiser(self) -> AgentInitialiser:
        return self._agent_initialiser
    
    @agent_initialiser.setter
    def agent_initialiser(self, agent_initialiser: AgentInitialiser):
        self._agent_initialiser = agent_initialiser

    @property
    def update(self) -> bool:
        return not self.agent.fitted

    def _build_status_transformer(self) -> TransformerMixin:
        raise NotImplementedError()

    def _build_action_transformer(self) -> TransformerMixin:
        raise NotImplementedError()

    def _build_reward_transformer(self) -> TransformerMixin:
        raise NotImplementedError()

    def _build_environment(self) -> Environment:
        raise NotImplementedError()
    
    def _build_transfer_agent(self):
        raise NotImplementedError()

    def _get_reference_agent(self) -> nn.Module:
        raise NotImplementedError()

    def _build_agent(self):
        if self._agent_initialiser and self._agent.fitted:
            return self._build_transfer_agent()
        else:
            return self._agent.fit(self._environment)

    def _update_model(self):
        self._status_transformer = self._build_status_transformer()
        self._action_transformer = self._build_action_transformer()
        self._reward_transformer = self._build_reward_transformer()
        self._environment = self._build_environment()
        self._agent = self._build_agent()

    def _update_timeout(self) -> Optional[float]:
        raise NotImplementedError()

    def update_model(self):
        if self._update_model_thread is None or not self._update_model_thread.is_alive():
            self._update_model_thread = threading.Thread(target=self._update_model)
            self._update_model_thread.start()

        self._update_model_thread.join(timeout=self._update_timeout())

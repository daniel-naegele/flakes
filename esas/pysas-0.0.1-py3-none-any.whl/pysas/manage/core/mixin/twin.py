from pysas.learn.rl.core import Agent, Environment
from pysas.system.core import System

from typing import Optional, Type


__all__ = ['TwinMixin']


class TwinMixin:
    _system_twin: Optional[System] = None

    def __init__(self, *args, system_twin: Optional[System] = None, **kwargs):
        super().__init__(*args, **kwargs)

        self._system_twin: Optional[System] = system_twin

    @property
    def system_twin(self):
        return self._system_twin

    @system_twin.setter
    def system_twin(self, system_twin):
        self._system_twin = system_twin

    @property
    def synch(self) -> bool:
        raise NotImplementedError()

    def _synch_twin(self):
        raise NotImplementedError()

    def synch_twin(self):
        if self._system_twin is not None:
            self._synch_twin()

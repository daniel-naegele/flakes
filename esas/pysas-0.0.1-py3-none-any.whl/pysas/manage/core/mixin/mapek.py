from typing import Optional, Dict, Union, Tuple

from dataclasses import dataclass, asdict

from abc import ABC

from pysas.common.configurable import ConfigurableMixin


__all__ = ['MAPEKMixin', 'Monitor', 'Analyser', 'Planner', 'Executor', 'Knowledge']

from pysas.manage.deltaiot.data import DeltaIoTObservation


@dataclass
class Knowledge:
    @property
    def data(self) -> Dict:
        return asdict(self)

    def register_monitor_update(self, *args, **kwargs):
        raise NotImplementedError()

    def register_analyser_update(self, *args, **kwargs):
        raise NotImplementedError()

    def register_planner_update(self, *args, **kwargs):
        raise NotImplementedError()

    def register_executor_update(self, *args, **kwargs):
        raise NotImplementedError()


class MAPEComponent(ConfigurableMixin, ABC):
    OUT_KEY: Optional[Union[Tuple[str, ...], str]] = None

    _manager: 'MAPEKMixin'

    def __init__(self, *args, manager: Optional['MAPEKMixin'] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._manager = manager

    @property
    def manager(self):
        return self._manager

    @manager.setter
    def manager(self, manager: Optional['MAPEKMixin']):
        self._manager = manager

    @property
    def next(self) -> Optional['MAPEComponent']:
        raise NotImplementedError()

    @property
    def knowledge(self):
        return self._manager.knowledge

    def _run(self, *args, **kwargs):
        raise NotImplementedError()

    def _update_knowledge(self, *args, **kwargs):
        raise NotImplementedError()

    def run(self, *args, **kwargs) -> Dict:
        out = self._run(*args, **kwargs)
        if self.OUT_KEY is not None:
            out = {self.OUT_KEY: out} if isinstance(self.OUT_KEY, str) else {k: o for k, o in zip(self.OUT_KEY, out)}
            if self.knowledge is not None:
                self._update_knowledge(**out)

        return out

    def __call__(self, *args, **kwargs):
        # TODO: review this calling approach
        out = self.run(*args, **kwargs)
        if self.next is not None:
            self.next(*args, **kwargs, **out)


class Monitor(MAPEComponent):
    OUT_KEY = 'observation'

    @property
    def next(self) -> 'Analyser':
        return self.manager.analyser

    def _update_knowledge(self, *args, **kwargs):
        self.manager.knowledge.register_monitor_update(*args, **kwargs)


class Analyser(MAPEComponent):
    OUT_KEY = 'adapt'

    @property
    def next(self) -> 'Planner':
        return self.manager.planner

    def _update_knowledge(self, *args, **kwargs):
        self.manager.knowledge.register_analyser_update(*args, **kwargs)


class Planner(MAPEComponent):
    OUT_KEY = 'plan'

    @property
    def next(self) -> 'Executor':
        return self.manager.executor

    def _update_knowledge(self, *args, **kwargs):
        self.manager.knowledge.register_planner_update(*args, **kwargs)


class Executor(MAPEComponent):
    @property
    def next(self) -> None:
        return None

    def _update_knowledge(self, *args, **kwargs):
        self.manager.knowledge.register_executor_update(*args, **kwargs)


class MAPEKMixin:
    _monitor: Optional[Monitor]
    _analyser: Optional[Analyser]
    _planner: Optional[Planner]
    _executor: Optional[Executor]
    _knowledge: Optional[Knowledge]

    def __init__(
            self,
            *args,
            monitor: Optional[Monitor] = None,
            analyser: Optional[Analyser] = None,
            planner: Optional[Planner] = None,
            executor: Optional[Executor] = None,
            knowledge: Optional[Knowledge] = None,
            **kwargs
    ):
        super().__init__(*args, **kwargs)

        if monitor is not None:
            monitor.manager = self
        self._monitor = monitor
        if analyser is not None:
            analyser.manager = self
        self._analyser = analyser
        if planner is not None:
            planner.manager = self
        self._planner = planner
        if executor is not None:
            executor.manager = self
        self._executor = executor
        self._knowledge = knowledge

    @property
    def monitor(self) -> Optional[Monitor]:
        return self._monitor

    @monitor.setter
    def monitor(self, monitor: 'Monitor'):
        monitor.manager = self
        self._monitor = monitor

    @property
    def analyser(self) -> Optional[Analyser]:
        return self._analyser

    @analyser.setter
    def analyser(self, analyser: 'Analyser'):
        analyser.manager = self
        self._analyser = analyser

    @property
    def planner(self) -> Optional[Planner]:
        return self._planner

    @planner.setter
    def planner(self, planner: 'Planner'):
        planner.manager = self
        self._planner = planner

    @property
    def executor(self) -> Optional[Executor]:
        return self._executor

    @executor.setter
    def executor(self, executor: 'Executor'):
        executor.manager = self
        self._executor = executor

    @property
    def knowledge(self) -> Optional[Knowledge]:
        return self._knowledge

    @knowledge.setter
    def knowledge(self, knowledge: Knowledge):
        self._knowledge = knowledge

    def run_mapek_iteration(self, *args, **kwargs):
        # Run MAPE(K) loop iteration starting from monitor
        self._monitor(*args, **kwargs)

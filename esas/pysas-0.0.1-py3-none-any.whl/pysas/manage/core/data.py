from dataclasses import dataclass, field, asdict

import numpy as np
from sklearn.base import TransformerMixin

import torch.nn as nn

from typing import Optional, List, Dict, Union


__all__ = ['SystemModel', 'SystemModelPrediction', 'SystemModelPredictions', 'MDPData']


@dataclass
class SystemModel:
    status_transformer: TransformerMixin
    action_transformer: TransformerMixin
    reward_transformer: TransformerMixin
    agent_model: nn.Module
    transfer_model_id: Optional[int]
    # agent: Agent  # TODO check if this is correct


@dataclass
class SystemModelPrediction:
    model_id: Optional[int] = None


@dataclass
class SystemModelPredictions:
    predictions: List[SystemModelPrediction] = field(default_factory=list)

    def __iter__(self):
        return iter(self.predictions)

    def __getitem__(self, index) -> Union['SystemModelPredictions', SystemModelPrediction]:
        if isinstance(index, int):
            return self.predictions[index]
        elif isinstance(index, slice):
            return self.__class__(predictions=self.predictions[index])
        else:
            raise ValueError()

    def __len__(self) -> int:
        return len(self.predictions)

    def append(self, observation: SystemModelPrediction):
        self.predictions.append(observation)


@dataclass
class MDPData:
    q_function: Optional[float] = None
    v_function: Optional[float] = None
    gamma: Optional[float] = None
    reward: Optional[float] = None
    reward_components: Dict[str, float] = field(default_factory=dict)

    @property
    def flat_data(self) -> Dict:
        data = asdict(self)

        reward_components = data.pop('reward_components')
        data |= reward_components

        return data

from .core import Manager

from .deltaiot import *
from .malware_infection import *

from typing import Dict, Type


manager_mapping: Dict[str, Type[Manager]] = {
    DeltaIoTBaseMAPEKManager.__name__: DeltaIoTBaseMAPEKManager,
    DeltaIoTRandomMAPEKManager.__name__: DeltaIoTRandomMAPEKManager,
    DeltaIoTSimpleMAPEKManager.__name__: DeltaIoTSimpleMAPEKManager,
    DeltaIoTLearningMAPEKManager.__name__: DeltaIoTLearningMAPEKManager,
    MalwareInfectionBaseMAPEKManager.__name__: MalwareInfectionBaseMAPEKManager,
    MalwareInfectionRandomMAPEKManager.__name__: MalwareInfectionRandomMAPEKManager,
    MalwareInfectionLearningMAPEKManager.__name__: MalwareInfectionLearningMAPEKManager
}

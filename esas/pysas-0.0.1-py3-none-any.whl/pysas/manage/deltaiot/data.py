import pandas as pd

from dataclasses import dataclass, field, asdict

from typing import Dict, List, Union, Literal, Optional, Tuple

from pysas.system.deltaiot.system import DeltaIoTAction
from pysas.system.deltaiot.data import DeltaIoTStatus, DeltaIoTQoS
from ..core.data import *


__all__ = [
    'DeltaIoTObservations',
    'DeltaIoTObservation',
    'DeltaIoTModel',
    'DeltaIoTModelPrediction',
    'DeltaIoTModelPredictions',
    'DeltaIoTModelSimilarities'
]


@dataclass
class DeltaIoTObservation:
    step: int
    status: DeltaIoTStatus
    metrics: DeltaIoTQoS
    activations: Optional[Dict[int, bool]] = None

    @property
    def status_df(self) -> pd.DataFrame:
        # TODO handle case where there are topology changes in the future
        # TODO see if direction gateway should be a feature
        return self.status.status_df


@dataclass
class DeltaIoTObservations:
    observations: List[DeltaIoTObservation] = field(default_factory=list)

    @property
    def states(self) -> List[DeltaIoTStatus]:
        return [obs.status for obs in self.observations]

    @property
    def states_df(self) -> pd.DataFrame:
        return pd.concat((observation.status_df for observation in self.observations), axis=0, ignore_index=True)

    @property
    def metrics(self) -> List[DeltaIoTQoS]:
        return [obs.metrics for obs in self.observations]

    @property
    def metrics_df(self):
        return pd.DataFrame(asdict(m) for m in self.metrics)

    @property
    def activations(self) -> List[Dict[int, bool]]:
        return [obs.activations for obs in self.observations]

    @property
    def activations_df(self) -> pd.DataFrame:
        return pd.DataFrame(self.activations)

    def __iter__(self):
        return iter(self.observations)

    def __getitem__(self, index) -> Union['DeltaIoTObservations', DeltaIoTObservation]:
        if isinstance(index, int):
            return self.observations[index]
        elif isinstance(index, slice):
            return self.__class__(observations=self.observations[index])
        else:
            raise ValueError()

    def __len__(self) -> int:
        return len(self.observations)

    def append(self, observation: DeltaIoTObservation):
        self.observations.append(observation)


@dataclass
class DeltaIoTModelSimilarities:
    past_state_vectors: Dict[int, List[float]]
    past_state_cluster: Dict[int, int]
    past_state_centroids: Dict[int, List[float]]
    current_state_vectors: Dict[int, List[float]]
    current_state_centroid: List[float]
    similarities: Dict[int, float]


@dataclass
class DeltaIoTModel(SystemModel):
    init_status: DeltaIoTStatus
    training_observations: DeltaIoTObservations
    history: List[Dict] = field(default_factory=list)
    similarities: DeltaIoTModelSimilarities = field(default_factory=DeltaIoTModelSimilarities)

    @property
    def history_df(self) -> pd.DataFrame:
        return pd.DataFrame(self.history)


@dataclass(kw_only=True)
class DeltaIoTMDPData(MDPData):
    action: Dict[Tuple[int, int], Optional[Literal['delete', 'restore']]] = field(default_factory=dict)

    @property
    def flat_data(self) -> Dict:
        data = super().flat_data

        action = data.pop('action')
        data |= {
            f'{src_node_id}_{dest_node_id}_{target}': a
            for target, actions in action.items()
            for (src_node_id, dest_node_id), a in actions.items()
        }

        return data


@dataclass(kw_only=True)
class DeltaIoTModelPrediction(SystemModelPrediction):
    step: Optional[int] = None
    status: Optional[DeltaIoTStatus] = None
    metrics: Optional[DeltaIoTQoS] = None
    mdp_data: Optional[DeltaIoTMDPData] = field(default_factory=DeltaIoTMDPData)
    drift_detected: bool = False
    drift_warning: bool = False
    plan: Optional[List[DeltaIoTAction]] = None


@dataclass(kw_only=True)
class DeltaIoTModelPredictions(SystemModelPredictions):
    @property
    def metrics(self) -> List[DeltaIoTQoS]:
        return [pred.metrics for pred in self.predictions]

    @property
    def metrics_df(self) -> pd.DataFrame:
        return pd.DataFrame(self.metrics)

    @property
    def mdp_data(self):
        return [pred.mdp_data.flat_data for pred in self.predictions]

    @property
    def mdp_data_df(self) -> pd.DataFrame:
        return pd.DataFrame(self.mdp_data)

    @property
    def drift(self) -> List[Dict[Literal['warning', 'detection'], bool]]:
        return [{'warning': pred.drift_warning, 'detection': pred.drift_detected} for pred in self.predictions]

    @property
    def drift_df(self) -> pd.DataFrame:
        return pd.DataFrame(self.drift)

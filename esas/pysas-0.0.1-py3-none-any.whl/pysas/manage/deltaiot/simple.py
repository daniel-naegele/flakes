from dataclasses import dataclass, field

from .data import DeltaIoTObservation, DeltaIoTAction
from pysas.manage.core.mixin.mapek import Analyser, Planner, Executor
from .base import DeltaIoTBaseMAPEKManager, DeltaIoTBaseKnowledge, DeltaIoTBaseMonitor

from typing import List, Optional, Dict, Type, Tuple


__all__ = [
    'DeltaIoTSimpleMAPEKManager',
    'DeltaIoTSimpleAnalyser',
    'DeltaIoTSimplePlanner',
    'DeltaIoTSimpleExecutor',
    'DeltaIoTSimpleKnowledge'
]


@dataclass(kw_only=True)
class DeltaIoTSimpleKnowledge(DeltaIoTBaseKnowledge):
    adaptation_triggers: List[bool] = field(default_factory=list)
    plans: List[List[DeltaIoTAction]] = field(default_factory=list)

    def register_analyser_update(self, *args, adapt: Optional[bool] = None, **kwargs):
        if adapt is not None:
            self.adaptation_triggers.append(adapt)

    def register_planner_update(self, *args, plan: Optional[List[DeltaIoTAction]] = None, **kwargs):
        if plan is not None:
            self.plans.append(plan)

    def register_executor_update(self, *args, **kwargs):
        pass


class DeltaIoTSimpleAnalyser(Analyser):
    _manager: 'DeltaIoTSimpleMAPEKManager'

    def _run(self, *args, observation: Optional[DeltaIoTObservation] = None, **kwargs):
        if observation is None:
            raise ValueError()

        for mote in observation.status.motes:
            for link in mote.links:
                if (link.snr > 0 and link.power > 0) or (link.snr < 0 and link.power < 15):
                    return True
            if len(mote.links) == 2:
                link_a, link_b = mote.links
                if link_a.power != link_b.power:
                    return True

        return False
    

class DeltaIoTSimplePlanner(Planner):      
    _manager: 'DeltaIoTSimpleMAPEKManager'
    
    def _run(
            self,
            *args,
            observation: Optional[DeltaIoTObservation] = None,
            adapt: Optional[bool] = None,
            **kwargs
    ):
        if observation is None:
            raise ValueError()
        if adapt is None:
            raise ValueError()

        plan: List[DeltaIoTAction] = list()

        if not adapt:
            return plan

        power_changing: bool = False
        for mote in observation.status.motes:
            for link in mote.links:
                power_changing = False
                if link.snr > 0 and link.power > 0:
                    plan.append(DeltaIoTAction(
                        src_node_id=link.src_node_id,
                        dest_node_id=link.dest_node_id,
                        target='power',
                        action='decrease'
                    ))
                    power_changing = True
                elif link.snr < 0 and link.power < 15:
                    plan.append(DeltaIoTAction(
                        src_node_id=link.src_node_id,
                        dest_node_id=link.dest_node_id,
                        target='power',
                        action='increase'
                    ))
                    power_changing = True
            if len(mote.links) == 2 and not power_changing:
                link_a, link_b = mote.links
                if link_a.power != link_b.power:
                    equalize = link_a.distribution == 100 and link_b.distribution == 100
                    if link_a.power > link_b.power and (link_a.distribution < 100 or equalize):
                        plan.append(DeltaIoTAction(
                            src_node_id=link_a.src_node_id,
                            dest_node_id=link_a.dest_node_id,
                            target='distribution',
                            action='increase',
                            equalize=equalize
                        ))
                        plan.append(DeltaIoTAction(
                            src_node_id=link_b.src_node_id,
                            dest_node_id=link_b.dest_node_id,
                            target='distribution',
                            action='decrease',
                            equalize=equalize
                        ))
                    elif link_b.distribution < 100 or equalize:
                        plan.append(DeltaIoTAction(
                            src_node_id=link_a.src_node_id,
                            dest_node_id=link_a.dest_node_id,
                            target='distribution',
                            action='decrease',
                            equalize=equalize
                        ))
                        plan.append(DeltaIoTAction(
                            src_node_id=link_b.src_node_id,
                            dest_node_id=link_b.dest_node_id,
                            target='distribution',
                            action='increase',
                            equalize=equalize
                        ))

        return plan


class DeltaIoTSimpleExecutor(Executor):
    _manager: 'DeltaIoTSimpleMAPEKManager'
    
    def _run(self, *args, plan: Optional[List[DeltaIoTAction]] = None, **kwargs):
        if plan is not None:
            self._manager.system.execute(plan)


class DeltaIoTSimpleMAPEKManager(DeltaIoTBaseMAPEKManager):
    _analyser: DeltaIoTSimpleAnalyser
    _planner: DeltaIoTSimplePlanner
    _executor: DeltaIoTSimpleExecutor
    _knowledge: DeltaIoTSimpleKnowledge

    mappings: Dict[str, Type] = {
        DeltaIoTBaseMonitor.__name__: DeltaIoTBaseMonitor,
        DeltaIoTSimpleAnalyser.__name__: DeltaIoTSimpleAnalyser,
        DeltaIoTSimplePlanner.__name__: DeltaIoTSimplePlanner,
        DeltaIoTSimpleExecutor.__name__: DeltaIoTSimpleExecutor,
        DeltaIoTSimpleKnowledge.__name__: DeltaIoTSimpleKnowledge
    }
    _mapped: Tuple[str, ...] = ('monitor', 'analyser', 'planner', 'executor', 'knowledge')
    
    def __init__(
            self, 
            *args,
            analyser: Optional[DeltaIoTSimpleAnalyser] = None,
            planner: Optional[DeltaIoTSimplePlanner] = None,
            executor: Optional[DeltaIoTSimpleExecutor] = None,
            knowledge: Optional[DeltaIoTSimpleKnowledge] = None,
            **kwargs
    ):
        super().__init__(
            *args,
            analyser=analyser if analyser is not None else DeltaIoTSimpleAnalyser(manager=self),
            planner=planner if planner is not None else DeltaIoTSimplePlanner(manager=self),
            executor=executor if executor is not None else DeltaIoTSimpleExecutor(manager=self),
            knowledge=knowledge if knowledge is not None else DeltaIoTSimpleKnowledge(),
            **kwargs
        )

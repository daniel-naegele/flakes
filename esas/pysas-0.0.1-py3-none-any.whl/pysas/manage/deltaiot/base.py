import os
import logging

import bz2
import pickle

import math

from ..core import Manager, MAPEKMixin
from pysas.manage.core.mixin.mapek import Monitor, Knowledge
from .data import DeltaIoTObservations, DeltaIoTObservation

from pysas.system.deltaiot import DeltaIoT
from pysas.system.deltaiot.utils import compute_metrics

from dataclasses import dataclass, field

from typing import Optional, Type, Dict, Tuple, Literal

from pysas.system.core import SystemAction
from pysas.system.deltaiot.data import DeltaIoTStatus, Mote

from matplotlib import pyplot as plt


__all__ = [
    'DeltaIoTBaseMAPEKManager',
    'DeltaIoTBaseMonitor',
    'DeltaIoTBaseKnowledge'
]


@dataclass(kw_only=True)
class DeltaIoTBaseKnowledge(Knowledge):
    observations: DeltaIoTObservations = field(default_factory=DeltaIoTObservations)

    def register_monitor_update(self, *args, observation: Optional[DeltaIoTObservation] = None, **kwargs):
        if observation is not None:
            self.observations.append(observation)


class DeltaIoTBaseMonitor(Monitor):
    _manager: 'DeltaIoTBaseMAPEKManager'

    def _get_mote_last_packet_number(self, mote: Mote) -> int:
        for m in self.knowledge.observations[-1].status.motes:
            if m.id == mote.id:
                return m.last_packet_number

        return 0

    def _check_mote_activation(self, mote: Mote) -> bool:
        # changet to use the new attribute
        return mote.did_activate_this_turn if hasattr(mote, 'did_activate_this_turn') else False

    def _run(self, status: DeltaIoTStatus, *args, **kwargs):
        return DeltaIoTObservation(
            self._manager.system.step,
            status,
            compute_metrics(status),
            activations={mote.id: self._check_mote_activation(mote) for mote in status.motes}
        )


class DeltaIoTBaseMAPEKManager(MAPEKMixin, Manager):
    _system: Optional[DeltaIoT]

    _monitor: Optional[DeltaIoTBaseMonitor]
    _knowledge = Optional[DeltaIoTBaseKnowledge]

    mappings: Dict[str, Type] = {
        DeltaIoTBaseMonitor.__name__: DeltaIoTBaseMonitor,
        DeltaIoTBaseKnowledge.__name__: DeltaIoTBaseKnowledge
    }
    _mapped: Tuple[str, ...] = ('monitor', 'knowledge')

    def __init__(
            self,
            *args,
            monitor: Optional[DeltaIoTBaseMonitor] = None,
            knowledge: Optional[DeltaIoTBaseKnowledge] = None,
            **kwargs
    ):
        super().__init__(
            *args,
            monitor=monitor if monitor is not None else DeltaIoTBaseMonitor(manager=self),
            knowledge=knowledge if knowledge is not None else DeltaIoTBaseKnowledge(),
            **kwargs
        )

    @property
    def system(self) -> DeltaIoT:
        return self._system

    @system.setter
    def system(self, system: Optional[DeltaIoT]):
        logging.debug('Registering system')
        self._system = system
        logging.debug('System registered in observer')

    def _checkpoint(self, path: str):
        with bz2.BZ2File(os.path.join(path, 'knowledge.pbz2'), 'w') as f:
            pickle.dump(self._knowledge, f)
        self._knowledge.observations.metrics_df.to_csv(os.path.join(path, 'metrics.csv'), index=False)
        self._knowledge.observations.activations_df.to_csv(os.path.join(path, 'activations.csv'), index=False)

    def _plot_metric(
            self,
            metric,
            title,
            *args,
            figure: Optional[plt.Figure] = None,
            axis: Optional[plt.Axes] = None,
            show: bool = True,
            ma_win_size: Optional[int] = 8,
            ma_n_sigma: Optional[float] = None,
            ewma_alpha: Optional[float] = 0.1,
            ewma_n_sigma: Optional[float] = None,
            ylabel='Value',
            **kwargs
    ):
        figure = plt.figure(*args, **kwargs) if figure is None and axis is None else figure
        axis = figure.add_subplot(1, 1, 1) if axis is None else axis

        metrics = self.knowledge.observations.metrics_df

        axis.plot(metrics.index, metrics[metric], c='tab:blue', label='Raw values')
        if ma_win_size is not None:
            ma = metrics[metric].rolling(ma_win_size, min_periods=1).mean()
            axis.plot(metrics.index, ma, c='tab:red', label=f'MA ($w = {ma_win_size}$)')
            if ma_n_sigma is not None:
                std = metrics[metric].rolling(ma_win_size, min_periods=1).std()
                axis.fill_between(
                    metrics.index, ma - ma_n_sigma * std, ma + ma_n_sigma * std, color='tab:red', alpha=0.33
                )
        if ewma_alpha is not None:
            ewma = metrics[metric].ewm(alpha=ewma_alpha).mean()
            axis.plot(metrics.index, ewma, c='tab:green', label=f'EWMA ($\\alpha = {ewma_alpha}$)')
            if ewma_n_sigma is not None:
                std = metrics[metric].ewm(alpha=ewma_alpha).std()
                axis.fill_between(
                    metrics.index, ewma - ewma_n_sigma * std, ewma + ewma_n_sigma * std, color='tab:green', alpha=0.33
                )
        axis.axhline(
            metrics[metric].mean(), xmin=0, xmax=max(metrics.index), c='k', ls='--', label='Mean'
        )

        axis.set_xlabel('Step')
        axis.set_ylabel(ylabel)
        axis.set_title(title)
        axis.grid()
        axis.legend(loc='best')

        if show:
            plt.show()

        return figure, axis

    def plot_cec(self, *args, **kwargs):
        return self._plot_metric(
            'cumulative_energy_consumption', 'Cumulative energy consumption', *args, ylabel='Energy', **kwargs
        )

    def plot_apl(self, *args, **kwargs):
        return self._plot_metric(
            'average_packet_loss', 'Average packet loss', *args, ylabel='Packet loss', **kwargs
        )

    def plot_nfi(self, *args, **kwargs):
        return self._plot_metric(
            'network_fairness_index', 'Network fairness index', *args, ylabel='Fairness', **kwargs
        )

    def plot_metrics(
            self,
            *args,
            figure: Optional[plt.Figure] = None,
            axes: Optional[plt.Axes] = None,
            show: bool = True,
            ma_win_size: Optional[int] = 8,
            ma_n_sigma: Optional[float] = None,
            ewma_alpha: Optional[float] = 0.1,
            ewma_n_sigma: Optional[float] = None,
            **kwargs
    ):
        figure, axes = plt.subplots(
            *args, nrows=1, ncols=3, sharex=True, **kwargs
        ) if figure is None and axes is None else (figure, axes)
        axes = figure.subplots(nrows=1, ncols=3, sharex=True) if axes is None else axes.flatten()

        for f, ax in zip([self.plot_cec, self.plot_apl, self.plot_nfi], axes):
            f(
                *args,
                axis=ax,
                show=False,
                ma_win_size=ma_win_size,
                ma_n_sigma=ma_n_sigma,
                ewma_alpha=ewma_alpha,
                ewma_n_sigma=ewma_n_sigma,
                **kwargs
            )

        if show:
            plt.show()

        return figure, axes

    def plot_activations(
        self,
        *args,
        figure: Optional[plt.Figure] = None,
        axes: Optional[plt.Axes] = None,
        show: bool = True,
        ma_win_size: Optional[int] = 8,
        ewma_alpha: Optional[float] = 0.1,
        ncols=2,
        **kwargs
    ):
        activations = self.knowledge.observations.activations_df

        figure, axes = plt.subplots(
            *args, nrows=int(math.ceil(len(activations.columns) / ncols)), ncols=ncols, 
            sharex=True, sharey=True, **kwargs
        ) if figure is None and axes is None else (figure, axes)
        axes = figure.subplots(...) if axes is None else axes.flatten()

        for i, mote_id in enumerate(activations.columns):
            ax = axes[i]

            ax.fill_between(activations.index, activations[mote_id], color='tab:blue', step='pre', alpha=0.33)
            ax.step(activations.index, activations[mote_id], c='tab:blue', label='Raw values')
            
            if ma_win_size is not None:
                ax.plot(
                    activations.index,
                    activations[mote_id].rolling(ma_win_size, min_periods=1).mean(),
                    c='tab:red',
                    label=f'MA ($w = {ma_win_size}$)'
                )
            
            if ewma_alpha is not None:
                ax.plot(
                    activations.index,
                    activations[mote_id].ewm(alpha=ewma_alpha).mean(),
                    c='tab:green',
                    label=f'EWMA ($\\alpha = {ewma_alpha}$)'
                )
            
            ax.axhline(activations[mote_id].mean(), xmin=0, xmax=max(activations.index), 
                    c='k', ls='--', label='Mean')
            
            mote = self.system.get_mote(mote_id)
            prob = mote.activation_probability

            # Check if the profile varies over time
            if len(set(prob.values)) == 1:
                # Constant value - horizontal line
                ax.axhline(
                    prob.get(0),
                    xmin=0,
                    xmax=max(activations.index),
                    c='tab:orange',
                    label='Activation proba.'
                )
            else:
                # Variable profile
                max_step = max(activations.index)
                profile_x = list(range(max_step + 1))
                profile_y = [prob.get(step) for step in profile_x]
                
                # Plot the profile line
                ax.plot(
                    profile_x,
                    profile_y,
                    c='tab:orange',
                    linewidth=2,
                    alpha=0.8,
                    label='Activation proba.',  # CHANGED: Keep label consistent
                    zorder=5
                )

            if i + 1 == len(activations.columns):
                ax.set_xlabel('Step')
            ax.set_ylabel('Activation')
            ax.set_title(f'Mote {mote_id} activation')
            ax.grid()

        if figure is not None:
            # FIX: Get handles/labels dynamically from first axis
            handles, labels = axes[0].get_legend_handles_labels()
            figure.legend(
                handles,
                labels,
                loc='upper center',
                bbox_to_anchor=(0.5, 0.925),
                ncol=len(handles)  # CHANGED: Use actual number of legend entries
            )

        if show:
            plt.show()

        return figure, axes

    def plot(self, *args, **kwargs):
        ...

    def observe(self):
        return self._system.status

    def start(self):
        pass

    def act(self, *args, **kwargs):
        # Run MAPE loop starting from monitor
        self.run_mapek_iteration(*args, **kwargs)

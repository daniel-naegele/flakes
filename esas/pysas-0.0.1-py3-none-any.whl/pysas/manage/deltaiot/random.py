from dataclasses import dataclass, field

import random

from pysas.system.deltaiot.system import DeltaIoTAction

from .data import DeltaIoTObservation
from pysas.manage.core.mixin.mapek import Analyser, Planner, Executor
from .base import DeltaIoTBaseMAPEKManager, DeltaIoTBaseKnowledge, DeltaIoTBaseMonitor

from typing import List, Optional, Dict, Type, Tuple

__all__ = [
    'DeltaIoTRandomMAPEKManager',
    'DeltaIoTRandomAnalyser',
    'DeltaIoTRandomPlanner',
    'DeltaIoTRandomExecutor',
    'DeltaIoTRandomKnowledge'
]


# TODO refactor to delete repeated code


@dataclass(kw_only=True)
class DeltaIoTRandomKnowledge(DeltaIoTBaseKnowledge):
    plans: List[List[DeltaIoTAction]] = field(default_factory=list)
    
    def register_analyser_update(self, *args, **kwargs):
        pass

    def register_planner_update(self, *args, plan: Optional[List[DeltaIoTAction]] = None, **kwargs):
        if plan is not None:
            self.plans.append(plan)

    def register_executor_update(self, *args, **kwargs):
        pass
    

class DeltaIoTRandomAnalyser(Analyser):
    _manager: 'DeltaIoTRandomMAPEKManager'

    def _run(self, *args, **kwargs):
        pass


class DeltaIoTRandomPlanner(Planner):
    _manager: 'DeltaIoTRandomMAPEKManager'

    def _run(
            self,
            *args,
            observation: Optional[DeltaIoTObservation] = None,
            **kwargs
    ):
        if observation is None:
            raise ValueError()

        plan: List[DeltaIoTAction] = list()

        for link in observation.status.links:
            power_action = random.choice(['increase', 'decrease', None])
            if power_action is not None:
                plan.append(DeltaIoTAction(
                    src_node_id=link.src_node_id,
                    dest_node_id=link.dest_node_id,
                    target='power',
                    action=power_action
                ))
            distribution_action = random.choice(['increase', 'decrease', None])
            if distribution_action is not None:
                plan.append(DeltaIoTAction(
                    src_node_id=link.src_node_id,
                    dest_node_id=link.dest_node_id,
                    target='distribution',
                    action=distribution_action,
                    equalize=False
                ))

        return plan


class DeltaIoTRandomExecutor(Executor):
    _manager: 'DeltaIoTRandomMAPEKManager'

    def _run(self, *args, plan: Optional[List[DeltaIoTAction]] = None, **kwargs):
        if plan is not None:
            self._manager.system.execute(plan)


class DeltaIoTRandomMAPEKManager(DeltaIoTBaseMAPEKManager):
    _analyser: DeltaIoTRandomAnalyser
    _planner: DeltaIoTRandomPlanner
    _executor: DeltaIoTRandomExecutor
    _knowledge: DeltaIoTRandomKnowledge

    mappings: Dict[str, Type] = {
        DeltaIoTBaseMonitor.__name__: DeltaIoTBaseMonitor,
        DeltaIoTRandomAnalyser.__name__: DeltaIoTRandomAnalyser,
        DeltaIoTRandomPlanner.__name__: DeltaIoTRandomPlanner,
        DeltaIoTRandomExecutor.__name__: DeltaIoTRandomExecutor,
        DeltaIoTRandomKnowledge.__name__: DeltaIoTRandomKnowledge
    }
    _mapped: Tuple[str, ...] = ('monitor', 'analyser', 'planner', 'executor', 'knowledge')

    def __init__(
            self,
            *args,
            analyser: Optional[DeltaIoTRandomAnalyser] = None,
            planner: Optional[DeltaIoTRandomPlanner] = None,
            executor: Optional[DeltaIoTRandomExecutor] = None,
            knowledge: Optional[DeltaIoTRandomKnowledge] = None,
            **kwargs
    ):
        super().__init__(
            *args,
            analyser=analyser if analyser is not None else DeltaIoTRandomAnalyser(manager=self),
            planner=planner if planner is not None else DeltaIoTRandomPlanner(manager=self),
            executor=executor if executor is not None else DeltaIoTRandomExecutor(manager=self),
            knowledge=knowledge if knowledge is not None else DeltaIoTRandomKnowledge(),
            **kwargs
        )

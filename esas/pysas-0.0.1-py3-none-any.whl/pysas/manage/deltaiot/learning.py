import os

from copy import deepcopy

import logging

from dataclasses import dataclass, field

import torch.nn as nn

from typing import Optional, List, Tuple, Dict, Type, Literal, Iterable, Union

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.base import TransformerMixin
from sklearn.preprocessing import StandardScaler
from matplotlib import pyplot as plt
import torch

from pysas.learn.preprocessing.transformers.deltaiot import *
from pysas.learn.olem.core import ChangeDetector
from pysas.learn.olem import EDDM
from pysas.learn.nn.graph import LinearEdgeEstimator
from pysas.learn.rl.core import Agent
from pysas.learn.rl.agent import GraphDQN, GraphQNetFactory
from pysas.learn.rl.environment import DeltaIoTEnvironment, DeltaIoTPerturbedEnvironment
from ..core.mixin import LearnerMixin, TwinMixin
from ..core.mixin.mapek import Analyser, Planner, Executor
from ..core.mixin.learner import TransformerFactory, EnvironmentFactory, AgentInitialiser
from .data import (
    DeltaIoTObservation,
    DeltaIoTModel,
    DeltaIoTModelPrediction,
    DeltaIoTModelPredictions,
    DeltaIoTModelSimilarities
)
from .base import DeltaIoTBaseMAPEKManager, DeltaIoTBaseMonitor, DeltaIoTBaseKnowledge
from pysas.system import DeltaIoT
from pysas.system.deltaiot.system import DeltaIoTAction
from pysas.system.deltaiot.data import DeltaIoTStatus
from pysas.system.deltaiot.utils import compute_metrics


__all__ = [
    'DeltaIoTLearningMAPEKManager',
    'DeltaIoTLearningMonitor',
    'DeltaIoTLearningAnalyser',
    'DeltaIoTLearningPlanner',
    'DeltaIoTLearningKnowledge',
    'DeltaIoTStatusTransformerFactory',
    'DeltaIoTActionTransformerFactory',
    'DeltaIoTRewardTransformerFactory',
    'DeltaIoTEnvironmentFactory',
    'DeltaIoTPerturbedEnvironmentFactory'
]


class DeltaIoTStatusTransformerFactory(TransformerFactory):
    def __call__(self, init_data: pd.DataFrame, *args, **kwargs):
        status_transformer = DeltaIoTStatusTransformer().fit(init_data)

        return status_transformer


class DeltaIoTActionTransformerFactory(TransformerFactory):
    def __call__(self, *args, **kwargs):
        action_transformer = DeltaIoTActionTransformer().fit(
            {k: [None, 'increase', 'decrease'] for k in ['power', 'distribution']}
        )

        return action_transformer


class DeltaIoTRewardTransformerFactory(TransformerFactory):
    def __call__(self, metrics: pd.DataFrame, *args, **kwargs):
        reward_transformer = DeltaIoTRewardTransformer().fit(metrics)

        return reward_transformer


class DeltaIoTEnvironmentFactory(EnvironmentFactory):
    def build(self, *args, **kwargs) -> DeltaIoTEnvironment:
        return DeltaIoTEnvironment(
            *args,
            **kwargs
        )


class DeltaIoTPerturbedEnvironmentFactory(DeltaIoTEnvironmentFactory):
    def __init__(self, injection_probability=None, injection_probabilities_for_events=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._injection_probability = injection_probability
        self._injection_probabilities_for_events = injection_probabilities_for_events

    def build(
        self,
        *args,
        **kwargs
    ) -> DeltaIoTPerturbedEnvironment:
        # kwargs.pop("injection_probabilities_for_events", None)
        return DeltaIoTPerturbedEnvironment(
            *args,
            injection_probability=self._injection_probability,
            injection_probabilities_for_events=self._injection_probabilities_for_events,
            **kwargs
        )


@dataclass(kw_only=True)
class DeltaIoTLearningKnowledge(DeltaIoTBaseKnowledge):
    models: List[DeltaIoTModel] = field(default_factory=list)

    model_predictions: DeltaIoTModelPredictions = field(default_factory=DeltaIoTModelPredictions)
    plans: List[Optional[List[DeltaIoTAction]]] = field(default_factory=list)

    active_model_id: Optional[int] = None
    transfer_model_id: Optional[int] = None
    steps_from_last_update: Optional[int] = None
    model_similarities: Optional[DeltaIoTModelSimilarities] = None

    def register_monitor_update(self, *args, twin_observation: Optional[DeltaIoTModelPrediction] = None, **kwargs):
        super().register_monitor_update(*args, **kwargs)
        self.model_predictions.append(
            DeltaIoTModelPrediction(
                model_id=self.active_model_id,
                step=twin_observation.step if twin_observation is not None else self.observations[-1].step,
                status=twin_observation.status if twin_observation is not None else None,
                metrics=twin_observation.metrics if twin_observation is not None else None
            )
        )

    def register_analyser_update(
            self,
            *args,
            action: Optional[Dict[Literal['power', 'distribution'], Iterable[Optional[Literal['increase', 'decrease']]]]] = None,
            q: Optional[float] = None,
            v: Optional[float] = None,
            gamma: Optional[float] = None,
            reward: Optional[float] = None,
            rewards: Optional[Dict[str, float]] = None,
            drift_detected: Optional[bool] = None,
            drift_warning: Optional[bool] = None,
            **kwargs
    ):
        self.model_predictions[-1].drift_detected = drift_detected
        self.model_predictions[-1].drift_warning = drift_warning
        self.model_predictions[-1].mdp_data.q_function = q
        self.model_predictions[-1].mdp_data.v_function = v
        self.model_predictions[-1].mdp_data.gamma = gamma
        self.model_predictions[-1].mdp_data.reward = reward
        self.model_predictions[-1].mdp_data.reward_components = rewards
        self.model_predictions[-1].mdp_data.action = {
            k: {(l.src_node_id, l.dest_node_id): a for l, a in zip(self.observations[-1].status.links, actions)}
            for k, actions in action.items()
        } if action is not None else dict()

    def register_planner_update(self, *args, plan: Optional[List[DeltaIoTAction]] = None, **kwargs):
        self.plans.append(plan)
        self.model_predictions[-1].plan = plan

    def register_executor_update(self, *args, **kwargs):
        pass


class DeltaIoTLearningMonitor(DeltaIoTBaseMonitor):
    _manager: 'DeltaIoTLearningMAPEKManager'

    OUT_KEY: Tuple[str, ...] = ('twin_observation', DeltaIoTBaseMonitor.OUT_KEY)

    def _run(self, *args, **kwargs):
        observation = super()._run(*args, **kwargs)
        twin_observation = None

        if self._manager.system_twin is not None:
            twin_status = self._manager.system_twin.status
            twin_observation = DeltaIoTObservation(
                self._manager.system_twin.step, twin_status, compute_metrics(twin_status)
            )

        return twin_observation, observation


class DeltaIoTLearningAnalyser(Analyser):
    _manager: 'DeltaIoTLearningMAPEKManager'

    mappings: Dict[str, Type] = {
        EDDM.__name__: EDDM
    }
    _mapped: Tuple[str, ...] = ('change_detector',)

    OUT_KEY: Tuple[str, ...] = (
        'action',
        'q',
        'v',
        'gamma',
        'reward',
        'rewards',
        'drift_detected',
        'drift_warning'
    )

    def __init__(self, *args, change_detector: Optional[ChangeDetector] = None, **kwargs):
        super().__init__(*args, **kwargs)

        self._change_detector: Optional[ChangeDetector] = change_detector

    @property
    def change_detector(self):
        return self._change_detector

    @torch.no_grad()
    def _run(self, *args, observation: Optional[DeltaIoTObservation] = None, **kwargs):
        action = None
        q = None
        v = None
        gamma = None
        reward = None
        rewards = {k: None for k in observation.metrics.keys}
        drift_detection = False
        drift_warning = False

        if self._manager.agent is not None and self._manager.knowledge.active_model_id is not None:
            encoded_status = self._manager.agent.preprocess_status(
                self._manager.status_transformer.transform([observation.status_df])
            )
            encoded_action = self._manager.agent.predict(encoded_status)
            action = self._manager.action_transformer.inverse_transform(
                self._manager.agent.postprocess_action(encoded_action)
            )[0]  # Note: output is batched
            q = self._manager.agent.q_function(encoded_status, encoded_action).cpu().item()
            v = self._manager.agent.v_function(encoded_status).cpu().item()
            gamma = self._manager.agent.gamma
            reward = self._manager.reward_transformer.transform(pd.DataFrame([observation.metrics])).item()
            rewards = dict(zip(
                observation.metrics.keys,
                self._manager.reward_transformer.transform(pd.DataFrame([observation.metrics]), scalarise=False)[0].tolist()
            ))

        if self._change_detector is not None:
            error_df = np.abs(self.knowledge.observations.metrics_df - self.knowledge.model_predictions.metrics_df)
            drift_detection, drift_warning = self._change_detector(error_df)

        return action, q, v, gamma, reward, rewards, drift_detection, drift_warning


class DeltaIoTLearningPlanner(Planner):
    _manager: 'DeltaIoTLearningMAPEKManager'

    def _run(
            self,
            *args,
            observation: Optional[DeltaIoTObservation] = None,
            action: Optional[Union[Dict[str, Optional[str]], List[Optional[str]]]] = None,
            **kwargs
    ):
        return DeltaIoTAction.build_plan(observation.status, action) if action is not None else None


class DeltaIoTLearningExecutor(Executor):
    _manager: 'DeltaIoTLearningMAPEKManager'

    def _run(self, *args, plan: Optional[List[DeltaIoTAction]] = None, **kwargs):
        if plan is not None:
            twin_plan = deepcopy(plan) if self._manager.system_twin is not None else None
            self._manager.system.execute(plan)
            if twin_plan is not None:
                self._manager.system_twin.execute(twin_plan)
                self._manager.system_twin.run_step()


class DeltaIoTAgentInitialiser(AgentInitialiser):
    def __init__(self, *args, reference_agent: Optional[Literal['first', 'last', 'most_similar']] = None, **kwargs):
        super().__init__(*args, **kwargs)

        self._reference_agent: Optional[Literal['first', 'last', 'most_similar']] = reference_agent

    def _get_status_embedding(self, status: DeltaIoTStatus, environment: DeltaIoTEnvironment) -> np.ndarray:
        return environment.status_transformer.transform([status.status_df])[0][0].mean(axis=0, keepdims=0)

    def _search_most_similar_model(
            self, agent: Agent, environment: DeltaIoTEnvironment, knowledge: DeltaIoTLearningKnowledge, warmup: int,
            train_size: int
    ) -> Tuple[int, float]:
        # Compute vector representation of all past states (shifted because of warning period)
        status_vectors = np.vstack([
            self._get_status_embedding(status, environment)
            for status in knowledge.observations[warmup - train_size:].states
        ]).astype(np.float32)

        status_vectors = StandardScaler().fit_transform(status_vectors)  # status_vectors = PCA(n_components=.95, whiten=True).fit_transform(status_vectors)

        past_status_embeddings = status_vectors[:-train_size]
        current_status_embeddings = status_vectors[-train_size:]
        # Identify cluster corresponding to each state
        past_status_clusters = np.array([
            pred.model_id for pred in knowledge.model_predictions[warmup:]
        ])
        # Compute centroid of states corresponding to the same model
        past_status_centroids = np.vstack([
            past_status_embeddings[past_status_clusters == model_id].mean(axis=0)
            for model_id in np.unique(past_status_clusters)
        ])
        # Compute vector representation of current status
        current_status_centroid = current_status_embeddings.mean(axis=0, keepdims=True)
        # Compute cosine similarity between current state and centroids
        similarities = {
            model_id.item(): similarity.item()
            for model_id, similarity in zip(
                np.unique(past_status_clusters),
                cosine_similarity(past_status_centroids, current_status_centroid).flatten()
            )
        }

        most_similar_model_id = max(similarities, key=similarities.get)

        knowledge.model_similarities = DeltaIoTModelSimilarities(
            {o.step: v.tolist() for o, v in zip(knowledge.observations[warmup-train_size:-train_size], past_status_embeddings)},
            {o.step: m.item() for o, m in zip(knowledge.observations[warmup-train_size:-train_size], past_status_clusters)},
            {m.item(): c.tolist() for m, c in zip(np.unique(past_status_clusters), past_status_centroids)},
            {o.step: v.tolist() for o, v in zip(knowledge.observations[-train_size:], current_status_embeddings)},
            current_status_centroid.flatten().tolist(),
            similarities
        )

        return most_similar_model_id, similarities[most_similar_model_id]

    def _get_reference_agent(self, knowledge: DeltaIoTLearningKnowledge) -> Optional[nn.Module]:
        if self._reference_agent is None:
            return None
        elif self._reference_agent == 'first':
            return knowledge.models[0].agent_model
        elif self._reference_agent == 'last':
            return knowledge.models[-1].agent_model
        elif self._reference_agent == 'most_similar' and knowledge.transfer_model_id is not None:
            return knowledge.models[knowledge.transfer_model_id].agent_model
        else:
            raise ValueError(f'Unknown reference agent {self._reference_agent}')

    def _transfer_model(
            self,
            agent: Agent,
            environment: DeltaIoTEnvironment,
            knowledge: DeltaIoTLearningKnowledge,
            tgt_model_id: int
    ):
        environment.status_transformer = knowledge.models[tgt_model_id].status_transformer
        environment.action_transformer = knowledge.models[tgt_model_id].action_transformer
        environment.reward_transformer = knowledge.models[tgt_model_id].reward_transformer
        agent.model = deepcopy(agent.model)
        agent.weights = knowledge.models[tgt_model_id].agent_model.state_dict()
        knowledge.transfer_model_id = tgt_model_id if knowledge.active_model_id != tgt_model_id else knowledge.models[tgt_model_id].transfer_model_id
        agent.baseline_model = self._get_reference_agent(knowledge)

    def __call__(
            self,
            agent: Agent,
            environment: DeltaIoTEnvironment,
            knowledge: DeltaIoTLearningKnowledge,
            warmup: int,
            train_size: int,
            *args,
            **kwargs
    ) -> Agent:
        most_similar_model_id, similarity = None, None
        if self._similarity_threshold is not None:
            most_similar_model_id, similarity = self._search_most_similar_model(
                agent, environment, knowledge, warmup, train_size
            )
            if similarity >= self._similarity_threshold and most_similar_model_id != knowledge.model_predictions[-1].model_id:  # Second clause is to push for fine tuning if most similar is still last
                knowledge.active_model_id = most_similar_model_id
                self._transfer_model(agent, environment, knowledge, most_similar_model_id)
                return agent
        if self._transfer_threshold is not None:
            if most_similar_model_id is None or similarity is None:
                most_similar_model_id, similarity = self._search_most_similar_model(
                    agent, environment, knowledge, warmup, train_size
                )
            if similarity >= self._transfer_threshold:
                self._transfer_model(agent, environment, knowledge, most_similar_model_id)
        else:
            self._transfer_model(agent, environment, knowledge, knowledge.model_predictions[-1].model_id)
        return agent.fit(environment)


class DeltaIoTLearningMAPEKManager(LearnerMixin, TwinMixin, DeltaIoTBaseMAPEKManager):
    _monitor: DeltaIoTLearningMonitor
    _analyser: DeltaIoTLearningAnalyser
    _planner: DeltaIoTLearningPlanner
    _executor: DeltaIoTLearningExecutor
    _knowledge: DeltaIoTLearningKnowledge

    _environment: DeltaIoTEnvironment

    _system_twin: Optional[DeltaIoT] = None

    mappings: Dict[str, Type] = {
        DeltaIoTEnvironmentFactory.__name__: DeltaIoTEnvironmentFactory,
        DeltaIoTPerturbedEnvironmentFactory.__name__: DeltaIoTPerturbedEnvironmentFactory,
        DeltaIoTStatusTransformerFactory.__name__: DeltaIoTStatusTransformerFactory,
        DeltaIoTActionTransformerFactory.__name__: DeltaIoTActionTransformerFactory,
        DeltaIoTRewardTransformerFactory.__name__: DeltaIoTRewardTransformerFactory,
        DeltaIoTAgentInitialiser.__name__: DeltaIoTAgentInitialiser,
        DeltaIoTLearningMonitor.__name__: DeltaIoTLearningMonitor,
        DeltaIoTLearningAnalyser.__name__: DeltaIoTLearningAnalyser,
        DeltaIoTLearningPlanner.__name__: DeltaIoTLearningPlanner,
        DeltaIoTLearningExecutor.__name__: DeltaIoTLearningExecutor,
        DeltaIoTLearningKnowledge.__name__: DeltaIoTLearningKnowledge,
        GraphDQN.__name__: GraphDQN
    }
    _mapped: Tuple[str, ...] = (
        'agent',
        'environment_factory',
        'status_transformer_factory',
        'action_transformer_factory',
        'reward_transformer_factory',
        'agent_initialiser',
        'monitor',
        'analyser',
        'planner',
        'executor',
        'knowledge'
    )

    def __init__(
            self,
            *args,
            agent: Optional[Agent] = None,
            status_transformer_factory: Optional[TransformerFactory] = None,
            action_transformer_factory: Optional[TransformerFactory] = None,
            reward_transformer_factory: Optional[TransformerFactory] = None,
            environment_factory: Optional[DeltaIoTEnvironmentFactory] = None,
            monitor: Optional[DeltaIoTLearningMonitor] = None,
            analyser: Optional[DeltaIoTLearningAnalyser] = None,
            planner: Optional[DeltaIoTLearningPlanner] = None,
            executor: Optional[DeltaIoTLearningExecutor] = None,
            knowledge: Optional[DeltaIoTLearningKnowledge] = None,
            train_size: int = 1,
            stride: Optional[Union[int, float]] = None,
            warmup: Optional[int] = None,
            use_twin: bool = True,
            **kwargs
    ):
        warmup = warmup if warmup is not None else train_size
        if warmup < train_size:
            raise ValueError()

        super().__init__(
            *args,
            agent=agent if agent is not None else GraphDQN(
                batch_size=2,
                episodes=2,
                episode_steps=4,
                iterations=2,
                iteration_steps=2,
                replay_buffer_size=96 * 4,
                eps_init=0.95,
                eps_final=0.05,
                eps_schedule='linear',
                max_grad_norm=1.0,
                half_precision=True,
                logging_period=10,
                patience=10,
                warmup=100,
                model_factory=GraphQNetFactory(LinearEdgeEstimator),
                centered=True
            ),
            environment_factory=environment_factory if environment_factory is not None else DeltaIoTEnvironmentFactory(),
            status_transformer_factory=status_transformer_factory if status_transformer_factory is not None else DeltaIoTStatusTransformerFactory(),
            action_transformer_factory=action_transformer_factory if action_transformer_factory is not None else DeltaIoTActionTransformerFactory(),
            reward_transformer_factory=reward_transformer_factory if reward_transformer_factory is not None else DeltaIoTRewardTransformerFactory(),
            monitor=monitor if monitor is not None else DeltaIoTLearningMonitor(manager=self),
            analyser=analyser if analyser is not None else DeltaIoTLearningAnalyser(manager=self),
            planner=planner if planner is not None else DeltaIoTLearningPlanner(manager=self),
            executor=executor if executor is not None else DeltaIoTLearningExecutor(manager=self),
            knowledge=knowledge if knowledge is not None else DeltaIoTLearningKnowledge(),
            **kwargs
        )

        self._train_size: int = train_size
        self._stride: Optional[int] = stride
        self._warmup: int = warmup

        self._use_twin: bool = use_twin

        if self._system is not None and self._system_twin is None and self._use_twin:
            self.synch_twin()

    @classmethod
    def load_active_learner_from_configs(cls, *args, proactive: bool = False, **kwargs):
        kwargs = deepcopy(kwargs)
        if 'analyser' in kwargs:
            if cls._PARAMS_KEY not in kwargs['analyser']:
                kwargs['analyser'][cls._PARAMS_KEY] = {'change_detector': {cls._DTYPE_KEY: EDDM.__name__}}
            else:
                kwargs['analyser'][cls._PARAMS_KEY]['change_detector'] = {cls._DTYPE_KEY: EDDM.__name__}
        else:
            kwargs['analyser'] = {
                cls._DTYPE_KEY: DeltaIoTLearningAnalyser.__name__,
                cls._PARAMS_KEY: {'change_detector': {cls._DTYPE_KEY: EDDM.__name__}}
            }
        return cls.load_from_configs(
            *args,
            environment_factory={
                cls._DTYPE_KEY: (
                    DeltaIoTPerturbedEnvironmentFactory if proactive else DeltaIoTEnvironmentFactory).__name__,
            },
            **kwargs
        )

    @classmethod
    def load_passive_learner_from_configs(cls, *args, proactive: bool = False, stride: Optional[Union[int, float]] = None, **kwargs):
        return cls.load_from_configs(
            *args,
            environment_factory={
                cls._DTYPE_KEY: (DeltaIoTPerturbedEnvironmentFactory if proactive else DeltaIoTEnvironmentFactory).__name__,
            },
            stride=stride if stride is not None else kwargs.get('train_size', 1),
            **kwargs
        )

    @classmethod
    def load_static_learner_from_configs(cls, *args, proactive: bool = False, **kwargs):
        return cls.load_from_configs(
            *args,
            environment_factory={
                cls._DTYPE_KEY: (DeltaIoTPerturbedEnvironmentFactory if proactive else DeltaIoTEnvironmentFactory).__name__,
            },
            **kwargs
        )

    @property
    def system(self):
        return self._system

    @system.setter
    def system(self, system: Optional[DeltaIoT]):
        logging.debug('Registering system')
        self._system = system
        logging.debug('System registered in observer')
        if self._system_twin is not None or self._use_twin:
            self._system_twin = system.clone(reset=False) if system is not None else None

    def _checkpoint(self, path: str):
        super()._checkpoint(path)
        self._knowledge.model_predictions.metrics_df.to_csv(os.path.join(path, 'expected_metrics.csv'), index=False)
        self._knowledge.model_predictions.mdp_data_df.to_csv(os.path.join(path, 'mdp_data.csv'), index=False)
        self._knowledge.model_predictions.drift_df.to_csv(os.path.join(path, 'drift_detection.csv'), index=False)

        for i, model_data in enumerate(self._knowledge.models):
            os.makedirs(os.path.join(path, 'models', str(i)), exist_ok=True)
            self._knowledge.models[i].history_df.to_csv(
                os.path.join(path, 'models', str(i), 'training.csv'), index=False
            )
            torch.save(model_data.agent_model.state_dict(), os.path.join(path, 'models', str(i), 'nn_model.pt'))

    def _build_status_transformer(self) -> TransformerMixin:
        return self._status_transformer_factory(
            self._knowledge.observations[self._warmup-self._train_size:].states_df
        )

    def _build_action_transformer(self) -> TransformerMixin:
        return self._action_transformer_factory()

    def _build_reward_transformer(self) -> TransformerMixin:
        return self._reward_transformer_factory(self._knowledge.observations[self._warmup-self._train_size:].metrics_df)

    def _build_environment(self) -> DeltaIoTEnvironment:
        return self._environment_factory.build(
            (self._system_twin if self._system_twin is not None else self._system).clone(),  # TODO fixme
            self._status_transformer,
            self._action_transformer,
            self._reward_transformer
        )

    def _build_transfer_agent(self):
        return self._agent_initialiser(
            self._agent, self._environment, self._knowledge, self._warmup, self._train_size
        )

    def plot_training_history(
            self,
            *args,
            figure: Optional[plt.Figure] = None,
            axes: Optional[plt.Axes] = None,
            show: bool = True,
            **kwargs
    ):
        figure, axes = plt.subplots(
            *args, nrows=len(self._knowledge.models), ncols=1, sharex=True, sharey=True, **kwargs
        ) if figure is None and axes is None else (figure, axes)
        axes = figure.subplots(...) if axes is None else (axes.flatten() if isinstance(axes, np.ndarray) else [axes])

        for i, model in enumerate(self._knowledge.models):
            history = model.history_df

            ax = axes[i]

            ax.plot(history['global_step'], history['loss'])

            ax.set_title('Reinforcement learning agent training')
            ax.set_xlabel('Step')
            ax.set_xlim([history['global_step'].min(), history['global_step'].max()])
            ax.set_ylabel('Loss')

            ax.grid()

        if show:
            plt.show()

        return figure, axes

    @property
    def update(self) -> bool:
        warmup_complete = self._system.step >= self._warmup

        drift_df = self._knowledge.model_predictions[-self._train_size:].drift_df
        drift_warned = drift_df.warning.all().item() if len(drift_df) > 0 else False
        drift_detected = drift_df.detection.any().item() if len(drift_df) > 0 else False

        current_model_df = self._knowledge.model_predictions[-self._knowledge.steps_from_last_update - 1:].drift_df if self._knowledge.steps_from_last_update is not None else None
        drifted_after_model_update = ((~current_model_df.detection.shift(1, fill_value=True)) & current_model_df.detection).any().item() if current_model_df is not None else True

        drifted = drift_warned and drift_detected and drifted_after_model_update

        period_completed = (self._system.step - self._warmup) % self._stride == 0 if self._stride is not None else False

        return warmup_complete and (super().update or drifted or period_completed)

    def _update_model(self):
        self._knowledge.active_model_id = len(self._knowledge.models)
        super()._update_model()
        if self._knowledge.active_model_id >= len(self._knowledge.models):
            self._knowledge.models.append(
                DeltaIoTModel(
                    self._status_transformer,
                    self._action_transformer,
                    self._reward_transformer,
                    self._agent.model,  # TODO Create agent factory
                    self._knowledge.transfer_model_id,
                    (self._system_twin if self._system_twin is not None else self._system).status,
                    self._knowledge.observations[-self._train_size:],
                    history=self._agent.history,
                    similarities=self._knowledge.model_similarities
                )
            )
        self._knowledge.steps_from_last_update = 0

    def _update_timeout(self) -> Optional[float]:
        t = self._system.time_to_next_clock_reset
        if t is not None:
            t = max(0.0, t.total_seconds() - 1.)

        return t

    @property
    def synch(self) -> bool:
        return self.update

    def _synch_twin(self):
        self._system_twin = self._system.clone(reset=False)
        for mote in self._system_twin.motes:
            try:  # TODO find better fix
                # activation_probability = self._knowledge.observations.activations_df[mote.id].iloc[-self._train_size:].mean().item()
                activation_probability = float(
                    self._knowledge.observations.activations_df[mote.id].iloc[-self._train_size:].mean()
                )
            except KeyError:
                activation_probability = 1.0
            except AttributeError: #to temporarily patch 'float' object has no attribute 'item'
                activation_probability = self._knowledge.observations.activations_df[mote.id].iloc[-self._train_size:].mean()
                logging.warning(f'AttributeError: {activation_probability} actually has type {type(activation_probability)}')

            self._system_twin.update_mote(id=mote.id, params={"activation_probability":activation_probability})

    def observe(self):
        # Update step counter
        if self._knowledge.steps_from_last_update is not None:
            self._knowledge.steps_from_last_update += 1
        # Get observation
        return super().observe()

    def act(self, *args, **kwargs):
        # Synch digital twin
        if self.synch:
            self.synch_twin()
        # Check if updating is required
        if self.update:
            self.update_model()
        # Run MAPE loop starting from monitor
        super().act(*args, **kwargs)

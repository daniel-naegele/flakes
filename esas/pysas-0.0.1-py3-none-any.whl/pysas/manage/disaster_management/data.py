import pandas as pd

from dataclasses import dataclass, field, asdict

from typing import List, Union

from pysas.system.disaster_management.data import DisasterManagementStatus, DisasterManagementQoS


__all__ = [
    'DisasterManagementObservations',
    'DisasterManagementObservation'
]


@dataclass
class DisasterManagementObservation:
    step: int
    status: DisasterManagementStatus
    metrics: DisasterManagementQoS

    @property
    def status_df(self) -> pd.DataFrame:
        # TODO handle case where there are topology changes in the future
        # TODO see if direction gateway should be a feature
        return self.status.status_df


@dataclass
class DisasterManagementObservations:
    observations: List[DisasterManagementObservation] = field(default_factory=list)

    @property
    def states(self) -> List[DisasterManagementStatus]:
        return [obs.status for obs in self.observations]

    @property
    def states_df(self) -> pd.DataFrame:
        return pd.concat((observation.status_df for observation in self.observations), axis=0, ignore_index=True)

    @property
    def metrics(self) -> List[DisasterManagementQoS]:
        return [obs.metrics for obs in self.observations]

    @property
    def metrics_df(self):
        return pd.DataFrame(asdict(m) for m in self.metrics)

    def __iter__(self):
        return iter(self.observations)

    def __getitem__(self, index) -> Union['DisasterManagementObservations', DisasterManagementObservation]:
        if isinstance(index, int):
            return self.observations[index]
        elif isinstance(index, slice):
            return self.__class__(observations=self.observations[index])
        else:
            raise ValueError()

    def __len__(self) -> int:
        return len(self.observations)

    def append(self, observation: DisasterManagementObservation):
        self.observations.append(observation)

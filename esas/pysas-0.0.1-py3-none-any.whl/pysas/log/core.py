from pysas.system.core import SystemLogger as Logger

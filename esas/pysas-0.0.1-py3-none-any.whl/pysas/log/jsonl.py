import json
import os
import numpy as np
from scipy.sparse import issparse

from .core import Logger


class JSONLLogger(Logger):
    FILE: str = 'logs.jsonl'

    def start(self):
        os.makedirs(self._system.path, exist_ok=True)
        open(os.path.join(self._system.path, self.FILE), 'x').close()

    def _flush(self, path: str):
        with open(os.path.join(path, self.FILE), 'a') as f:
            for entry in self._buffer:
                f.write(json.dumps(entry, default=self._json_serializer))
                f.write('\n')
    
    def _json_serializer(self, obj):
        """Custom JSON serializer for objects not serializable by default json code"""
        if issparse(obj):
            return {
                '__type__': 'sparse_matrix',
                '__format__': obj.format,
                '__shape__': obj.shape,
                '__data__': obj.toarray().tolist()
            }
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, (np.integer, np.floating)):
            return obj.item()
        else:
            raise TypeError(f'Object of type {obj.__class__.__name__} is not JSON serializable')
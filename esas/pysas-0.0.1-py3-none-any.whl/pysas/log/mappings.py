from .core import Logger

from typing import Dict, Type

from .jsonl import JSONLLogger


logger_mapping: Dict[str, Type[Logger]] = {
    JSONLLogger.__name__: JSONLLogger
}

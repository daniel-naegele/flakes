from .jsonl import JSONLLogger

from .mappings import logger_mapping

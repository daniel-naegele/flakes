from typing import Optional, Dict, Type, Tuple


__all__ = ['ConfigurableMixin']


class ConfigurableMixin:
    _DTYPE_KEY: str = 'dtype'
    _PARAMS_KEY: str = 'params'

    mappings: Optional[Dict[str, Type]] = None
    _mapped: Optional[Tuple[str, ...]] = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @classmethod
    def load_from_configs(cls, *args, **kwargs):
        if cls._mapped is not None:
            for mapped in cls._mapped:
                configs = kwargs.pop(mapped, None)
                if configs is not None:
                    tgt_class = cls.mappings[configs[cls._DTYPE_KEY]]
                    params = configs.get(cls._PARAMS_KEY, dict())
                    try:
                        kwargs[mapped] = tgt_class.load_from_configs(**params)
                    except AttributeError:
                        kwargs[mapped] = tgt_class(**params)

        return cls(*args, **kwargs)

import os
os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'

import shutil
from argparse import ArgumentParser, Namespace
import logging
from datetime import datetime

import random
import math

import numpy as np
import torch

from joblib import Parallel, delayed, parallel_config

import yaml

from typing import Dict, List, Optional, Union

from pysas.system import system_mapping
from pysas.log import logger_mapping
from pysas.manage import manager_mapping
from pysas.schedule import scheduler_mapping

from pysas.system.core import System
from pysas.log.core import Logger
from pysas.manage.core import Manager
from pysas.schedule.core import EventsScheduler


RUNS: str = 'runs'
STEPS: str = 'steps'
SEED: str = 'seed'

SYSTEM: str = 'system'
LOGGERS: str = 'loggers'
MANAGER: str = 'manager'
SCHEDULER: str = 'scheduler'

DTYPE: str = 'dtype'
PARAMS: str = 'params'

CONFIG_FILE_NAME: str = 'config.yml'


def run_experiment(config: Dict[str, Union[Dict, int]], output_path: Optional[str] = None, restart: bool = True) -> None:
    # Run experiment
    start_time = datetime.now()
    logging.info(f'Experiment started')

    # Set random seed
    if config.get(SEED) is not None:
        random.seed(config[SEED])
        np.random.seed(config[SEED])
        torch.manual_seed(config[SEED])
        torch.cuda.manual_seed_all(config[SEED])
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # Create experiment directory
    if output_path is not None:
        os.makedirs(output_path, exist_ok=True)

    # Create system simulator
    system_type: str = config[SYSTEM][DTYPE]
    system_params: Dict = config[SYSTEM].get(PARAMS, dict()) | {'seed': config.get(SEED)}
    system: System = system_mapping[system_type].load_from_configs(**system_params, path=output_path)
    logging.debug(f'{system_type} instantiated')

    # Create and register loggers if required
    if LOGGERS in config and output_path is not None:
        for logger_config in config[LOGGERS]:
            logger_type: str = logger_config[DTYPE]
            logger_params: Dict = logger_config.get(PARAMS, dict())
            logger: Logger = logger_mapping[logger_type].load_from_configs(**logger_params)
            logging.debug(f'{logger_type} instantiated')
            system.logger = logger
            logging.debug(f'{logger_type} registered in system')

    # Create and register manager if required
    if MANAGER in config:
        manager_type: str = config[MANAGER][DTYPE]
        manager_params: Dict = config[MANAGER].get(PARAMS, dict())
        manager: Manager = manager_mapping[manager_type].load_from_configs(**manager_params)
        logging.debug(f'{manager_type} instantiated')
        system.manager = manager
        logging.debug(f'{manager_type} registered in system')

    # Create and register change trigger if required
    if SCHEDULER in config:
        scheduler_type: str = config[SCHEDULER][DTYPE]
        scheduler_params: Dict = config[SCHEDULER].get(PARAMS, dict())
        scheduler: EventsScheduler = scheduler_mapping[scheduler_type].load_from_configs(**scheduler_params)
        logging.debug(f'{scheduler_type} instantiated')
        system.observer = scheduler
        logging.debug(f'{scheduler_type} registered in system')

    num_steps: int = config[STEPS]
    try:
        system(num_steps=num_steps)
    except Exception as e:
        if restart:
            logging.error(f'Experiment failed - Restarting experiment')
            shutil.rmtree(output_path)
            run_experiment(config, output_path=output_path, restart=True)
        else:
            raise e

    stop_time = datetime.now()
    logging.info(f'Experiment completed - Running time: {stop_time - start_time}')


def run_seed_update(config: Dict[str, Union[Dict, int]], run_idx) -> Dict:
    if config.get(SEED) is not None:
        return {SEED: config[SEED] + run_idx}
    else:
        return dict() 

def run_experiments(config: Dict[str, Union[Dict, int]], output_path: Optional[str] = None, restart: bool = True) -> None:
    # Run experiments
    start_time = datetime.now()
    logging.info(f'Experiments started')

    # Create experiments directory
    if output_path is not None:
        os.makedirs(output_path, exist_ok=True)

    # Dump configs
    if output_path is not None:
        with open(os.path.join(output_path, CONFIG_FILE_NAME), 'w') as f:
            yaml.dump(config, f)
        logging.debug(f'Configs dumped at {output_path}')

    num_runs: int = config[RUNS]
    num_digits: int = int(1 + math.floor(math.log10(num_runs)))
    Parallel()(
        delayed(run_experiment)(
            config | run_seed_update(config, i),
            output_path=os.path.join(output_path, str(i).zfill(num_digits)),
            restart=restart
        )
        for i in range(1, num_runs + 1)
    )

    stop_time = datetime.now()
    logging.info(f'Experiments block completed - Running time: {stop_time - start_time}')



def parse_arguments() -> Namespace:
    parser = ArgumentParser(description='Self-Adaptive Systems Simulation Command Line Tool')

    parser.add_argument(
        '--config',
        type=str,
        nargs='+',
        help='Path or list of paths to config files or directories containing config files'
    )
    parser.add_argument(
        '--output',
        type=str,
        default=None,
        help='Output directory path (if specified overrides the output path specified in the configs)'
    )
    parser.add_argument(
        '--runs',
        type=int,
        default=None,
        help='Number of simulation runs (if specified overrides the number of runs specified in the configs)'
    )
    parser.add_argument(
        '--steps',
        type=int,
        default=None,
        help='Override the number of steps per simulation specified in the configs'
    )
    parser.add_argument(
        '--seed',
        type=int,
        default=None,
        help='Random seed for reproducibility'
    )
    parser.add_argument(
        '--workers',
        type=int,
        default=1,
        help='Number of concurrent workers to run multiple simulations in parallel'
    )
    parser.add_argument(
        '--restart',
        type=bool,
        default=False,
        help='Whether to restart experiment in case of failure or not'
    )

    return parser.parse_args()


def load_configs(
        config_paths: List[str], runs: Optional[int] = None, steps: Optional[int] = None, seed: Optional[int] = None
) -> Dict[str, Dict]:
    config_files: Dict[str, str] = dict()
    for config_path in config_paths:
        if os.path.isdir(config_path):
            config_path = config_path[:-1] if config_path.endswith(os.path.sep) else config_path
            for file_name in os.listdir(config_path):
                file_name_, ext = os.path.splitext(file_name)
                if ext in ['.yml', '.yaml']:
                    config_path_ = os.path.join(config_path, file_name)
                    config_id = os.path.join(os.path.basename(config_path), file_name_)
                    config_files[config_id] = config_path_
        else:
            config_id, _ = os.path.splitext(os.path.basename(config_path))
            config_files[config_id] = config_path

    configs: Dict[str, Dict] = dict()
    for config_id, config_file_path in config_files.items():
        with open(config_file_path, 'r') as f:
            configs[config_id] = yaml.safe_load(f)
        if runs is not None:
            configs[config_id][RUNS] = runs
        if steps is not None:
            configs[config_id][STEPS] = steps
        if seed is not None:
            configs[config_id][SEED] = seed

    return configs


def main():
    # Apply basic logging configuration
    logging.basicConfig(level=logging.INFO)

    start_time = datetime.now()
    logging.info('Script started')

    # Parse arguments
    args: Namespace = parse_arguments()
    logging.debug('Arguments parsed')

    # Load config files
    configs: Dict[str, Dict] = load_configs(args.config, runs=args.runs, steps=args.steps, seed=args.seed)
    logging.debug('Config files loaded')

    # Get simulation timestamp
    timestamp: str = start_time.strftime('%Y-%m-%d_%H:%M:%S.%f')
    logging.debug(f'Timestamp set to `{timestamp}`')

    with parallel_config(n_jobs=args.workers):
        Parallel()(
            delayed(run_experiments)(
                config, output_path=os.path.join(args.output, config_id, timestamp), restart=args.restart
            )
            for config_id, config in configs.items()
        )

    stop_time = datetime.now()
    logging.info(f'Script completed - Running time: {stop_time - start_time}')

    return 0


if __name__ == '__main__':
    main()

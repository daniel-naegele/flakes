from pysas.backend.api.status import status_bp

def register_blueprints(app):
    app.register_blueprint(status_bp, url_prefix="/api")
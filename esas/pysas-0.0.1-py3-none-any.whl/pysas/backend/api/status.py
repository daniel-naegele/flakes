from flask import Blueprint, jsonify

status_bp = Blueprint("status", __name__)

@status_bp.get("/status")
def get_status():
    return jsonify("ok"), 200

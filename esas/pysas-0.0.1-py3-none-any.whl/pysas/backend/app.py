from flask import Flask
from pysas.backend.config import Config
from pysas.backend.extensions import cors
from pysas.backend.api import register_blueprints

def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)

    cors.init_app(app, resources={r"/api/*": {"origins": "http://localhost:4242"}})

    register_blueprints(app)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)

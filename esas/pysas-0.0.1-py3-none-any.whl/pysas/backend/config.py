class Config:
    SECRET_KEY = "WillBeReplacedByEnvVar"
    JSON_SORT_KEYS = False